#!/bin/bash

pip3 install progress
pip3 install matplotlib
pip3 install pandas
pip3 install regex
pip3 install Levenshtein