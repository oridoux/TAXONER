p318 = ["Lépidotus", "lépidotus", "Jépidostés",
        "lépidotus", "Crocodilus depressifrons", "lépidotus"]

p374 = ["1beris umbellata", "Hesperis matronalis"]

p68 = ["NEPHROPS STEWARTII", "Astacus zaleucus",
       "Nephrops Stewartii", "Nephrops Norwegicus", "Astaciens",
       "Astacus pellucidus", "Cambarus pellucidus", "Calocaris Macandre",
       "Calliaxis adriatica", "Nephrops Stewartii", "Àstacus zaleucus",
       "Calocaris", "Nephrops Stewartii", "Nephrops", "Hoploparia longimana"]

p262 = ["Quercus Coccifera", "Lacanium vermilio", "phylHoxera vastatrix"]

p372 = ["Scalpella", "Scalpellum regium", "Sculpellum regium", "Scalpellum"
        "Scalpellum", "Scalpellum r igium", "Scalpellum regium",
        "Physostomes", "Siernoptychides", "Sternoptychide",
        "Thalassidroma Wilsoni", "Ophioglyphe bullata",
        "Antennarius marmoratus", "Lophius Piscatorius", "Antennarus",
        "Sargassum bacciferum"]

p177 = ["Calophasis Ellioti", "Phasianus lorquatus", "Torquatus",
        "Revesit", "Calophase", "Euplocomes", "Phasianides"]

p338 = ["Glaucium Serpieri", "Glaucium"]

p44 = ["Phylloxera vastatrix"]

p307 = ["Macrotoma Heros", "Holothuria edulis"]

p330 = ["Peper Methysticum", "Dammara viliensis"]

p391 = ["Stenotomus argyrops", "Coryphène", "Pomatomus saltatrix",
        "Slenolumus argyrops", "lomatomus sallatrix",
        "0phius americanus", "Pentacta frondosa",
        "Cerianthus borealis", "Lophius americanus", "ophius",
        "Torpedo occidentalis", "Dendronotus arborescens",
        "Lophothuria fabricii", "Pentacta frondosa", "Boltenia reniformis"
        "Boltenia", "Cerianthus borealis"]

p403 = ["Spirorbis nautiloides", "Cirratulus", "Cornutus autolytus"
        "Lern onema radiata", "Lucernia quadricornis", "iner Grratulus"
        "Cancer irroratus", "Lucernia quadricornis"]

p416 = ["Crotaliens", "Vipériens",
        "Acanthophide cérastin", "Acanthophide cérastin"]

p144 = ["Musa ensete"]

p245 = ["Pharyngiens labyrinthiformes", "Osphronemus olfax",
        "Aroïdées"]

p151 = ["scorpio europ", "scorpio occilanus", "scorpio occitanus",
        "scorpio afer", "scorpio funestus", "buthus imperalor",
        "scorpio occitanus", "scorpio occitanus", "scorpio europ",
        "scorpio occitanus", "Scorpio occitanus", "scorpio occilanus",
        "scorpio occitanus"]

p14 = ["Urtica urens"]

p80 = ["Pagurus Bernardus Linn", "Palémons", "Crangons", "Buceins",
       "Dueccins", "Luccin Lessin"]

p193 = ["ANABANTIDÉS", "Anabas", "Anabantidés", "Anabas"
        "anabas", "Anabantidés", "Anabantidé", "Anabantidés",
        "Anabantidés", "Anabas", "Anabas", "Anabas", "Anabas",
        "Anabantidés", "Anabas Cienopome", "Spirobranches",
        "Polyacanthe", "Macropode", "Orphromène", "Trichopus",
        "Trichopsis", "Trichogaster", "Betta", "Heloctome"]

p31 = ["Esox lucius", "Clupea sardinia", "Pleuronecles solea",
       "Osmerus eperlanus", "Alburinus lucidus Heck", "Gobis fluviatilis"]

p218 = []

p369 = ["MOAS", "DINORNIS", "Moas", "Dinornis", "Brévipennes",
        "Dinerais ingens", "Brévipennes", "tarsométatarsien",
        "tarsométatarsien", "elephantopus", "Dinora",
        "Palaptéryx", "Dinornis", "Dinornis robustus", "Dinornis giganteus",
        "Dinornis giganieus", "Dinornis casuarinus",
        "D didiformis", "D elephantopus", "Dinornis ingens",
        "Dinornis", "Dinornis", "Strigops", "Ocydromes"]

p90 = ["sorex areneus", "sorex fodiens", "arvicola arvalis",
       "auriculis absconditis"]

p135 = ["Phoca vitulina", "Cumetopias selleri", "Trichichus rosmarus"]

p115 = ["Téléostéens", "Ganvïdes", "Téléostéens", "Holécoïdes",
        "Ganoïides", "Gestraciontes", "Iylodontes", "Ganoïdes",
        "Plagiostomes", "Fistularia", "Vomer", "Osmerus", "Clupea",
        "Osmerus Albyi", "Anopterus Albyi", "Conus ponderosus",
        "Turritella triplicata", "Murex scabcr Arca", "Trigla licat",
        "Triglid", "Triglid", "Triglida licat", "Triglida Hirundo",
        "Scomhéroïdes", "Anxis", "Scomber", "Osmerus Albyi",
        "Anapterus", "Üsmerus", "Anapterus", "Diatomacées",
        ]

p178 = ["Yponomente", "Yponomenta malinella", "Bombyx neustria Linn",
        "Liparis dispar Linn", "Liparis chrysorrhea Linn",
        "Liparis auriflua"]

p408 = ["Pexophaps", "Ocydrome", "Erythromaque", "Athene murivora",
        "Ardea megacephala", "Psitlacus rodericanus", "Turtur picturatus",
        "Columba rodericana", "Numida tiarata", "Pteropus rubricollis Leguat"]

p239 = ["Trachelocerea olor", "Amphileptus margaritifer",
        "Kolpode capuchon", "Euplotes charon",
        "Paramécie AuréHe", "Stylonychia mytilus", "Kolpodes",
        "Paramécies", "amphileptus", "euplotus", "Stylonychia Icion"]

p288 = ["Podocarpus Koraiana"]
