# ----------------------------------------------------------------------------------------------------------
Experience launched on May 04, 2022 at 14:42:47
Chosen mode: union
----------------------------------------------------------------------------------------------------------
## starting evaluation of volume vol83
Evaluation of the article : page_611 :
	true positives : [] 
	false positives : ["Ruccrro Ravasixi", "Coquetier mire", "R. Viiuers", "C. Lechalas", "R. Marrerr"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_109 :
	true positives : [] 
	false positives : ["Stephenson actionnentles", "Almagestum novum", "Riccrour relaie", "Perspectiva horaria"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_472 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_507 :
	true positives : ["Gigantosaurus africanus", "G. robustus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_218 :
	true positives : ["Vipera berus", "Vipera aspis", "Naja hiperdians", "Lachesis lanceolatus", "Vipera aspis", "Crotalus terrificus"] 
	false positives : ["Sao Paulo"] 
	false negatives : [] 
	precision = 85.71 %
	recall = 100.00 %
	F-measure = 92.31 %
Evaluation of the article : page_232 :
	true positives : [] 
	false positives : ["Sierra Candelaria", "Lucrex Fourier", "Sapeurs pompiers"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_310 :
	true positives : ["Rotalina orbicularis", "Pupa similis", "Pupa similis"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_122 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_139 :
	true positives : [] 
	false positives : ["Imperator rappellera", "Princeps Mathematicorum", "Bourgogne survenue", "Roufs flotlanis", "Gama Machado", "B. Emerson", "P. Joumors"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_488 :
	true positives : ["Cereus pitahaya"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_83 :
	true positives : [] 
	false positives : ["Revaccination antityphique", "Viribus Unitis"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_537 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_655 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_654 :
	true positives : [] 
	false positives : ["Amplitudes diurnes", "Hadiation solair"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_569 :
	true positives : ["Homo heidelbergensis"] 
	false positives : ["H. Ducxwortx"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_550 :
	true positives : ["yucca filamentosa", "helianthus multiflorus", "bocconia microcarpa"] 
	false positives : ["Amplitudes diurnes"] 
	false negatives : ["statice limonium", "anemone japonica"] 
	precision = 75.00 %
	recall = 60.00 %
	F-measure = 66.67 %
Evaluation of the article : page_489 :
	true positives : [] 
	false positives : ["piedra movediza", "Quiconque transmettra", "assa f\u0153tida", "Matth\u0153us Platearius", "medicina dictus", "Circa instans", "Circa instans", "olla positus", "Serapionis dicta", "S. Baglioni", "C. Hess"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_60 :
	true positives : ["Macrorhinus elephantinus", "Canis jubatus", "Bradypus tridactylus"] 
	false positives : ["Clemente ficie"] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : ["Uxiox vgsraze", "Wie onts"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_530 :
	true positives : ["Cichorium intrbus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_281 :
	true positives : [] 
	false positives : ["cxpor ation"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_341 :
	true positives : ["Sporotrichum globuliferum"] 
	false positives : ["Botr ylis"] 
	false negatives : ["Botr ylis bassiana"] 
	precision = 50.00 %
	recall = 50.00 %
	F-measure = 50.00 %
Evaluation of the article : page_176 :
	true positives : ["Amanita phalloides", "Russula emetica", "Amanita phalloides", "Balliota campestris", "Amanita muscaria", "Boletus edulis"] 
	false positives : ["accueillis Lepiota", "A. Acroqur"] 
	false negatives : ["Lepiota procera"] 
	precision = 75.00 %
	recall = 85.71 %
	F-measure = 80.00 %
Evaluation of the article : page_105 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_372 :
	true positives : [] 
	false positives : ["Hyla arborea", "Alytes obstetricans", "Sciurres rufiventer", "Volontaires albanais", "Slaves austrohongrois", "grosso modo"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_657 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_35 :
	true positives : ["Rhizina inflata", "Rhizina inflata"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_169 :
	true positives : ["Mirabilis Jalappa", "Mirabilis jalappa"] 
	false positives : ["Farents inlr", "Elude stalislique"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_570 :
	true positives : [] 
	false positives : ["Amortisseur pneminatique", "Lectures anthropologiques", "Gasron Bonxier", "L. Meens", "G. Bernstein"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_80 :
	true positives : ["Homarus americanus", "Pinnotheres pisum", "Birgus latro", "Nephrops norvegicus", "Pandalus borealis"] 
	false positives : ["Aselle aqualique", "Crangon vulgar"] 
	false negatives : ["Limnoria \u2018 lignorium", "Limnoria ef des Chelura", "Crangon vulgar is"] 
	precision = 71.43 %
	recall = 62.50 %
	F-measure = 66.67 %
Evaluation of the article : page_118 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_164 :
	true positives : ["Grampus griseus", "Grampus griseus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_127 :
	true positives : [] 
	false positives : ["Eryngium maritimum", "Conventionne fui"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_230 :
	true positives : ["Raphidium nivale", "Protococcus nivalis", "Pteromonas nivalis", "Ancylonema Nordenskioldii"] 
	false positives : ["Diamylon nivale"] 
	false negatives : ["Sph\u00e6rella \u2018mivalis", "Sph\u00e6rella: lacustris", "rococcus vulg\u00e4ris"] 
	precision = 80.00 %
	recall = 57.14 %
	F-measure = 66.67 %
Evaluation of the article : page_652 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_348 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_406 :
	true positives : ["Mesonaula insignis", "Herniramphus fluvia", "Danio rerio", "Rasbora heteromorpha", "Paratilapia multicolor"] 
	false positives : [] 
	false negatives : ["Plerophy Ju scalare", "Seatophagus arqUs", "Heros ", " facetus", "Mo\u00eflienesia latipinna"] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_81 :
	true positives : ["Carcinus mo\u0153nas", "Portunus puber", "Callinectes sapidus", "Eupagurus Bernhardus", "Balanus psittacus", "Pinnotheres pisum", "Asellus aquaticus", "Limnoria lignorium", "Chelura terebrans"] 
	false positives : [] 
	false negatives : ["Cancer pagurus", "Pollicipes cornucopi\u00e6"] 
	precision = 100.00 %
	recall = 81.82 %
	F-measure = 90.00 %
Evaluation of the article : page_227 :
	true positives : ["Ornithodorus Savignyi", "Ornithodorus moubaia", "Solanum Luberosum"] 
	false positives : ["Lucrex Fournrer"] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_521 :
	true positives : [] 
	false positives : ["Vereins deutscher"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_470 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_211 :
	true positives : ["ficus carica"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_116 :
	true positives : ["Desoria glacialis", "Polytrichum formosum", "Polytrichum formosum", "Pellia epiphylla", "Polytrichum formosum", "Polytrichum formosum"] 
	false positives : ["Oronge citrine", "P. Lesage"] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_397 :
	true positives : ["Drosera rotundifolia", "Drosera rotundifolia", "Drosera rotundifolia", "Drosera rotundifolia", "Drosera rotundifolia", "Pinguicula caudata", "Drosera rotundifolia", "Dionaea muscipula", "Dionaea muscipula", "Apocynum androsoemifolium"] 
	false positives : [] 
	false negatives : ["Dionaca m\u00fcscipula"] 
	precision = 100.00 %
	recall = 90.91 %
	F-measure = 95.24 %
Evaluation of the article : page_583 :
	true positives : [] 
	false positives : ["Jacobus Henricus", "Ufficio Idrografico", "Carlo Ferrari", "Theo Hillmer", "Astra Romana", "Garnissage calorifuge", "Studio zoologico", "Mira Ceti", "Andrea Doria", "Caio Duillio", "A. Cuwapver", "J. Coe", "C. Davisox", "C. Aruould", "G. Chevallier", "J. Bonenfant", "J. Loisez", "G. Urbain", "J. Lorsez", "A. Canxox", "A. Minchin", "S. Geol"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_649 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_508 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_228 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_551 :
	true positives : ["Ceroxylon audicola", "Copernicia cerifera", "Rhus succedanea", "Rhus vermicifera", "Stillingia Sebifera"] 
	false positives : [] 
	false negatives : ["M. Cerifera", "M. Carolinensis", "M. Pensylvanica", "M. Cordifolia", "M. Quercifolia", "M. Serrata"] 
	precision = 100.00 %
	recall = 45.45 %
	F-measure = 62.50 %
Evaluation of the article : page_478 :
	true positives : ["tradescantia virginica", "geum urbanum", "deutzia scabra"] 
	false positives : ["Ambplitudes diurnes", "A. Angot"] 
	false negatives : [] 
	precision = 60.00 %
	recall = 100.00 %
	F-measure = 75.00 %
Evaluation of the article : page_471 :
	true positives : ["Atriplex halimus", "Atriplex nummularia", "Artemisia maritima", "Casuarina equisetifolia", "Ephedra alata", "Juniperus macrocarpa", "Melaleuca eri\u00e6\u0153folia", "Ph\u0153nix tenuis", "Ph\u0153nix dactylifera", "Rhus viminalis", "Salsola fruticosa", "Tamarix articulata", "Tamarix gallica", "Acacia cyclopis", "Acacia cyanophylla", "Albizzia lophauta", "Prosopis dulcis", "Casuarina quadrivalvis", "Cupressus lambertiana", "Eucalyptus robusta", "Evonymus japonica", "Ficus carica", "Pittosporum tobira", "Phillyrea media", "Parkinsonia aculeata", "Punica granatum", "Statice arborea"] 
	false positives : ["Vitex agnus", "A. Delbove", "J. Larroche", "V. Martinaud", "J. Weinmann", "E. Duval", "C. Bailly"] 
	false negatives : ["Hippoph\u00e6 rhamno\u00efdes", "Phytolacca dio\u00efca", "Vitex agnus castus", "Acacia-nilatica"] 
	precision = 79.41 %
	recall = 87.10 %
	F-measure = 83.08 %
Evaluation of the article : page_555 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_278 :
	true positives : ["Hydra fusca", "Branchipus stagnalis", "Apus productus", "Daphnia similis", "Nepa cinerea"] 
	false positives : [] 
	false negatives : ["Gammarus n\u00e9giectus"] 
	precision = 100.00 %
	recall = 83.33 %
	F-measure = 90.91 %
Evaluation of the article : page_120 :
	true positives : ["Palinurus regius", "Temnodon sallator", "Dentex maroccanus", "Temnodon Sallaior", "Beryx decadactylus"] 
	false positives : ["Brito Capello", "Temnodon sauteur", "Dentiex macro", "decadactylus Guvier"] 
	false negatives : ["Dentiex macro phthalmus", "Berg decadactylus"] 
	precision = 55.56 %
	recall = 71.43 %
	F-measure = 62.50 %
Evaluation of the article : page_252 :
	true positives : ["Bal\u00e6noptera Sibbaldii", "B. musculus", "B. borealis"] 
	false positives : ["Sandwichs australes"] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_424 :
	true positives : [] 
	false positives : ["Oualata contribuera", "Oualata reconstruite", "Blatte chanteuse", "Revaeciuation antityphique", "Revaccination antityphique", "R. Lecrnbre", "R. Boxnix", "R. Menur", "R. Vizsens", "R. Boxux", "R. Menue", "R. Boxmx", "R. Bossix", "R. Box"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_648 :
	true positives : ["Helix pomatia"] 
	false positives : ["Orro Srecae"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_610 :
	true positives : ["Polysiphonia Brodiaei", "Batrachospermum Gallaer", "Demanea fluviatilis", "Ceramium rubrum", "P. nigrescens"] 
	false positives : [] 
	false negatives : ["Rhodomela su\u00fcbfusca"] 
	precision = 100.00 %
	recall = 83.33 %
	F-measure = 90.91 %
Evaluation of the article : page_531 :
	true positives : [] 
	false positives : ["Geologica Mexicana", "Pacte ravemi", "P. Gordon", "P. Cousin"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_101 :
	true positives : ["Pulicaria vulqaris", "Pyrethrum carneum", "Pyrethrum roseum", "P. roseum"] 
	false positives : ["Chr ysanthemum"] 
	false negatives : ["Chr ysanthemum leucanthemum"] 
	precision = 80.00 %
	recall = 80.00 %
	F-measure = 80.00 %
Evaluation of the article : page_451 :
	true positives : ["Zirphaea {Pholas] cristata", "Saxicava rugosa"] 
	false positives : ["vacuum cleaner"] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_351 :
	true positives : ["Ginkgo biloba", "Ginkgo biloba", "Ginkgo biloba"] 
	false positives : ["Lilter ature"] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_192 :
	true positives : ["Littorina littoralis"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_534 :
	true positives : ["ficus carica"] 
	false positives : ["Augustus Woelker"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_369 :
	true positives : ["Arvicola agrestis"] 
	false positives : ["Campagrols pullulations"] 
	false negatives : ["Mus sylvaticus", "B. Typhi murium"] 
	precision = 50.00 %
	recall = 33.33 %
	F-measure = 40.00 %
Evaluation of the article : page_535 :
	true positives : ["Eucalyptus globulus", "quassia amara", "quassia amara"] 
	false positives : ["E. Kayser", "E. Duclaux", "E. Boullanger"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_95 :
	true positives : [] 
	false positives : ["Corrado Gappello", "Alessandro Malladra", "Immunisation vaccinale", "I. Alessandro"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_510 :
	true positives : ["galega officinalis", "Mistichthys luzonensis", "Bal\u00e6noptera sibbaldi", "Microsorex minnemana", "Blarina parva", "Diomedea exulans", "Sph\u00e6rodactylus sputator", "Varanus saltator", "Arthroleptis sechellensis", "Hyla Pickeringi", "Megalobatrachus japonicus", "Acanthophacelus bifurcus", "Arapaima gigas", "Carcharodon Rondeletii", "Oospora pulmonalis", "Rhizomucor parasiticus", "Mucor corymbifer"] 
	false positives : ["Amplitudes diurnes", "Oosporoses pulmonaires"] 
	false negatives : ["Calypte kelen\u00e6", "aspergilluss fumigatus"] 
	precision = 89.47 %
	recall = 89.47 %
	F-measure = 89.47 %
Evaluation of the article : page_452 :
	true positives : [] 
	false positives : ["Delambre laissa"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_568 :
	true positives : ["quassia amara"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_519 :
	true positives : ["Eriocampa limacina"] 
	false positives : ["E. Freurexr"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_486 :
	true positives : ["Cimex lectularius", "Acanthia lectularia"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_186 :
	true positives : [] 
	false positives : ["danstous lessens"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_311 :
	true positives : ["bacillus butylicus", "bacillus orthobutylicus"] 
	false positives : ["Osonide ara"] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_543 :
	true positives : ["Cossus ligniperda"] 
	false positives : [] 
	false negatives : ["Zeus\u00e8ra \u00e6sculi"] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_264 :
	true positives : [] 
	false positives : ["Lacroix constale"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_342 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_422 :
	true positives : ["Libellula depressa"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_166 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_212 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_102 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_302 :
	true positives : ["Eumenes coarctatus", "Eumenes coarclatus", "Euinenes unguiculus", "Odynevus spinipes", "Celonites abbreviatus", "Polistes gallicus", "Vespa germanica", "Vespa germanica", "Vespa media", "Vespa media", "Leipomeles lamellaria", "Polybia dimidiaia", "Polybia rejecta", "Ceramius lusitanicus", "Odynerus spinipes", "Polistes gallicus", "Vespa germanica", "Vespa media", "Protopolybia emortualis", "Protopolybia emortualis", "Leipomeles lamellaria", "Polybia rejecta", "Cassicus persicus"] 
	false positives : ["Vespides solilaires", "Vespides solitaires", "Ceramie portugais"] 
	false negatives : ["Odyner us spinipes", "Belenogaster junceuset", "Prolopolybia emoTtualis", "Polybia rejecta", "Chelonites abbrevi\u00e4tus"] 
	precision = 88.46 %
	recall = 82.14 %
	F-measure = 85.19 %
Evaluation of the article : page_172 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_487 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_512 :
	true positives : [] 
	false positives : ["Hooton Blackiston", "aglo inclus", "Watson jugea", "H. Paillard"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_632 :
	true positives : ["Luillaja Saponaria", "Zuillaja Saponaria", "castilloa elastica"] 
	false positives : ["Sapindus Saponaria", "Mancer Bror", "S. Gramer"] 
	false negatives : ["Sapindus Saponaria officinalis"] 
	precision = 50.00 %
	recall = 75.00 %
	F-measure = 60.00 %
Evaluation of the article : page_656 :
	true positives : ["Quillaja sapo", "Schisotrypanum Cruzi"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_314 :
	true positives : [] 
	false positives : ["Transactions philo", "nullius addicius", "verba magistri", "Costa Rica", "Malte vota", "Instr uctions", "C. Holzapfel"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_660 :
	true positives : [] 
	false positives : ["sara Casablanca", "Louer ass", "Rapaces bienfaisants", "Speclres stellaires", "Garnissage calorifuge", "Muselte mangeoire", "R. Graxsow", "R. Homwer", "G. Wervy", "G. Fisher", "R. Vizcens"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_558 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_346 :
	true positives : ["Shistocerca peregrina", "Shistocerca americana", "Micrococcus Acridiorum", "Coccobacillus Acridiorum", "Coccobacillus Acridiorum"] 
	false positives : ["ocerca americana", "Ricardo Mattei"] 
	false negatives : ["Shis{ocerca americana", "Atta Sexdens"] 
	precision = 71.43 %
	recall = 71.43 %
	F-measure = 71.43 %
Evaluation of the article : page_106 :
	true positives : ["Culex fatigans", "Stegomya fasciata"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_408 :
	true positives : [] 
	false positives : ["Basile remporta"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_177 :
	true positives : [] 
	false positives : ["Patinage agiatique"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_400 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_405 :
	true positives : [] 
	false positives : ["fyphus levissimus"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_480 :
	true positives : [] 
	false positives : ["Ulrico H\u00e6pli", "assa f\u0153tida"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_353 :
	true positives : [] 
	false positives : ["Schultze gunpowder", "Mirabilia graphica", "Technica curiosa", "Divinum munus", "velocior illis", "Nondum lingua", "suum dextra", "furta verborum", "Tachygraphia nova", "Techuca euriosa", "Tachygraphia nova", "Mirabilia graphica", "Avarus vettes", "Kuliabko conserva"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_466 :
	true positives : ["Lithodes kamschatica", "Chinoeletes opilio"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_540 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_634 :
	true positives : [] 
	false positives : ["Lyster Jameson", "Barbier conseille", "Cyon affirma", "servizio minerario", "Societa eritrea", "Aeide butyrique", "Industria Saponiera", "A. Soulier", "S. Julien"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_183 :
	true positives : ["Lomentaria articulata", "Padina Pavotia", "Corallina officinalis", "Rhodymenia palmata", "Delesseria sanguinea", "Laminaria Cloustoni", "Callophyllis laciniata", "Ulva Lactuca", "Fucus vesiculosus", "Calliblepharis ciliata", "Calliblepharis laciniata", "Plocamium coccineum", "Chondrus crispus", "Heterosiphonia coccinea"] 
	false positives : ["H. Coubin"] 
	false negatives : [] 
	precision = 93.33 %
	recall = 100.00 %
	F-measure = 96.55 %
Evaluation of the article : page_36 :
	true positives : [] 
	false positives : ["envo oyer", "Lucrex Fourxrer", "deutscher Elektrotechniker", "L. Menvsxr"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_658 :
	true positives : ["Parom\u00e6cium aurelia", "Colpomenia sinuosa"] 
	false positives : ["Hughes invente"] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_262 :
	true positives : ["Hippopotamus amphibius", "Hippopotamus amphibius", "Hippopotamus melitensis", "H. minutus", "H. madagascariensis"] 
	false positives : ["Hippopotarnes nains", "Hippopotame adulle", "Chcer opsis"] 
	false negatives : ["Hippopotamus amphibius major"] 
	precision = 62.50 %
	recall = 83.33 %
	F-measure = 71.43 %
Evaluation of the article : page_554 :
	true positives : ["Gonioma Kamassi"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_622 :
	true positives : ["veronica speciosa", "helianthus rigidus", "helianthus orgyalis"] 
	false positives : ["Amplitudes diurnes"] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_582 :
	true positives : ["polygonum cuspidatum"] 
	false positives : ["Amplitudes diurnes"] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_92 :
	true positives : ["Catarrhactes chrysolophus", "Pygoscelis antarctica", "Catarrhactes chrysolophus", "Pygoscelis antarctica"] 
	false positives : ["Pingouins antarctiques", "dermer plongeon", "ygoscelis papua", "P. papou"] 
	false negatives : ["P, Adeli\u00e6", "Aptenodytes Forsteri", "P.papua", "Catarrhacteschrysolophus", "P ygoscelis papua", "Pygoscelis Adeli\u00e6"] 
	precision = 50.00 %
	recall = 40.00 %
	F-measure = 44.44 %
Evaluation of the article : page_257 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_479 :
	true positives : ["uassia amara"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_623 :
	true positives : [] 
	false positives : ["Linde fournira"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_552 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_651 :
	true positives : ["Falco tinnunculus", "Aceipiter nisus", "Buteo vulgaris"] 
	false positives : ["Rapaces bienfaisants"] 
	false negatives : ["Astur.palumbarius"] 
	precision = 75.00 %
	recall = 75.00 %
	F-measure = 75.00 %
Evaluation of the article : page_194 :
	true positives : [] 
	false positives : ["Milton Dana", "sourcier Kurringer", "Franvins ctpar", "F. Barrett"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_103 :
	true positives : ["Phyteuma Villarsi"] 
	false positives : [] 
	false negatives : ["Phyt. Charmelii"] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_538 :
	true positives : ["Xantophyllum lanceatum"] 
	false positives : ["Leo Stevens", "Zana distante"] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_306 :
	true positives : [] 
	false positives : ["Ecoles nationales"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_124 :
	true positives : ["Picea esvention", "Betula nana", "Coronella austriaca", "Eryngium maritimum", "Cypripedium calceolus", "Ophrys muscifera", "Eryngium maritimum"] 
	false positives : ["Porta Westfalica", "Isar acheta", "Poria Westfalica"] 
	false negatives : ["Pices berg"] 
	precision = 70.00 %
	recall = 87.50 %
	F-measure = 77.78 %
Evaluation of the article : page_136 :
	true positives : ["Carex stricta", "Carex stricta", "Phragmites comcelle", "Typha angustifolia", "Juncus obtusiflorus", "Scirpus lacustris", "Carex stricta", "Carex riparia", "Scirpus lacustris", "Scirpus lacus", "Scirpus lacustris"] 
	false positives : [] 
	false negatives : ["Carex .stricta"] 
	precision = 100.00 %
	recall = 91.67 %
	F-measure = 95.65 %
Evaluation of the article : page_222 :
	true positives : [] 
	false positives : ["Sao Paulo", "Garros vainqueur"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %

overall scores on the corpus vol83:
	precision = 53.48 %
	recall = 82.08 %
	F-measure = 64.76 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## starting evaluation of volume vol126
Evaluation of the article : page_472 :
	true positives : ["Ac\u00e6na argentea", "Antholcus varinervis", "Ac\u00e6na argentea"] 
	false positives : ["Miller retourna"] 
	false negatives : ["ANTHOLCUS VARINERVIS", "Ac\u00e6na sanguisorb\u00e6"] 
	precision = 75.00 %
	recall = 60.00 %
	F-measure = 66.67 %
Evaluation of the article : page_381 :
	true positives : [] 
	false positives : ["portugais Bomba", "Procession religieuse", "Statuelies votives"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_122 :
	true positives : [] 
	false positives : ["Pedro Jevenois", "Garcia Fara", "Gallego Herrera", "Curvas dromocronicas", "Punta Ferdigua", "Medina Sidonia", "Tissier abrite", "Calligraphia gr\u0153\u00e6ca", "G. Sineriz", "G. Sineriz", "G. Sineris", "G. Sineriz"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_536 :
	true positives : [] 
	false positives : ["Marius Houlier", "Mimoso Serra", "Mathematica dilettevole", "Liber Abaci", "Griffon bruxellois", "water polo", "L. Emir", "L. Nordmann"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_160 :
	true positives : ["Perca latus", "Sci\u00e6na umbra", "Perca latus", "Malapterurus electricus", "Mormyre axyrhynaque", "Mormyrus oxyrhynchus", "Trigon vulgaris", "Trigon lymne"] 
	false positives : ["Silure trembleur", "Pastenague lymne", "Hisloire nalurelle", "P. Hiprozyre"] 
	false negatives : ["Trygon Lymne"] 
	precision = 66.67 %
	recall = 88.89 %
	F-measure = 76.19 %
Evaluation of the article : page_527 :
	true positives : ["Medicago satiwa", "Atriplex semibaccata", "Medicago faleaia"] 
	false positives : ["cerra Blanco", "Toscas calcareas", "Toscas argentines", "Bolivie montagneuse", "Chaco torride"] 
	false negatives : ["Atriplexz cachiyuyo", "\u00c6Elephas meridionalis", "Atriplez cachiyuyo"] 
	precision = 37.50 %
	recall = 50.00 %
	F-measure = 42.86 %
Evaluation of the article : page_576 :
	true positives : ["Zostera marina", "Z. nana", "Z. nana", "Z. marina", "Z. nana"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_289 :
	true positives : [] 
	false positives : ["Christiana Minekompani", "Haber creusa", "H. Kavser", "H. Konxen", "C. Tourneux"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_215 :
	true positives : [] 
	false positives : ["Madonna della", "Monsignor Angelo", "Paino Arcivescovo", "Archimandrita Donando", "Messina questo", "Orologio Miracolo", "Richiamo dei", "Angelo Paino", "A. Gould", "P. Chappuis", "A. Michelson", "R. Castaing"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_386 :
	true positives : ["Oxypleurus Nodieri"] 
	false positives : ["Jeme souviens", "Arias aetarietinr", "Nodier rencontra"] 
	false negatives : ["Carabus aurenitens", "O\u00e9ypleurus Nodieri"] 
	precision = 25.00 %
	recall = 33.33 %
	F-measure = 28.57 %
Evaluation of the article : page_295 :
	true positives : ["Welwitschia mirabilis", "Welwitschia mirabilis", "Welvitschia mirabilis", "Odontopus sexpunctatus"] 
	false positives : ["Welvitschia orme"] 
	false negatives : [] 
	precision = 80.00 %
	recall = 100.00 %
	F-measure = 88.89 %
Evaluation of the article : page_11 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_80 :
	true positives : [] 
	false positives : ["Dolomie siliceuse"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_22 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_377 :
	true positives : ["Physeter macrocephalus", "Bal\u00e6noptera acutorostrata", "Bal\u00e6na biscayensis", "Bal\u00e6noptera physalus", "Bal\u00e6na biscayensis", "Delphis delphis", "Phocaena phocaena", "Grampus griseus", "Orcinus orca", "Globicephalus melas", "Tursiops tursio", "Delphinus algeriensis", "Delphinus delphis", "Phoc\u00e6na phoc\u00e6na", "Grampus griseus", "Orcinus orca", "Tursiops tursio", "llex Paraguayensis", "D. plombeus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_108 :
	true positives : [] 
	false positives : ["Gourbes isostatiques", "Favre conseille", "Campine estla", "Campine avantles", "G. Danet", "G. Geo"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_283 :
	true positives : ["Sepia officinalis", "Sepia officinalis", "Petromyzon fluviatilis", "Petromyzon marinus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_93 :
	true positives : ["Manatus senegalensis", "Arctocephalus antarcticus"] 
	false positives : [] 
	false negatives : ["M. americanus"] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : page_500 :
	true positives : ["Scilla marilima"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_433 :
	true positives : [] 
	false positives : ["Flora sinensis", "Plantae medicinalis", "Chinese materia", "Lanoline anhydre", "Chevaliers teutoniques", "L. Dudley", "P. Guillemet", "P. Guillemet", "P. Bouraoin"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_64 :
	true positives : [] 
	false positives : ["Mercurio Europeo", "Mercurio Europeo", "Hacienda nomma"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_551 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_432 :
	true positives : ["Triodendron anfractuosum"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_120 :
	true positives : ["Bison bonasus", "Bos primigenius", "Rhinoceros trichorhinus", "Ursus spel\u00e6us"] 
	false positives : ["nomma Urus"] 
	false negatives : [] 
	precision = 80.00 %
	recall = 100.00 %
	F-measure = 88.89 %
Evaluation of the article : page_475 :
	true positives : [] 
	false positives : ["chancelier Hitler"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_146 :
	true positives : [] 
	false positives : ["Consultations gratuites"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_548 :
	true positives : ["Anchusa linctoria"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_145 :
	true positives : ["Casianea sativa"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_38 :
	true positives : [] 
	false positives : ["saura retrancher", "Phenomena hydrauliea-pneumatica", "Mersenne utilisa", "Eclipse iotale", "Meyerson exposa", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Mersenne", "P. Bs"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_190 :
	true positives : [] 
	false positives : ["Allier abonde"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_533 :
	true positives : ["Euryopis acuminata", "Olios c\u00e6nobita", "Cyclosa turbinata", "Meta merianae"] 
	false positives : [] 
	false negatives : ["Meta merian\u00e6"] 
	precision = 100.00 %
	recall = 80.00 %
	F-measure = 88.89 %
Evaluation of the article : page_389 :
	true positives : [] 
	false positives : ["usager constatera", "Aussile radiophonographe", "Dextrine blonde", "Mantes via", "Emme memes", "Puszta hongroise", "Fata Morgana", "E. Darmois", "P. Buxyer", "E. Fazz", "E. Chiron"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_297 :
	true positives : [] 
	false positives : ["Permutite alcaline", "-viela solubilisation", "Agro romano", "Bonifica della", "Lago Lunga", "Fore apoenne", "Volsques porta", "Appius Claudius", "Regina Viarum", "Via Appia", "Linea Pia", "Linea Pia", "Pontins assainis", "Fosso Moscarello", "Linea Pia", "Piazza Daittorio", "Agro Pontino", "Littoria abrite", "Lua pula", "synchronisation Bston", "A. Chaplet"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_104 :
	true positives : ["Cebus paraguayensis"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_18 :
	true positives : ["Alligator mississipiensis"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_412 :
	true positives : ["Ursus arctos"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_287 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_99 :
	true positives : ["Medicago sativa", "Raphanus raphanistrum", "Sinapis arvensis", "Medicago falcata"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_581 :
	true positives : [] 
	false positives : [] 
	false negatives : ["\u00c6Echinocactus ingens"] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_165 :
	true positives : [] 
	false positives : ["Kirghises nomades", "Iraniens samanides", "Pelouze accepta", "Pelouze accepta"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_98 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_100 :
	true positives : [] 
	false positives : ["Babbage tenta", "Quevedo apporta"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_414 :
	true positives : [] 
	false positives : ["Violle proposa", "Kotaro Honda", "Kotaro Honda"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_558 :
	true positives : ["Ovis studeri", "Hydroch\u0153rus capybara"] 
	false positives : ["legon amena", "Chiare jresche", "Friquets abrite"] 
	false negatives : [] 
	precision = 40.00 %
	recall = 100.00 %
	F-measure = 57.14 %
Evaluation of the article : page_56 :
	true positives : ["Homo capensis", "Homo sapiens", "Elephas antiquus", "Elephas antiquus", "Elephas antiquus", "Hippopotamus amphibius", "Pelorovis oldowayensis", "Elephas antiquus", "Pelorovis oldowayensis", "Equus (Hippotigris) Hollisi", "Rhinoceros bicornis", "Hippopotamus amphibius", "Procavia abyssinica", "Homo mediterraneus", "Homo sapiens", "P. Mackinderi"] 
	false positives : ["Knysna implique", "Lalla Marnia", "Caton Thompson", "Homo afer", "R. Broom", "R. Drennan", "H. Wells", "R. Broom", "H. Vallois", "R. Drennan", "R. Dart", "R. Broom", "R. Drennan", "H. Wells", "H. Wells", "E. Salmons", "H. Wells", "R. Drennan", "H. Vallois", "H. Vallois", "H. Reck", "H. Reck", "P. Brookes", "E. Bleek", "E. Blecck", "P. Culwick", "E. Bleek", "C. Arambourg", "E. Garrod", "H. Obermaier", "H. Vallois", "H. Vallois", "E. Garrod", "E. Garrod", "C. Arambourg", "L. Joreaun"] 
	false negatives : ["Buffelus Bainu", "Hippopotamus amphibius gorgops", "Bu\u00ffffelus antiquus", "P. \u00c6Erlangeri", "Homo afer taganus"] 
	precision = 30.77 %
	recall = 76.19 %
	F-measure = 43.84 %
Evaluation of the article : page_6 :
	true positives : ["Homo sapiens", "Homo sapiens", "Homo sapiens", "Homo capensis", "Homo sapiens", "Homo sapiens", "Sinanthropus pekinensis", "Homo sapiens", "Homo sapiens", "Homo neanderthalensis", "Homo sapiens", "Homo sapiens", "Homo palestinus", "Homo sapiens"] 
	false positives : ["Quina ftraits", "antiquus Recki", "Homo (Palaeanthropus) neanderthalensis", "Homo (Javanthropus) soloensis", "Hippopotame hexaprotodonte", "Hippopotame hexaprotodonte", "H. Reck", "H. Breuil"] 
	false negatives : ["\u00c2omo sapiens", "\u00c6Elephas antiquus"] 
	precision = 63.64 %
	recall = 87.50 %
	F-measure = 73.68 %
Evaluation of the article : page_204 :
	true positives : ["Saccharum officinarum", "Solanum iuberosum", "Solanum luberosum", "Solanum stoloniferum", "Solunum Fendleri", "Solanum tuberosum", "Solanum stoloniferum", "Solanum tuberosum", "S. longiconicum", "S. pinnasectum"] 
	false positives : ["Copper Corporation", "acceptum Viennae", "Papas peruanum", "Costa Rica"] 
	false negatives : [] 
	precision = 71.43 %
	recall = 100.00 %
	F-measure = 83.33 %
Evaluation of the article : page_241 :
	true positives : [] 
	false positives : ["voudrais crier"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_267 :
	true positives : [] 
	false positives : ["Florine iype", "Florine montrera", "Hispano Suiza", "Katanga abonde", "Contacter electrique"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_237 :
	true positives : ["Fraxinus excelsior", "Onthophagus taurus", "Onthophagus taurus", "Pistacia terebinihus", "Pistacia terebinthus", "Pistacia terebinthus", "Pistacia terebinthus", "Valgus hemipterus", "Valgus hemipterus", "Valgus hemipierus", "Onthophagus taurus"] 
	false positives : ["Julius Sunyer", "Palpes maxillaires", "Mandibules membraneuses", "Palpes labiales", "J. Guichard"] 
	false negatives : [] 
	precision = 68.75 %
	recall = 100.00 %
	F-measure = 81.48 %
Evaluation of the article : page_36 :
	true positives : ["Pyrophorus noctilucus"] 
	false positives : [] 
	false negatives : ["P: noctilucus"] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_262 :
	true positives : ["Azorella antipoda", "Ac\u0153\u00e6na affinis", "Festuca Kerguelensis", "Thuya tetragona", "Thuya tetragonia", "Araucaria imbricata", "Pringlea antiscorbutica", "Festuca Kerguelensis", "Azorella Selago", "Barbula validinervis", "Grimmia cupularis", "Campylopus austro-siramineus", "Campylopus austro-stramineus", "Drepanocladus uncinatus", "Placodium mexicanum", "Neuropogon trachycarpus", "Galera tenera", "Macrocystis pyrifera", "A. Selago", "A. patagonica", "A. trifurcata", "C. stramineus", "N. trachycarpus", "N. trachycarpus"] 
	false positives : [] 
	false negatives : ["A.trifoliata", "\u00c0. antipoda"] 
	precision = 100.00 %
	recall = 92.31 %
	F-measure = 96.00 %
Evaluation of the article : page_189 :
	true positives : ["Manta brevirostra"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_582 :
	true positives : [] 
	false positives : ["della Preta", "Minimas mensuelles", "Julius Springer", "J. Chaussin", "J. Cnaussin"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_188 :
	true positives : ["Allium sativum"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_602 :
	true positives : ["Welwitschia mirabilis", "Wekwitschia mirabilis"] 
	false positives : ["Citernes amovibles", "Isolants calorifuges", "Citernes amovibles", "Isolants calorifuges", "Does sms", "Isolants calorifuges", "Citernes amovibles", "C. Jose"] 
	false negatives : [] 
	precision = 20.00 %
	recall = 100.00 %
	F-measure = 33.33 %
Evaluation of the article : page_288 :
	true positives : ["Indigofera tinctoria"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_75 :
	true positives : ["Helolontha fullo", "Melolontha fullo"] 
	false positives : ["Exner distingua"] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_286 :
	true positives : ["Pegomyia hyosciama"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_327 :
	true positives : [] 
	false positives : ["Pravda Vostoka", "Xavier Marmier", "Ergebnisse geologischer", "selcnla chanson", "X. Marmier", "E. Douszer", "E. Schweizerbart", "E. Bowes", "E. Esclangon", "P. Liau", "P. Liau"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_326 :
	true positives : ["Cetorhinus maximus", "Dinemoura producta", "Nemesis lamna", "Dinobothrium plicitum"] 
	false positives : ["porco monstroso", "horribilibus monstris", "Litiorum Norvegiae"] 
	false negatives : [] 
	precision = 57.14 %
	recall = 100.00 %
	F-measure = 72.73 %
Evaluation of the article : page_502 :
	true positives : [] 
	false positives : ["Tendilha Retha", "Ailas linguistique", "Variantes juqguoir", "neutraliser laction", "Ungerva ravitailleur", "A. Piccard"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_561 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %

overall scores on the corpus vol126:
	precision = 40.83 %
	recall = 88.27 %
	F-measure = 55.83 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## starting evaluation of volume vol12
Evaluation of the article : page_138 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_82 :
	true positives : ["aspidosperma Gomesianum"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_232 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_387 :
	true positives : [] 
	false positives : ["Casola Valsenio", "Casola Valsenio", "Casola Valsenio", "Casola Valsenio"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_139 :
	true positives : ["Gentiana glacialis", "Daphne cn\u00e6orum"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_212 :
	true positives : ["Cofinga maynana", "Guacamaya colorada", "Troyon pavoninus", "Tinnunculus sparverius"] 
	false positives : ["Panache maure", "Pine preneur"] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_83 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_155 :
	true positives : [] 
	false positives : ["Deville consacre", "Cosmos esi", "Veufs avecenfants"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_91 :
	true positives : [] 
	false positives : ["guerrier Osycba", "Hache pahouine"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_310 :
	true positives : ["Solanum laciniatum"] 
	false positives : ["Nouka Hiva", "Foyage aulour"] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_147 :
	true positives : [] 
	false positives : ["Prosper Guyor"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_118 :
	true positives : ["Bathynomus giganteus"] 
	false positives : ["Isopodes marcheurs", "Cymothoadiens errants", "Cymothoadiens errants"] 
	false negatives : [] 
	precision = 25.00 %
	recall = 100.00 %
	F-measure = 40.00 %
Evaluation of the article : vol12_page_51 :
	true positives : ["Elephas primigenius", "Rhinoceros lichorinus", "Bos urus", "B. priscus", "B. latifrons", "B. europ\u0153us", "B. primigenius", "B. trachoceras", "B. frontosus", "B. longifrons", "B. brachyceras", "B. brachycephalus"] 
	false positives : ["iaurus ligeriensis", "taurus jurassicus", "laurus balavicus", "taurus alpinus", "B. iaurus", "B. taurus", "B. laurus", "B. taurus", "R. Viox"] 
	false negatives : ["B, antiquus", "B, primigenius", "B. iaurus ligeriensis", "B. taurus jurassicus", "B. laurus balavicus", "B. taurus alpinus"] 
	precision = 57.14 %
	recall = 66.67 %
	F-measure = 61.54 %
Evaluation of the article : page_108 :
	true positives : [] 
	false positives : ["ultima ratio"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_328 :
	true positives : ["Epidendrum Vanilla", "Vanilla aromatica", "Vanilla sativa", "Vanilla planifolia", "Oclomeria graminifolia", "Brassavola cordata", "Angr\u00e6cum fragrans", "V. quianensis", "V. palmarum", "V. planifolia", "V. Pompona"] 
	false positives : [] 
	false negatives : ["\u0178. aromatica"] 
	precision = 100.00 %
	recall = 91.67 %
	F-measure = 95.65 %
Evaluation of the article : page_230 :
	true positives : ["Cinnyris Adalberti", "Semnopithecus monspessulanus"] 
	false positives : ["Gervais aborda", "Pal\u00e6otheriums parlsiens", "P. Gervais", "P. Gervus"] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_221 :
	true positives : [] 
	false positives : ["Pacide borique", "Agenda vade", "Wilkes emmena", "Spectacles selentifiques"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_420 :
	true positives : ["Rhinocerus tichorhinus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_113 :
	true positives : [] 
	false positives : ["tophasma Dumasi"] 
	false negatives : ["Pro: tophasma Dumasi"] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_390 :
	true positives : [] 
	false positives : ["Varialions nocturnes"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_312 :
	true positives : [] 
	false positives : ["Bruchus obfectus"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_12 :
	true positives : [] 
	false positives : ["chapska polonais", "Lapons nomades", "Lapons blonds", "Iowa Weaiher", "Andamento diurno", "Domenico Racowa", "Chabrier appuya", "Sie mens", "Memoria sobre", "sistema metrico", "I. Bierzy", "D. Appleton", "C. Towwe", "L. Paruierr", "L. Muybridge", "A. Seccyt"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_148 :
	true positives : ["Sarracenia purpurea"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_104 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_251 :
	true positives : [] 
	false positives : ["usum delphini", "Figuier aspire", "Finitiative individuelle", "Pantzer sombra", "Aevues hebdomadaires", "Batraciens anoures", "Gutte parcelle", "Drauings made", "Moss abonde", "Triton alpestre", "A. Young", "D. Cassini", "A. Varley", "P. Drnrnan", "A. Destrem", "P. Cravoe", "A. Secondement", "F. Iayez", "A. Guyard", "A. Agassis", "G. Tissaxnren"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_120 :
	true positives : [] 
	false positives : ["Rhizo Carpasso", "Mia Milia", "Brazza acheta", "Brazza renvoya", "Melchior Guillandinus"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_60 :
	true positives : ["Papilio Laglaizei", "Megalodon ensifer", "P. speciosa", "P. speciosa", "P. speciosa", "P. armata"] 
	false positives : ["Ilistoire naturelte", "P. grandis"] 
	false negatives : ["PHYLLOFHORA ARMATA", "Nyctalemon Urontes"] 
	precision = 75.00 %
	recall = 75.00 %
	F-measure = 75.00 %
Evaluation of the article : page_146 :
	true positives : ["Dasychira pudibunda"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_429 :
	true positives : ["phylloxora armiita"] 
	false positives : ["Etna sors", "Noctuclle piniperde", "Helminthes entozonires", "E. Frov", "E. Ovsraser", "E. Sauvace", "E. Sauvacr", "E. Trirar", "E. Conriuserr"] 
	false negatives : ["S\u00e9pedon h\u0153\u00e6machale"] 
	precision = 10.00 %
	recall = 50.00 %
	F-measure = 16.67 %
Evaluation of the article : vol12_page_151 :
	true positives : ["Eleotraqus reduncus", "Oryx leucoryx", "Oryx beisa", "Oryx gazella", "Damalis albifions", "Antilope albifions", "Damalis pygargi", "Antilope canna", "Tragelaphus scriplus", "Tragelaphus scriptus", "Tragelaphus decula", "Tragelaphus sylvaticus"] 
	false positives : ["eotragus arundinaceus", "Antilopes rousses", "Antilopes typiques", "Ganna rappclle", "Nilgaus offerts"] 
	false negatives : ["E/eotragus arundinaceus"] 
	precision = 70.59 %
	recall = 92.31 %
	F-measure = 80.00 %
Evaluation of the article : vol12_page_166 :
	true positives : [] 
	false positives : [] 
	false negatives : ["S\u00e9pedon h\u0153machate", "S\u00e9pedon h\u0153machate", "S\u00e9pedon h\u0153machate"] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_417 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_413 :
	true positives : ["Bacillus Rossi", "Enrycantha horrida", "Broussonetia papyrifolia", "Eurycantha calcarata", "E. Australis", "E. horrida", "E. echinata", "E. horrida"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_49 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_214 :
	true positives : ["Protum\u00e6ba prinitiva", "Myxasirum radians", "Protomyxa aurantiaca", "Protam\u00e6ba primitiva", "Bathybius H\u00e6ckeli", "H\u00e6ckelina gigantea", "Protomonas amyli", "Protomonas gomphonematis", "Protomyxa aurantiaco", "Protomyxa aurantiaca", "Myxastrum radians", "Actinosph\u00e6rium Eichhornii"] 
	false positives : [] 
	false negatives : ["Protomyra ankyst\u00e9e", "Myxodiclium sociale", "Myxodictium sociale", "Pro\u00e9omyra auruntiaca", "Actinophrys sol", "Actinosph\u00e6rium E\u00efichhornii"] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : vol12_page_353 :
	true positives : [] 
	false positives : ["Torule ammoniacale", "Sacra Familia", "Cyclode noirjaune", "Volvox proprements", "Euglena sanguinea", "Astasia h\u0153matodes", "Monas prodigiosa", "Salping\u00e6ca Clarkii", "V. Dave", "T. Hamy", "V. Meyer", "E. Sauvacs", "S. Resort"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_68 :
	true positives : ["t\u0153nia mediocanellata"] 
	false positives : ["\u00e6nia solium", "\u00e6nia mediocanellata", "Dee mour"] 
	false negatives : ["{\u00e6nia solium", "{\u00e6nia mediocanellata"] 
	precision = 25.00 %
	recall = 33.33 %
	F-measure = 28.57 %
Evaluation of the article : vol12_page_56 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_8 :
	true positives : ["Eopteris Crier", "Eopteris Morierei"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_384 :
	true positives : ["Gastornis Edwardsi", "Gaslornis Edwardsi", "Gastornis minor", "Eupterornis remensis", "Heterodiadema Lybicum", "Holaster equiluberculatus", "Archiacia Saadensis", "Coptophyma problemalicum", "Heterodiadema Libycum", "Holaster senonensis", "Holaster pilula"] 
	false positives : ["Salenia Bainensis"] 
	false negatives : ["H\u00e9miaster Balorensis", "Goniopygus Messaoud"] 
	precision = 91.67 %
	recall = 84.62 %
	F-measure = 88.00 %
Evaluation of the article : vol12_page_351 :
	true positives : ["Vesperugo parisiensis", "Tenia solium", "Tenia perfoliata", "Tenia pectinata", "Tenia pectinala", "Cysticercus pisiformis", "Tenia serrata", "Tenia serrata", "Rumina decollata", "Pelobales fuscus", "Pelobates cullripes"] 
	false positives : ["Helminthes parasilaires"] 
	false negatives : ["Teniu perfoliata"] 
	precision = 91.67 %
	recall = 91.67 %
	F-measure = 91.67 %
Evaluation of the article : page_415 :
	true positives : ["Bos brachyceros", "Succharomyces quitulatus", "S. roseus"] 
	false positives : [] 
	false negatives : ["Saccharomyce Sminor"] 
	precision = 100.00 %
	recall = 75.00 %
	F-measure = 85.71 %
Evaluation of the article : vol12_page_347 :
	true positives : ["Tradescantia Virginica", "Stephanosph\u00e6ra pluvialis", "Magosph\u00e6ra planula", "Fucus vusiculusus", "\u0152dogonium gemelliparum", "Bulboch\u00e6te intermedia", "Nitella flexilis", "Funaria hygrometrica", "Sphagnum acutifohum", "Equiselum arvense", "Gonium pectorale", "Magosph\u00e6ra planuia", "Didymium leucojus", "Mugosph\u00e6ra adulle", "\u00c6thalium septicum", "Ceratium hydnoides", "Polysticta reticulata"] 
	false positives : ["th\u0153\u00e6a rosea", "Adianthum capillus"] 
	false negatives : ["Adianthum capillus veneris", " Volvoz globator", "Labyrinthula macrocystis"] 
	precision = 89.47 %
	recall = 85.00 %
	F-measure = 87.18 %
Evaluation of the article : page_422 :
	true positives : ["Phyllophora armata", "phyllophora armata"] 
	false positives : ["Telminthes entozoaires", "Noctuelle piniperde", "Meptiles peumiens", "Noctuelle piniperde", "P. Gower", "P. Gower"] 
	false negatives : ["S\u00e9pedon h\u0153machale", "s\u00e9p\u00e9don h\u0153machate"] 
	precision = 25.00 %
	recall = 50.00 %
	F-measure = 33.33 %
Evaluation of the article : page_143 :
	true positives : [] 
	false positives : ["Junonia minor", "Thedisio Doria", "Castille envoya", "Fernando Peraza", "Diego Silva"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_246 :
	true positives : ["Gromia oviformis", "Globigerina builoides", "Antmalina hemisph\u00e6rica", "Rosalina anomala", "Lagenuiina costata", "Dentalina punctata", "Cristellaria iriangularis", "Rotalia Venela", "Cornuspira planorbis", "Mihota flenera", "Arachnocorys circumlexta", "Amphilonche heteracanta", "Doratospis polyanuystra", "Cuchilonia Beckmanni"] 
	false positives : [] 
	false negatives : ["Aca\u00efthometra elaslica"] 
	precision = 100.00 %
	recall = 93.33 %
	F-measure = 96.55 %
Evaluation of the article : vol12_page_53 :
	true positives : ["Trachea piniperda"] 
	false positives : ["Noctuelle puuperde", "Noctuelle piniperde", "Noctuelle piniperde"] 
	false negatives : [] 
	precision = 25.00 %
	recall = 100.00 %
	F-measure = 40.00 %
Evaluation of the article : page_102 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_100 :
	true positives : ["Bathynomus qiyanteus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_103 :
	true positives : ["Antilope dama", "Gazslle dama", "Gazelle mobhr", "Gazelle dama", "Gazelle mohr", "Gazelle euchore", "Gazelles euchores", "Gazelle euchore", "Antilope bezoartica", "G. Soemmeringi"] 
	false positives : ["Cafres cherchentils"] 
	false negatives : ["Gazelle Granli", "G.euchore"] 
	precision = 90.91 %
	recall = 83.33 %
	F-measure = 86.96 %
Evaluation of the article : vol12_page_54 :
	true positives : ["Elaphurus Davidianus", "Capra dorcas", "Antilope dorcas", "Gazelle dorcas", "Gazelle dorcas", "Gazelle dorcas", "Gazelle dorcas", "Gazelle dorcas", "G. isabella", "G. Cuvieri"] 
	false positives : ["Antilopes bovines", "Antilopes reconnaissables", "Antilopes eervines", "Antilopes caprines", "Kemas odgsoni", "Gazelle isabelle", "Gazelle corinne", "Antilope mohr", "E. Ousrazer", "E. Gray"] 
	false negatives : ["lG. rufifrons"] 
	precision = 50.00 %
	recall = 90.91 %
	F-measure = 64.52 %
Evaluation of the article : page_48 :
	true positives : ["Lamprocolius nitens"] 
	false positives : ["Gasrox Tissanbier"] 
	false negatives : ["Lamprocolius iris"] 
	precision = 50.00 %
	recall = 50.00 %
	F-measure = 50.00 %
Evaluation of the article : page_421 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_96 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_241 :
	true positives : [] 
	false positives : ["Paiguille recule", "Hhonune ivre", "Alexandrette centralise"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_235 :
	true positives : ["Orchis pyramidulis", "Orchis intacta", "Callleya Epidendrum", "Limodorum abortivum", "Cypripedium barbalum", "Colax jugosus", "Epidendrum \u00e6mulum", "Trichopilia tortilis", "Ansellia africana", "Calypso borealis", "Neottia ovala", "Orchis conopsea", "Arethusa bulbosa", "Spiranthes diuretica", "Chlor\u0153a disoidea", "Cypripsdium pubescens", "Angr\u00e6cum fragrans", "S. macrautha", "C. guttatum"] 
	false positives : ["Blume rencontra", "ditum iridifolium", "C. Sprengel"] 
	false negatives : ["Neottia nidus-avis", "Neottia nidus-avis", "One'ditum iridifolium", "Orchis Mono", "PO. papilionccea", "Ophrys nidus-avis"] 
	precision = 86.36 %
	recall = 76.00 %
	F-measure = 80.85 %
Evaluation of the article : vol12_page_168 :
	true positives : [] 
	false positives : ["alluvion laissa", "Kane envahie", "Delemater tron", "Brazza poussa", "pestis indica", "Kalmouks nomades", "Obserles bourrasques", "O. Desvour"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_63 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_52 :
	true positives : [] 
	false positives : ["Repliles permiens"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_389 :
	true positives : [] 
	false positives : ["Geite irisation", "G. Tissannigr"] 
	false negatives : ["Mygale Pyrenaica"] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_106 :
	true positives : ["Cerithium latisulcatum", "Limopsis concentrica", "Cerithium latisulcatum", "Cerithium spiratum", "Cerithium spiratum", "Dentalium eburneum", "Dentalium eburneum", "Nummulites variolaria", "Dentalium eburneum", "Limopsis concentrica", "Cardita Bazini", "Cardium stampinense", "Cardium aviculinum"] 
	false positives : ["Quiconque renouvellera"] 
	false negatives : ["Dentalium Leoni\u00e6", "Dentalium Leoni\u00e6", "Dentalium Leoni\u00e6"] 
	precision = 92.86 %
	recall = 81.25 %
	F-measure = 86.67 %
Evaluation of the article : vol12_page_331 :
	true positives : [] 
	false positives : ["Mio Blanco", "Gastox Tissannier", "Cocilio Pujazon", "Brilo Capello", "Seynes conteste", "Tradescantia Virginica", "th\u0153\u00e6a rosea", "B. Wyse", "G. Cantoni"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_69 :
	true positives : [] 
	false positives : ["surnommer Bender"] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_167 :
	true positives : ["T\u00e6nia solium", "T\u00e6\u0153nia cucumerina", "T\u00e6nia Echinococcus"] 
	false positives : [] 
	false negatives : ["Trichodectes Canis", "Disfonum hepaticun", "D. lanceolatum"] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : vol12_page_379 :
	true positives : ["Euglena sanguinea", "Astasia h\u0153matodes", "Monas prodigiosa", "Salping\u00e6ca Clarkii", "Astasia h\u00e6matodes", "Phacus longicauda", "Euglena deses", "Stentor polymorphus", "Codosiga Botrytis", "Salping\u00e6ca Clarkii", "Dinobryon sertularia", "Uvella virescens", "Rhipidodendron splendidum", "Cephalothamnium Cyclopum", "Anlhophysa vegetans", "Dendromonas virgurie", "Cladomonas fruticulosa", "Poteriodendron petiolatum", "Noctiluca miliaris", "Notiluca miliaris", "Clepsidrina blattarum", "Gregarina gigantea", "Gregarina gigantea", "Gregarina gigantea"] 
	false positives : ["Volvox proprements", "terium digitatum", "orhynchus oligacanthus"] 
	false negatives : ["Hop'orhynchus oligacanthus"] 
	precision = 88.89 %
	recall = 96.00 %
	F-measure = 92.31 %
Evaluation of the article : page_137 :
	true positives : ["Verspertilio murinus"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_149 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_86 :
	true positives : ["Phyllorera vaslatrix", "Quercus pedunculata", "Vitis vinifera", "Schizoneura lanigera"] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %

overall scores on the corpus vol12:
	precision = 56.42 %
	recall = 81.45 %
	F-measure = 66.67 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## overall scores on the whole corpus:
	precision = 50.55 %
	recall = 83.29 %
	F-measure = 62.92 %
