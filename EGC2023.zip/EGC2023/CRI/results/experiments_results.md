expériences table 2
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 12:16:31 with classifier TAXREF and mode raw
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 37.00 %
	F-measure = 54.02 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 30.21 %
	F-measure = 46.40 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 33.82 %
	F-measure = 50.55 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 12:25:07 with classifier TAXREF and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 39.14 %
	F-measure = 56.26 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 34.72 %
	F-measure = 51.55 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 37.07 %
	F-measure = 54.09 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 12:33:42 with classifier LATIN and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 69.97 %
	recall = 66.97 %
	F-measure = 68.44 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 70.23 %
	recall = 72.92 %
	F-measure = 71.55 %
## overall scores on the whole corpus:
	precision = 70.10 %
	recall = 69.76 %
	F-measure = 69.93 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 12:37:01 with classifier ABS3 and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 87.71 %
	recall = 63.30 %
	F-measure = 73.53 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 93.27 %
	recall = 67.36 %
	F-measure = 78.23 %
## overall scores on the whole corpus:
	precision = 90.32 %
	recall = 65.20 %
	F-measure = 75.73 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 19:33:06 with classifier LATIN and mode A:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 62.82 %
	recall = 74.92 %
	F-measure = 68.34 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 64.24 %
	recall = 76.74 %
	F-measure = 69.94 %
## overall scores on the whole corpus:
	precision = 63.49 %
	recall = 75.77 %
	F-measure = 69.09 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 19:36:42 with classifier LATIN and mode A:mm:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 61.95 %
	recall = 81.65 %
	F-measure = 70.45 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 59.84 %
	recall = 77.08 %
	F-measure = 67.37 %
## overall scores on the whole corpus:
	precision = 60.97 %
	recall = 79.51 %
	F-measure = 69.02 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 11, 2022 at 21:24:25 with classifier ABS3 and mode A:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol83:
	precision = 37.95 %
	recall = 71.25 %
	F-measure = 49.52 %

overall scores on the corpus Processed_corpus/vol155:
	precision = 50.25 %
	recall = 70.14 %
	F-measure = 58.55 %
## overall scores on the whole corpus:
	precision = 42.81 %
	recall = 70.73 %
	F-measure = 53.34 %
# première expérience TAXREF (avec abbréviations)
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 01:31:15 with classifier TAXREF and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 34.72 %
	F-measure = 51.55 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 100.00 %
	recall = 13.89 %
	F-measure = 24.39 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 38.53 %
	F-measure = 55.63 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 100.00 %
	recall = 38.89 %
	F-measure = 56.00 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 31.02 %
	F-measure = 47.36 %
# première expérience TAXREF (sans abbréviations)
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 01:52:29 with classifier TAXREF and mode raw
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 34.72 %
	F-measure = 51.55 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 100.00 %
	recall = 13.89 %
	F-measure = 24.39 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 38.53 %
	F-measure = 55.63 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 100.00 %
	recall = 38.89 %
	F-measure = 56.00 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 31.02 %
	F-measure = 47.36 %
# expérience LINNAEUS
# expériences section 4.2
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 02:13:59 with classifier ABS7 and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 36.11 %
	F-measure = 53.06 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 100.00 %
	recall = 15.97 %
	F-measure = 27.54 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 41.28 %
	F-measure = 58.44 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 100.00 %
	recall = 43.89 %
	F-measure = 61.00 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 33.61 %
	F-measure = 50.31 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 03:12:32 with classifier ABS5 and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 40.97 %
	F-measure = 58.13 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 100.00 %
	recall = 26.39 %
	F-measure = 41.76 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 99.34 %
	recall = 45.87 %
	F-measure = 62.76 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 100.00 %
	recall = 53.33 %
	F-measure = 69.57 %
## overall scores on the whole corpus:
	precision = 99.77 %
	recall = 40.63 %
	F-measure = 57.74 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 03:48:14 with classifier ABS3 and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 40.29 %
	recall = 67.71 %
	F-measure = 50.52 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 31.63 %
	recall = 51.74 %
	F-measure = 39.26 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 32.76 %
	recall = 63.61 %
	F-measure = 43.24 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 22.66 %
	recall = 64.44 %
	F-measure = 33.53 %
## overall scores on the whole corpus:
	precision = 31.78 %
	recall = 61.68 %
	F-measure = 41.95 %
expérience amélioration ad-hoc
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 03:52:07 with classifier ABS3 and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 66.67 %
	recall = 61.11 %
	F-measure = 63.77 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 65.49 %
	recall = 51.39 %
	F-measure = 57.59 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 52.96 %
	recall = 63.00 %
	F-measure = 57.54 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 54.21 %
	recall = 64.44 %
	F-measure = 58.88 %
## overall scores on the whole corpus:
	precision = 59.10 %
	recall = 59.65 %
	F-measure = 59.37 %
expérience section 5
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 03:59:10 with classifier LATIN and mode A:MM:mm
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 2.51 %
	recall = 79.17 %
	F-measure = 4.86 %

overall scores on the corpus Processed_corpus/vol12:
	precision = 3.22 %
	recall = 75.35 %
	F-measure = 6.18 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 2.51 %
	recall = 81.96 %
	F-measure = 4.88 %

overall scores on the corpus Processed_corpus/vol126:
	precision = 1.58 %
	recall = 80.00 %
	F-measure = 3.09 %
## overall scores on the whole corpus:
	precision = 2.41 %
	recall = 79.13 %
	F-measure = 4.67 %
# expériences figure 1 LATIN
# expériences figure 1 TAXREF
# expériences table 2
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 04:14:40 with classifier TAXREF and mode raw
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 30.21 %
	F-measure = 46.40 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 37.00 %
	F-measure = 54.02 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 33.82 %
	F-measure = 50.55 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 04:21:37 with classifier TAXREF and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 100.00 %
	recall = 34.72 %
	F-measure = 51.55 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 100.00 %
	recall = 39.14 %
	F-measure = 56.26 %
## overall scores on the whole corpus:
	precision = 100.00 %
	recall = 37.07 %
	F-measure = 54.09 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 04:29:00 with classifier ABS3 and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 93.27 %
	recall = 67.36 %
	F-measure = 78.23 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 87.71 %
	recall = 63.30 %
	F-measure = 73.53 %
## overall scores on the whole corpus:
	precision = 90.32 %
	recall = 65.20 %
	F-measure = 75.73 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 04:31:36 with classifier ABS3 and mode A:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 50.25 %
	recall = 70.14 %
	F-measure = 58.55 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 38.11 %
	recall = 71.56 %
	F-measure = 49.73 %
## overall scores on the whole corpus:
	precision = 42.91 %
	recall = 70.89 %
	F-measure = 53.46 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 04:35:25 with classifier ABS3 and mode A:mm:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 39.92 %
	recall = 69.44 %
	F-measure = 50.70 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 36.84 %
	recall = 79.20 %
	F-measure = 50.29 %
## overall scores on the whole corpus:
	precision = 38.12 %
	recall = 74.63 %
	F-measure = 50.47 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 05:39:24 with classifier LATIN and mode A
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 70.23 %
	recall = 72.92 %
	F-measure = 71.55 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 69.97 %
	recall = 66.97 %
	F-measure = 68.44 %
## overall scores on the whole corpus:
	precision = 70.10 %
	recall = 69.76 %
	F-measure = 69.93 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 05:40:48 with classifier LATIN and mode A:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 64.24 %
	recall = 76.74 %
	F-measure = 69.94 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 62.82 %
	recall = 74.92 %
	F-measure = 68.34 %
## overall scores on the whole corpus:
	precision = 63.49 %
	recall = 75.77 %
	F-measure = 69.09 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on October 12, 2022 at 05:42:26 with classifier LATIN and mode A:mm:MM
----------------------------------------------------------------------------------------------------------

overall scores on the corpus Processed_corpus/vol155:
	precision = 59.84 %
	recall = 77.08 %
	F-measure = 67.37 %

overall scores on the corpus Processed_corpus/vol83:
	precision = 61.95 %
	recall = 81.65 %
	F-measure = 70.45 %
## overall scores on the whole corpus:
	precision = 60.97 %
	recall = 79.51 %
	F-measure = 69.02 %
