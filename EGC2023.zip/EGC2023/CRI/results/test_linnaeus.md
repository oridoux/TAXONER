# ----------------------------------------------------------------------------------------------------------
Experience launched on May 05, 2022 at 18:48:22
Chosen mode: union
----------------------------------------------------------------------------------------------------------
## starting evaluation of volume vol83
Evaluation of the article : page_611 :
	true positives : [] 
	false positives : [["jute", 725, 729], ["jute", 1482, 1486], ["sable", 2744, 2749], ["Aka", 43324, 43327]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_109 :
	true positives : [] 
	false positives : [["Argentine", 24060, 24069], ["Argentine", 24765, 24774], ["Argentine", 25321, 25330]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_472 :
	true positives : [] 
	false positives : [["Sable", 16553, 16558], ["Casse", 33270, 33275], ["casse", 33282, 33287], ["casse", 33432, 33437], ["casse", 33444, 33449]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_507 :
	true positives : [] 
	false positives : [["Axolotl", 7601, 7608], ["Axolotl", 7965, 7972]] 
	false negatives : [["Gigantosaurus africanus", 3678, 3701], ["G. robustus", 3705, 3716]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_218 :
	true positives : [["Vipera berus", 114, 126], ["Vipera aspis", 143, 155], ["Vipera aspis", 4811, 4823], ["Crotalus terrificus", 6778, 6797]] 
	false positives : [["Fer-de-lance", 3376, 3388], ["rats", 8452, 8456], ["chats", 8478, 8483]] 
	false negatives : [["Naja hiperdians", 1815, 1830], ["Lachesis lanceolatus", 3408, 3428]] 
	precision = 57.14 %
	recall = 66.67 %
	F-measure = 61.54 %
Evaluation of the article : page_232 :
	true positives : [] 
	false positives : [["sable", 22800, 22805], ["sable", 23715, 23720], ["sable", 24334, 24339], ["sable", 24378, 24383], ["sable", 28367, 28372], ["sable", 28609, 28614], ["sable", 35376, 35381], ["Casse", 76638, 76643]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_310 :
	true positives : [] 
	false positives : [["sables", 1994, 2000]] 
	false negatives : [["Rotalina orbicularis", 968, 988], ["Pupa similis", 2210, 2222], ["Pupa similis", 2604, 2616]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_122 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_139 :
	true positives : [] 
	false positives : [["dogs", 76129, 76133], ["rat", 77047, 77050]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_488 :
	true positives : [] 
	false positives : [["mastic", 2408, 2414], ["cat", 4760, 4763]] 
	false negatives : [["Cereus pitahaya", 588, 603]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_83 :
	true positives : [] 
	false positives : [["sables", 4578, 4584], ["sables", 6154, 6160], ["sable", 6594, 6599], ["sable", 7295, 7300], ["sable", 7400, 7405], ["sables", 8042, 8048], ["sable", 9218, 9223], ["sable", 9416, 9421], ["sable", 9747, 9752], ["sables", 10422, 10428], ["sables", 11051, 11057], ["sables", 11085, 11091], ["sable", 11145, 11150], ["Lion", 20957, 20961]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_537 :
	true positives : [] 
	false positives : [["Mans", 3794, 3798]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_655 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_654 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_569 :
	true positives : [["ide", 1206, 1209]] 
	false positives : [["Man", 842, 845], ["Tia", 3592, 3595]] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_550 :
	true positives : [] 
	false positives : [] 
	false negatives : [["yucca filamentosa", 6135, 6152], ["statice limonium", 6261, 6277], ["helianthus multiflorus", 6286, 6308], ["bocconia microcarpa", 6318, 6337], ["anemone japonica", 6509, 6525]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_489 :
	true positives : [] 
	false positives : [["Mans", 4502, 4506], ["Argentine", 15845, 15854], ["Lion", 30512, 30516], ["Lion", 30620, 30624], ["Lion", 30873, 30877], ["Lion", 34986, 34990], ["Lion", 35351, 35355], ["Lion", 35815, 35819], ["Lake", 69712, 69716], ["man", 72387, 72390], ["tare", 90879, 90883], ["lime", 90954, 90958], ["lime", 91331, 91335], ["lime", 91666, 91670], ["lime", 92056, 92060]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_60 :
	true positives : [["Bradypus tridactylus", 5179, 5199]] 
	false positives : [["Argentine", 105, 114], ["Argentine", 4994, 5003], ["chinchilla", 5112, 5122], ["tares", 6601, 6606]] 
	false negatives : [["Macrorhinus elephantinus", 1281, 1305], ["Canis jubatus", 5005, 5018]] 
	precision = 20.00 %
	recall = 33.33 %
	F-measure = 25.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [["tare", 29739, 29743], ["Sama", 46854, 46858], ["sables", 68076, 68082], ["sables", 73632, 73638], ["sables", 75658, 75664], ["sables", 76842, 76848], ["sable", 101658, 101663]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_530 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Cichorium intrbus", 2072, 2089]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_281 :
	true positives : [] 
	false positives : [["LI", 3964, 3966], ["Niger", 50234, 50239], ["Niger", 50658, 50663]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_341 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Botr ylis bassiana", 2203, 2221], ["Sporotrichum globuliferum", 2228, 2253]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_176 :
	true positives : [["Amanita phalloides", 1587, 1605], ["Amanita phalloides", 1886, 1904], ["Amanita muscaria", 2307, 2323], ["Boletus edulis", 3744, 3758]] 
	false positives : [] 
	false negatives : [["Russula emetica", 1865, 1880], ["Lepiota procera", 2026, 2041], ["Balliota campestris", 2046, 2065]] 
	precision = 100.00 %
	recall = 57.14 %
	F-measure = 72.73 %
Evaluation of the article : page_105 :
	true positives : [] 
	false positives : [["lime", 3941, 3945]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_372 :
	true positives : [] 
	false positives : [["Argentine", 8820, 8829], ["argentines", 16903, 16913], ["Hyla arborea", 17724, 17736], ["Alytes obstetricans", 17766, 17785], ["Rat", 18702, 18705], ["chat", 21925, 21929], ["lions", 27379, 27384], ["casse", 38209, 38214], ["man", 39189, 39192], ["comptons", 97186, 97194]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_657 :
	true positives : [] 
	false positives : [["mum", 3342, 3345]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_35 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Rhizina inflata", 4293, 4308], ["Rhizina inflata", 4961, 4976]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_169 :
	true positives : [] 
	false positives : [["tare", 10818, 10822], ["tare", 11227, 11231], ["tares", 11306, 11311], ["tare", 14196, 14200], ["tares", 16274, 16279]] 
	false negatives : [["Mirabilis Jalappa", 3145, 3162], ["Mirabilis jalappa", 3396, 3413]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_570 :
	true positives : [] 
	false positives : [["citron", 31888, 31894], ["citron", 32212, 32218], ["mastic", 33916, 33922], ["Boas", 42619, 42623], ["Man", 42647, 42650], ["Oscar", 46789, 46794], ["sable", 64027, 64032], ["sable", 74139, 74144], ["sable", 74252, 74257]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_80 :
	true positives : [["Homarus americanus", 245, 263], ["Birgus latro", 676, 688], ["Nephrops norvegicus", 1127, 1146], ["Pandalus borealis", 2564, 2581]] 
	false positives : [["sables", 2485, 2491]] 
	false negatives : [["Pinnotheres pisum", 601, 618], ["Limnoria \u2018 lignorium", 1961, 1981], ["Limnoria ef des Chelura", 2087, 2110], ["Leander serra", 2403, 2416], ["Crangon vulgar is", 2493, 2510]] 
	precision = 80.00 %
	recall = 44.44 %
	F-measure = 57.14 %
Evaluation of the article : page_118 :
	true positives : [] 
	false positives : [["sables", 3793, 3799]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_164 :
	true positives : [["Grampus griseus", 2111, 2126], ["Grampus griseus", 2778, 2793]] 
	false positives : [["colo", 2963, 2967]] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_127 :
	true positives : [] 
	false positives : [["laver", 12982, 12987], ["Argentine", 33564, 33573]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_230 :
	true positives : [] 
	false positives : [["sable", 3895, 3900]] 
	false negatives : [["Raphidium nivale", 674, 690], ["Protococcus nivalis", 1199, 1218], ["Sph\u00e6rella \u2018mivalis", 1498, 1516], ["Sph\u00e6rella: lacustris", 1664, 1684], ["rococcus vulg\u00e4ris", 1758, 1775], ["Pteromonas nivalis", 4794, 4812], ["Ancylonema Nordenskioldii", 5129, 5154]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_652 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_348 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_406 :
	true positives : [["Danio rerio", 3673, 3684]] 
	false positives : [] 
	false negatives : [["Plerophy Ju scalare", 1726, 1745], ["Seatophagus arqUs", 1749, 1766], ["Heros | facetus", 2997, 3012], ["Mesonaula insignis", 3594, 3612], ["Herniramphus fluvia", 3641, 3660], ["Rasbora heteromorpha", 3690, 3710], ["Mo\u00eflienesia latipinna", 3719, 3740], ["Paratilapia multicolor", 4031, 4053]] 
	precision = 100.00 %
	recall = 11.11 %
	F-measure = 20.00 %
Evaluation of the article : page_81 :
	true positives : [["Cancer pagurus", 568, 582], ["Callinectes sapidus", 703, 722], ["Asellus aquaticus", 3217, 3234]] 
	false positives : [] 
	false negatives : [["Carcinus mo\u0153nas", 599, 614], ["Portunus puber", 628, 642], ["Eupagurus Bernhardus", 826, 846], ["Balanus psittacus", 1004, 1021], ["Pollicipes cornucopi\u00e6", 1190, 1211], ["Pinnotheres pisum", 2744, 2761], ["Limnoria lignorium", 3572, 3590], ["Chelura terebrans", 3643, 3660]] 
	precision = 100.00 %
	recall = 27.27 %
	F-measure = 42.86 %
Evaluation of the article : page_227 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Ornithodorus Savignyi", 2823, 2844], ["Ornithodorus moubaia", 2873, 2893], ["Solanum Luberosum", 3246, 3263]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_521 :
	true positives : [] 
	false positives : [["Argentine", 53417, 53426], ["sable", 53826, 53831], ["lions", 55178, 55183], ["Mans", 59216, 59220], ["Mans", 60252, 60256], ["Mans", 60841, 60845], ["Mans", 61201, 61205]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_470 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_211 :
	true positives : [["ficus carica", 1869, 1881]] 
	false positives : [["sable", 21, 26], ["sable", 245, 250]] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_116 :
	true positives : [["Polytrichum formosum", 3563, 3583], ["Polytrichum formosum", 6762, 6782], ["Polytrichum formosum", 8645, 8665], ["Polytrichum formosum", 10153, 10173]] 
	false positives : [] 
	false negatives : [["Desoria glacialis", 1816, 1833], ["Pellia epiphylla", 8341, 8357]] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : page_397 :
	true positives : [["Dionaea muscipula", 4583, 4600], ["Dionaea muscipula", 5113, 5130]] 
	false positives : [] 
	false negatives : [["Drosera rotundifolia", 444, 464], ["Drosera rotundifolia", 617, 637], ["Drosera rotundifolia", 1252, 1272], ["Drosera rotundifolia", 2243, 2263], ["Drosera rotundifolia", 2268, 2288], ["Drosera rotundifolia", 4445, 4465], ["Dionaca m\u00fcscipula", 1351, 1368], ["Pinguicula caudata", 3225, 3243], ["Drosera ratun", 4728, 4741], ["Apocynum androsoemifolium", 7765, 7790]] 
	precision = 100.00 %
	recall = 16.67 %
	F-measure = 28.57 %
Evaluation of the article : page_583 :
	true positives : [] 
	false positives : [["sable", 3641, 3646], ["mani", 5565, 5569], ["LI", 15015, 15017], ["man", 24819, 24822], ["osier", 43630, 43635], ["ale", 44244, 44247], ["man", 48595, 48598], ["Laver", 56973, 56978], ["Mum", 70458, 70461], ["rats", 78431, 78435], ["rats", 78735, 78739], ["lion", 83294, 83298], ["lion", 84310, 84314], ["chats", 85562, 85567], ["Lion", 106417, 106421], ["Lion", 106819, 106823], ["Lion", 107242, 107246], ["sable", 108329, 108334], ["Lion", 109973, 109977], ["sable", 111500, 111505], ["sable", 111554, 111559], ["sable", 111721, 111726], ["chats", 113416, 113421], ["chats", 113533, 113538], ["sable", 115718, 115723], ["Culebra", 128740, 128747], ["Culebra", 129301, 129308], ["man", 130482, 130485], ["laver", 161186, 161191], ["sable", 164496, 164501], ["lake", 172410, 172414]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_649 :
	true positives : [] 
	false positives : [["Lion", 8296, 8300]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_508 :
	true positives : [] 
	false positives : [["laver", 2071, 2076], ["laver", 2990, 2995], ["laver", 3330, 3335]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_228 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_551 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Ceroxylon audicola", 130, 148], ["Copernicia cerifera", 480, 499], ["M. Cerifera", 1195, 1206], ["M. Carolinensis", 1208, 1223], ["M. Pensylvanica", 1225, 1240], ["M. Cordifolia", 1257, 1270], ["M. Quercifolia", 1272, 1286], ["M. Serrata", 1288, 1298], ["Rhus succedanea", 2084, 2099], ["Rhus vermicifera", 2126, 2142], ["Stillingia Sebifera", 2982, 3001]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_478 :
	true positives : [] 
	false positives : [] 
	false negatives : [["tradescantia virginica", 6446, 6468], ["geum urbanum", 6519, 6531], ["deutzia scabra", 6739, 6753]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_471 :
	true positives : [["Atriplex halimus", 3401, 3417], ["Atriplex nummularia", 3419, 3438], ["Casuarina equisetifolia", 3460, 3483], ["Tamarix gallica", 3719, 3734], ["Ficus carica", 3997, 4009], ["Punica granatum", 4070, 4085]] 
	false positives : [] 
	false negatives : [["Artemisia maritima", 3440, 3458], ["Ephedra alata", 3485, 3498], ["Hippoph\u00e6 rhamno\u00efdes", 3500, 3519], ["Juniperus macrocarpa", 3521, 3541], ["Melaleuca eri\u00e6\u0153folia", 3557, 3577], ["Phytolacca dio\u00efca", 3596, 3613], ["Ph\u0153nix tenuis", 3615, 3628], ["Ph\u0153nix dactylifera", 3630, 3648], ["Rhus viminalis", 3664, 3678], ["Salsola fruticosa", 3680, 3697], ["Tamarix articulata", 3699, 3717], ["Vitex agnus castus", 3736, 3754], ["Acacia-nilatica", 3821, 3836], ["Acacia cyclopis", 3838, 3853], ["Acacia cyanophylla", 3855, 3873], ["Albizzia lophauta", 3875, 3892], ["Prosopis dulcis", 3894, 3909], ["Casuarina quadrivalvis", 3911, 3933], ["Cupressus lambertiana", 3935, 3956], ["Eucalyptus robusta", 3958, 3976], ["Evonymus japonica", 3978, 3995], ["Pittosporum tobira", 4011, 4029], ["Phillyrea media", 4031, 4046], ["Parkinsonia aculeata", 4048, 4068], ["Statice arborea", 4093, 4108]] 
	precision = 100.00 %
	recall = 19.35 %
	F-measure = 32.43 %
Evaluation of the article : page_555 :
	true positives : [] 
	false positives : [["bovine", 4644, 4650], ["Lime", 18166, 18170]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_278 :
	true positives : [["Hydra fusca", 9533, 9544], ["Daphnia similis", 9784, 9799]] 
	false positives : [["sable", 618, 623], ["mastic", 988, 994], ["sable", 7541, 7546], ["axolotls", 11639, 11647]] 
	false negatives : [["Branchipus stagnalis", 9686, 9706], ["Apus productus", 9711, 9725], ["Gammarus n\u00e9giectus", 9843, 9861], ["Nepa cinerea", 10105, 10117]] 
	precision = 33.33 %
	recall = 33.33 %
	F-measure = 33.33 %
Evaluation of the article : page_120 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Palinurus regius", 5766, 5782], ["Temnodon sallator", 6471, 6488], ["Dentiex macro phthalmus", 7402, 7425], ["Dentex maroccanus", 7781, 7798], ["Temnodon Sallaior", 7848, 7865], ["Beryx decadactylus", 7881, 7899], ["Berg decadactylus", 8607, 8624]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_252 :
	true positives : [["B. musculus", 910, 921], ["B. borealis", 944, 955]] 
	false positives : [] 
	false negatives : [["Bal\u00e6noptera Sibbaldii", 877, 898]] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : page_424 :
	true positives : [] 
	false positives : [["Lion", 1011, 1015], ["Niger", 27036, 27041], ["Sardine", 62087, 62094], ["ginkgo", 65511, 65517], ["sardine", 80145, 80152], ["Ginkgo", 82748, 82754]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_648 :
	true positives : [["Helix pomatia", 7167, 7180]] 
	false positives : [["chats", 4262, 4267]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_610 :
	true positives : [["P. nigrescens", 3130, 3143]] 
	false positives : [] 
	false negatives : [["Polysiphonia Brodiaei", 3107, 3128], ["Rhodomela su\u00fcbfusca", 3147, 3166], ["Batrachospermum Gallaer", 3597, 3620], ["Demanea fluviatilis", 3624, 3643], ["Ceramium rubrum", 3869, 3884]] 
	precision = 100.00 %
	recall = 16.67 %
	F-measure = 28.57 %
Evaluation of the article : page_531 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_101 :
	true positives : [["Pyrethrum", 1161, 1170], ["Pyrethrum", 1843, 1852]] 
	false positives : [] 
	false negatives : [["Chr ysanthemum leucanthemum", 404, 431], ["Pulicaria vulqaris", 715, 733], ["P. roseum", 1182, 1191]] 
	precision = 100.00 %
	recall = 40.00 %
	F-measure = 57.14 %
Evaluation of the article : page_451 :
	true positives : [] 
	false positives : [["Lion", 5408, 5412]] 
	false negatives : [["Zirphaea {Pholas] cristata", 3601, 3627], ["Saxicava rugosa", 3635, 3650]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_351 :
	true positives : [["Ginkgo biloba", 1851, 1864], ["Ginkgo biloba", 5513, 5526], ["Ginkgo biloba", 8224, 8237]] 
	false positives : [["Ginkgo", 1497, 1503], ["Ginkgo", 1656, 1662], ["Ginkgo", 2319, 2325], ["Ginkgo", 3625, 3631], ["Ginkgo", 5490, 5496], ["Ginkgo", 6961, 6967], ["Ginkgo", 6979, 6985], ["Ginkgo", 8258, 8264], ["Ginkgo", 8441, 8447], ["Ginkgo", 8609, 8615], ["Ginkgo", 8983, 8989], ["Ginkgo", 9357, 9363], ["Ginkgo", 9676, 9682], ["Ginkgo", 9689, 9695]] 
	false negatives : [] 
	precision = 17.65 %
	recall = 100.00 %
	F-measure = 30.00 %
Evaluation of the article : page_192 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Littorina littoralis", 2811, 2831]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_534 :
	true positives : [["ficus carica", 3200, 3212]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_369 :
	true positives : [] 
	false positives : [["Rats", 4837, 4841]] 
	false negatives : [["Arvicola agrestis", 119, 136], ["Mus sylvaticus", 161, 175], ["B. Typhi murium", 8913, 8928]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_535 :
	true positives : [["Eucalyptus globulus", 6301, 6320], ["quassia amara", 6999, 7012], ["quassia amara", 7099, 7112]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_95 :
	true positives : [] 
	false positives : [["sable", 12313, 12318], ["sable", 14631, 14636]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_510 :
	true positives : [["galega officinalis", 5070, 5088], ["Diomedea exulans", 7503, 7519], ["Megalobatrachus japonicus", 11359, 11384], ["Arapaima gigas", 11723, 11737]] 
	false positives : [] 
	false negatives : [["Mistichthys luzonensis", 5720, 5742], ["Bal\u00e6noptera sibbaldi", 5901, 5921], ["Microsorex minnemana", 6172, 6192], ["Blarina parva", 6283, 6296], ["Calypte kelen\u00e6", 6931, 6945], ["Sph\u00e6rodactylus sputator", 7614, 7637], ["$. notatus", 7742, 7752], ["Varanus saltator", 7837, 7853], ["aspergilluss fumigatus", 9382, 9404], ["Arthroleptis sechellensis", 11132, 11157], ["Hyla Pickeringi", 11254, 11269], ["Acanthophacelus bifurcus", 11577, 11601], ["Carcharodon Rondeletii", 11890, 11912], ["Oospora pulmonalis", 12987, 13005], ["Rhizomucor parasiticus", 13330, 13352], ["Mucor corymbifer", 13357, 13373]] 
	precision = 100.00 %
	recall = 20.00 %
	F-measure = 33.33 %
Evaluation of the article : page_452 :
	true positives : [] 
	false positives : [["laver", 11913, 11918], ["ide", 14003, 14006], ["Mans", 23399, 23403], ["laver", 26284, 26289], ["man", 30637, 30640], ["Boas", 36047, 36051], ["sable", 53524, 53529], ["sable", 56775, 56780], ["argentines", 89547, 89557], ["Rat", 94095, 94098]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_568 :
	true positives : [["quassia amara", 1530, 1543]] 
	false positives : [["bovines", 5651, 5658]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_519 :
	true positives : [] 
	false positives : [["rats", 6196, 6200], ["rats", 6745, 6749], ["rats", 7062, 7066], ["Argentine", 11741, 11750], ["Niger", 12525, 12530]] 
	false negatives : [["Eriocampa limacina", 4828, 4846]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_486 :
	true positives : [["Cimex lectularius", 2976, 2993]] 
	false positives : [["anthrax", 3619, 3626], ["citron", 4041, 4047], ["citron", 5111, 5117], ["citron", 5426, 5432]] 
	false negatives : [["Acanthia lectularia", 2997, 3016]] 
	precision = 20.00 %
	recall = 50.00 %
	F-measure = 28.57 %
Evaluation of the article : page_186 :
	true positives : [] 
	false positives : [["clines", 15777, 15783]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_311 :
	true positives : [] 
	false positives : [["manioc", 10874, 10880]] 
	false negatives : [["bacillus butylicus", 10383, 10401], ["bacillus orthobutylicus", 10617, 10640]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_543 :
	true positives : [] 
	false positives : [["laver", 4181, 4186]] 
	false negatives : [["Zeus\u00e8ra \u00e6sculi", 6045, 6059], ["Cossus ligniperda", 6648, 6665]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_264 :
	true positives : [] 
	false positives : [["Mans", 5840, 5844], ["sable", 13444, 13449], ["sable", 18735, 18740], ["sable", 18893, 18898], ["sable", 19648, 19653], ["mastic", 33352, 33358], ["sable", 37481, 37486], ["sable", 37865, 37870], ["ellipse", 48168, 48175]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_342 :
	true positives : [] 
	false positives : [["sables", 12140, 12146], ["sable", 13407, 13412], ["sables", 14991, 14997], ["sables", 15077, 15083], ["sables", 15186, 15192]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_422 :
	true positives : [] 
	false positives : [["sable", 425, 430]] 
	false negatives : [["Libellula depressa", 5903, 5921]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_166 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_212 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_102 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_302 :
	true positives : [] 
	false positives : [["ber", 596, 599]] 
	false negatives : [["Eumenes coarctatus", 738, 756], ["Eumenes coarclatus", 1638, 1656], ["Euinenes unguiculus", 1674, 1693], ["Odynevus spinipes", 1711, 1728], ["Celonites abbreviatus", 1768, 1789], ["Odyner us spinipes", 2454, 2472], ["Belenogaster junceuset", 3495, 3517], ["Polistes gallicus", 3533, 3550], ["Polistes gallicus", 8267, 8284], ["Leipomeles lamellaria", 4110, 4131], ["Leipomeles lamellaria", 14294, 14315], ["Prolopolybia emoTtualis", 4156, 4179], ["Polybia dimidiaia", 4193, 4210], ["Polybia rejecta", 4269, 4284], ["Polybia rejecta", 15445, 15460], ["Polybia rejecta", 15867, 15882], ["Ceramius lusitanicus", 4845, 4865], ["Odynerus spinipes", 5015, 5032], ["Chelonites abbrevi\u00e4tus", 5619, 5641], ["Vespa germanica", 3567, 3582], ["Vespa germanica", 3595, 3610], ["Vespa germanica", 8644, 8659], ["Vespa media", 3631, 3642], ["Vespa media", 3656, 3667], ["Vespa media", 11164, 11175], ["Protopolybia emortualis", 13426, 13449], ["Protopolybia emortualis", 13939, 13962], ["Cassicus persicus", 15737, 15754]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_172 :
	true positives : [] 
	false positives : [["tare", 249, 253], ["tares", 2327, 2332], ["ellipse", 9176, 9183]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_487 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_512 :
	true positives : [] 
	false positives : [["Mans", 10492, 10496], ["Mans", 11778, 11782]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_632 :
	true positives : [["Saponaria officinalis", 2895, 2916]] 
	false positives : [["Ginkgo", 9524, 9530], ["Mans", 19047, 19051]] 
	false negatives : [["Luillaja Saponaria", 2280, 2298], ["Zuillaja Saponaria", 2813, 2831], ["castilloa elastica", 3593, 3611]] 
	precision = 33.33 %
	recall = 25.00 %
	F-measure = 28.57 %
Evaluation of the article : page_656 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Quillaja sapo", 1119, 1132], ["Schisotrypanum Cruzi", 5295, 5315]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_314 :
	true positives : [] 
	false positives : [["chamois", 36381, 36388], ["cow", 39202, 39205], ["sable", 40708, 40713], ["chat", 56515, 56519], ["Argentine", 74067, 74076], ["sable", 81991, 81996], ["sable", 84800, 84805], ["sable", 94326, 94331], ["sable", 97561, 97566], ["Sables", 100354, 100360]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_660 :
	true positives : [] 
	false positives : [["lime", 9766, 9770], ["citron", 15217, 15223], ["sable", 17132, 17137], ["sable", 17740, 17745], ["Axolotl", 41448, 41455], ["Chats", 42832, 42837], ["lion", 43304, 43308], ["lion", 45003, 45007], ["Lion", 47780, 47784], ["ass", 49107, 49110], ["Casse", 56206, 56211], ["casse", 56218, 56223], ["laver", 58321, 58326], ["laver", 58697, 58702], ["emu", 59247, 59250], ["pig", 59688, 59691]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_558 :
	true positives : [] 
	false positives : [["sables", 15635, 15641], ["Mans", 34101, 34105], ["sable", 37217, 37222], ["casse", 41291, 41296], ["Argentine", 44797, 44806], ["Argentine", 45162, 45171], ["Lion", 46834, 46838], ["laver", 66209, 66214]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_346 :
	true positives : [] 
	false positives : [["Argentine", 624, 633], ["Argentine", 1119, 1128], ["Argentine", 2385, 2394], ["Argentine", 4237, 4246], ["Anthrax", 6055, 6062], ["Argentine", 6812, 6821], ["Argentine", 8738, 8747]] 
	false negatives : [["Shistocerca peregrina", 810, 831], ["Shis{ocerca americana", 981, 1002], ["Shistocerca americana", 1187, 1208], ["Micrococcus Acridiorum", 2646, 2668], ["Coccobacillus Acridiorum", 7580, 7604], ["Coccobacillus Acridiorum", 9292, 9316], ["Atta Sexdens", 9572, 9584]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_106 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Culex fatigans", 3913, 3927], ["Stegomya fasciata", 4457, 4474]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_408 :
	true positives : [] 
	false positives : [["Man", 33301, 33304], ["ale", 33376, 33379]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_177 :
	true positives : [] 
	false positives : [["ginkgo", 10366, 10372], ["sable", 23730, 23735]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_400 :
	true positives : [] 
	false positives : [["Argentine", 289, 298], ["man", 1714, 1717]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_405 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_480 :
	true positives : [] 
	false positives : [["Mans", 10372, 10376]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_353 :
	true positives : [] 
	false positives : [["chat", 48158, 48162], ["ass", 48520, 48523]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_466 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Chinoeletes opilio", 13206, 13224], ["Lithodes kamschatica", 13092, 13112]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_540 :
	true positives : [] 
	false positives : [["anthrax", 16509, 16516]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_634 :
	true positives : [] 
	false positives : [["ber", 3360, 3363], ["jute", 5230, 5234], ["jute", 5373, 5377], ["jute", 5561, 5565], ["jute", 6050, 6054], ["jute", 6485, 6489], ["jute", 6678, 6682], ["jute", 6943, 6947], ["chats", 9081, 9086], ["chats", 9215, 9220], ["chats", 9546, 9551], ["chats", 9908, 9913], ["chats", 10388, 10393], ["chats", 10535, 10540], ["tares", 31067, 31072], ["Mastic", 45486, 45492], ["ber", 58400, 58403], ["ide", 60086, 60089], ["tule", 78037, 78041], ["Lions", 79222, 79227], ["Storax", 93711, 93717], ["Storax", 93932, 93938], ["citron", 94039, 94045]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_183 :
	true positives : [["Corallina officinalis", 165, 186], ["Rhodymenia palmata", 1997, 2015], ["Fucus vesiculosus", 2616, 2633], ["Chondrus crispus", 4386, 4402]] 
	false positives : [["sable", 533, 538]] 
	false negatives : [["Lomentaria articulata", 66, 87], ["Padina Pavotia", 104, 118], ["Delesseria sanguinea", 2116, 2136], ["Laminaria Cloustoni", 2197, 2216], ["Callophyllis laciniata", 2237, 2259], ["Calliblepharis ciliata", 2654, 2676], ["Calliblepharis laciniata", 4247, 4271], ["Plocamium coccineum", 4284, 4303], ["Heterosiphonia coccinea", 4459, 4482], ["Ulva Lactuca", 2279, 2291]] 
	precision = 80.00 %
	recall = 28.57 %
	F-measure = 42.11 %
Evaluation of the article : page_36 :
	true positives : [] 
	false positives : [["ape", 4469, 4472], ["osier", 64973, 64978], ["tare", 66388, 66392], ["chamois", 74248, 74255], ["ass", 74302, 74305], ["sardine", 87616, 87623], ["sardine", 87706, 87713], ["sardines", 87796, 87804]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_658 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Parom\u00e6cium aurelia", 11397, 11415], ["Colpomenia sinuosa", 13638, 13656]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_262 :
	true positives : [["Hippopotamus amphibius", 3859, 3881], ["Hippopotamus amphibius", 6020, 6042], ["Hippopotamus", 6281, 6293], ["H. madagascariensis", 6491, 6510]] 
	false positives : [["osier", 2694, 2699], ["Hippopotamus", 5442, 5454], ["Niger", 7425, 7430], ["manioc", 8748, 8754]] 
	false negatives : [["H. minutus", 6326, 6336]] 
	precision = 50.00 %
	recall = 80.00 %
	F-measure = 61.54 %
Evaluation of the article : page_554 :
	true positives : [] 
	false positives : [["Churchill", 5335, 5344]] 
	false negatives : [["Gonioma Kamassi", 2854, 2869]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_622 :
	true positives : [] 
	false positives : [] 
	false negatives : [["veronica speciosa", 6770, 6787], ["helianthus rigidus", 6819, 6837], ["helianthus orgyalis", 6924, 6943]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_582 :
	true positives : [["polygonum cuspidatum", 6977, 6997]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_92 :
	true positives : [["P.papua", 3377, 3384]] 
	false positives : [] 
	false negatives : [["Catarrhactes chrysolophus", 1997, 2022], ["Catarrhactes chrysolophus", 3177, 3202], ["Pygoscelis antarctica", 2071, 2092], ["Pygoscelis antarctica", 3690, 3711], ["P, Adeli\u00e6", 2107, 2116], ["Aptenodytes Forsteri", 3342, 3362], ["Catarrhacteschrysolophus", 3388, 3412], ["P ygoscelis papua", 6585, 6602], ["Pygoscelis Adeli\u00e6", 7654, 7671]] 
	precision = 100.00 %
	recall = 10.00 %
	F-measure = 18.18 %
Evaluation of the article : page_257 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_479 :
	true positives : [] 
	false positives : [["tare", 610, 614]] 
	false negatives : [["uassia amara", 2056, 2068]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_623 :
	true positives : [] 
	false positives : [["Cotton", 8702, 8708], ["Culebra", 31515, 31522], ["ramie", 48769, 48774]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_552 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_651 :
	true positives : [["Falco tinnunculus", 7356, 7373]] 
	false positives : [["lion", 5063, 5067], ["lion", 5411, 5415], ["lion", 5781, 5785], ["jaguar", 5987, 5993], ["lion", 6067, 6071]] 
	false negatives : [["Aceipiter nisus", 7730, 7745], ["Astur.palumbarius", 7998, 8015], ["Buteo vulgaris", 8177, 8191]] 
	precision = 16.67 %
	recall = 25.00 %
	F-measure = 20.00 %
Evaluation of the article : page_194 :
	true positives : [] 
	false positives : [["sable", 747, 752], ["Lake", 2868, 2872], ["Lion", 21645, 21649], ["lion", 23342, 23346], ["lion", 23911, 23915], ["sables", 68888, 68894], ["sable", 69972, 69977], ["sable", 70426, 70431], ["sable", 71008, 71013], ["sable", 71112, 71117]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_103 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Phyteuma Villarsi", 3856, 3873], ["Phyt. Charmelii", 4505, 4520]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_538 :
	true positives : [] 
	false positives : [["limes", 2340, 2345], ["sable", 9173, 9178]] 
	false negatives : [["Xantophyllum lanceatum", 11633, 11655]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_306 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_124 :
	true positives : [["Betula nana", 7265, 7276]] 
	false positives : [["tares", 2147, 2152], ["tares", 2527, 2532], ["chat", 8910, 8914]] 
	false negatives : [["Pices berg", 2711, 2721], ["Picea esvention", 2804, 2819], ["Coronella austriaca", 7942, 7961], ["Cypripedium calceolus", 8442, 8463], ["Ophrys muscifera", 8469, 8485], ["Eryngium maritimum", 8244, 8262], ["Eryngium maritimum", 10258, 10276]] 
	precision = 25.00 %
	recall = 12.50 %
	F-measure = 16.67 %
Evaluation of the article : page_136 :
	true positives : [["Typha angustifolia", 11136, 11154]] 
	false positives : [["osier", 13662, 13667], ["jute", 13976, 13980], ["jute", 14048, 14052]] 
	false negatives : [["Carex stricta", 8230, 8243], ["Carex stricta", 9961, 9974], ["Carex stricta", 13372, 13385], ["Phragmites comcelle", 9979, 9998], ["Juncus obtusiflorus", 11158, 11177], ["Scirpus lacustris", 11183, 11200], ["Scirpus lacustris", 13516, 13533], ["Scirpus lacustris", 13571, 13588], ["Carex riparia", 13400, 13413], ["Scirpus lacus", 11183, 11196], ["Scirpus lacus", 13516, 13529], ["Scirpus lacus", 13546, 13559], ["Scirpus lacus", 13571, 13584], ["Carex .stricta", 13725, 13739]] 
	precision = 25.00 %
	recall = 6.67 %
	F-measure = 10.53 %
Evaluation of the article : page_222 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %

overall scores on the corpus vol83:
	precision = 16.50 %
	recall = 21.12 %
	F-measure = 18.53 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## starting evaluation of volume vol126
Evaluation of the article : page_472 :
	true positives : [] 
	false positives : [] 
	false negatives : [["ANTHOLCUS VARINERVIS", 1841, 1861], ["Ac\u00e6na sanguisorb\u00e6", 2512, 2529], ["Ac\u00e6na argentea", 3373, 3387], ["Ac\u00e6na argentea", 9368, 9382], ["Antholcus varinervis", 4156, 4176]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_381 :
	true positives : [] 
	false positives : [["Mate", 1476, 1480], ["citron", 2180, 2186]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_122 :
	true positives : [] 
	false positives : [["Aurochs", 194, 201], ["Aurochs", 430, 437], ["Aurochs", 1984, 1991], ["Aurochs", 2411, 2418], ["Citrons", 7049, 7056], ["citrons", 8689, 8696], ["tare", 10960, 10964], ["osier", 12389, 12394], ["osier", 12430, 12435], ["Pig", 15287, 15290], ["Gallego", 20934, 20941], ["sables", 31705, 31711], ["Canaries", 51168, 51176], ["cardinal", 54912, 54920], ["cardinal", 55258, 55266], ["casse", 58332, 58337], ["imbu", 66868, 66872], ["Lion", 83310, 83314], ["Lion", 87092, 87096]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_536 :
	true positives : [] 
	false positives : [["chats", 10877, 10882], ["lions", 10888, 10893], ["chats", 14600, 14605], ["chats", 14986, 14991], ["chats", 16648, 16653], ["lion", 18389, 18393], ["lion", 18403, 18407], ["lion", 18418, 18422], ["lion", 18481, 18485], ["lion", 18939, 18943], ["lions", 22670, 22675], ["Lion", 32081, 32085], ["sables", 51885, 51891], ["sable", 55024, 55029]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_160 :
	true positives : [] 
	false positives : [["sable", 48, 53], ["sable", 1160, 1165], ["Niger", 5510, 5515], ["sable", 8546, 8551], ["rat", 10681, 10684], ["sable", 18606, 18611], ["laver", 22515, 22520]] 
	false negatives : [["Perca latus", 3828, 3839], ["Perca latus", 6973, 6984], ["Sci\u00e6na umbra", 6939, 6951], ["Malapterurus electricus", 8735, 8758], ["Mormyre axyrhynaque", 13703, 13722], ["Mormyrus oxyrhynchus", 15039, 15059], ["Trigon vulgaris", 17600, 17615], ["Trigon lymne", 19119, 19131], ["Trygon Lymne", 19297, 19309]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_527 :
	true positives : [] 
	false positives : [["Niger", 5306, 5311], ["argentine", 5722, 5731], ["laver", 7201, 7206], ["Niger", 7340, 7345], ["argentines", 11158, 11168], ["argentine", 11237, 11246], ["Argentine", 12685, 12694], ["Argentine", 13109, 13118], ["Argentine", 13626, 13635], ["Argentine", 13852, 13861], ["Argentine", 14025, 14034], ["Argentine", 16255, 16264], ["Argentine", 16358, 16367], ["argentines", 17875, 17885], ["argentines", 23747, 23757], ["Argentine", 25776, 25785], ["Niger", 27580, 27585], ["argentine", 28212, 28221], ["Niger", 28336, 28341], ["Argentine", 29971, 29980], ["Argentine", 30321, 30330], ["Argentine", 30480, 30489], ["Argentine", 30659, 30668], ["Argentine", 31057, 31066], ["Niger", 31593, 31598]] 
	false negatives : [["Medicago satiwa", 13529, 13544], ["Atriplexz cachiyuyo", 14468, 14487], ["Atriplex semibaccata", 14491, 14511], ["Medicago faleaia", 14861, 14877], ["\u00c6Elephas meridionalis", 23908, 23929], ["Atriplez cachiyuyo", 28070, 28088]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_576 :
	true positives : [["Zostera marina", 19357, 19371], ["Z. marina", 19638, 19647]] 
	false positives : [["Cotton", 20998, 21004]] 
	false negatives : [["Z. nana", 19375, 19382], ["Z. nana", 19601, 19608], ["Z. nana", 22208, 22215]] 
	precision = 66.67 %
	recall = 40.00 %
	F-measure = 50.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_289 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_215 :
	true positives : [] 
	false positives : [["sables", 59668, 59674], ["sable", 59682, 59687], ["lion", 68810, 68814], ["lion", 72455, 72459], ["lion", 72502, 72506], ["lion", 72708, 72712], ["lion", 74922, 74926]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_386 :
	true positives : [] 
	false positives : [["Cat", 5163, 5166]] 
	false negatives : [["Carabus aurenitens", 3796, 3814], ["O\u00e9ypleurus Nodieri", 10191, 10209], ["Oxypleurus Nodieri", 11652, 11670]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_295 :
	true positives : [["Welwitschia mirabilis", 1773, 1794], ["Welwitschia mirabilis", 3543, 3564]] 
	false positives : [["sable", 6365, 6370], ["sables", 7064, 7070]] 
	false negatives : [["Welvitschia mirabilis", 3623, 3644], ["Odontopus sexpunctatus", 4930, 4952]] 
	precision = 50.00 %
	recall = 50.00 %
	F-measure = 50.00 %
Evaluation of the article : page_11 :
	true positives : [] 
	false positives : [["LI", 11, 13]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_80 :
	true positives : [] 
	false positives : [["sable", 7466, 7471]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_22 :
	true positives : [] 
	false positives : [["sables", 23610, 23616], ["sables", 23743, 23749], ["sable", 24583, 24588], ["sable", 25088, 25093]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_377 :
	true positives : [["Physeter macrocephalus", 1673, 1695], ["Grampus griseus", 8446, 8461], ["Orcinus orca", 8463, 8475], ["Delphinus delphis", 9329, 9346], ["Grampus griseus", 9438, 9453], ["Orcinus orca", 9850, 9862]] 
	false positives : [["sables", 1622, 1628], ["lion", 2169, 2173], ["sable", 14274, 14279], ["Lion", 15121, 15125], ["Canaries", 16561, 16569], ["Argentine", 17569, 17578]] 
	false negatives : [["Bal\u00e6noptera acutorostrata", 1714, 1739], ["Bal\u00e6na biscayensis", 1753, 1771], ["Bal\u00e6na biscayensis", 7422, 7440], ["Bal\u00e6noptera physalus", 7313, 7333], ["Delphis delphis", 8376, 8391], ["Phocaena phocaena", 8413, 8430], ["Globicephalus melas", 8490, 8509], ["Tursiops tursio", 8525, 8540], ["Tursiops tursio", 9908, 9923], ["Delphinus algeriensis", 8998, 9019], ["D. plombeus", 9087, 9098], ["Phoc\u00e6na phoc\u00e6na", 9350, 9365], ["llex Paraguayensis", 17048, 17066]] 
	precision = 50.00 %
	recall = 31.58 %
	F-measure = 38.71 %
Evaluation of the article : page_108 :
	true positives : [] 
	false positives : [["sables", 37750, 37756]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_283 :
	true positives : [["Sepia officinalis", 2905, 2922], ["Sepia officinalis", 2967, 2984], ["Petromyzon marinus", 8250, 8268]] 
	false positives : [["turbots", 9351, 9358], ["sable", 11754, 11759]] 
	false negatives : [["Petromyzon fluviatilis", 8190, 8212]] 
	precision = 60.00 %
	recall = 75.00 %
	F-measure = 66.67 %
Evaluation of the article : page_93 :
	true positives : [["M. americanus", 24863, 24876]] 
	false positives : [["sable", 13686, 13691], ["lions", 28592, 28597]] 
	false negatives : [["Manatus senegalensis", 24812, 24832], ["Arctocephalus antarcticus", 28625, 28650]] 
	precision = 33.33 %
	recall = 33.33 %
	F-measure = 33.33 %
Evaluation of the article : page_500 :
	true positives : [] 
	false positives : [["rats", 10117, 10121]] 
	false negatives : [["Scilla marilima", 10076, 10091]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_433 :
	true positives : [] 
	false positives : [["Morel", 13383, 13388], ["Lion", 39836, 39840], ["citron", 44822, 44828], ["Lion", 46528, 46532], ["Mans", 92476, 92480], ["laver", 99940, 99945], ["Argentine", 102119, 102128], ["sables", 106292, 106298], ["sable", 106511, 106516], ["sable", 111373, 111378], ["sable", 119904, 119909]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_64 :
	true positives : [] 
	false positives : [["tare", 24171, 24175], ["sable", 34696, 34701]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_551 :
	true positives : [] 
	false positives : [["Julia", 44, 49], ["Argentine", 2033, 2042], ["sable", 8763, 8768], ["sable", 10493, 10498], ["jute", 12165, 12169], ["sable", 12368, 12373]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_432 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Triodendron anfractuosum", 919, 943]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_120 :
	true positives : [["Bison bonasus", 1884, 1897], ["Bos primigenius", 1986, 2001]] 
	false positives : [["sables", 1563, 1569], ["bovine", 1681, 1687], ["Aurochs", 1977, 1984], ["Aurochs", 2452, 2459], ["Aurochs", 2474, 2481], ["Aurochs", 2550, 2557], ["Aurochs", 3534, 3541], ["Aurochs", 4943, 4950], ["Aurochs", 5651, 5658], ["Aurochs", 5885, 5892], ["Aurochs", 6141, 6148], ["Aurochs", 6229, 6236], ["aurochs", 6388, 6395], ["Aurochs", 6674, 6681], ["Aurochs", 6910, 6917], ["Aurochs", 8464, 8471], ["Aurochs", 8891, 8898]] 
	false negatives : [["Rhinoceros trichorhinus", 2189, 2212], ["Ursus spel\u00e6us", 2214, 2227]] 
	precision = 10.53 %
	recall = 50.00 %
	F-measure = 17.39 %
Evaluation of the article : page_475 :
	true positives : [] 
	false positives : [["man", 5478, 5481], ["lime", 73236, 73240], ["lime", 79171, 79175], ["lime", 91104, 91108], ["lime", 122356, 122360]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_146 :
	true positives : [] 
	false positives : [["casse", 8071, 8076], ["Argentine", 29524, 29533], ["sable", 34987, 34992], ["sable", 39013, 39018], ["sable", 40324, 40329], ["sable", 41310, 41315], ["sable", 42514, 42519], ["sable", 43939, 43944], ["sable", 47586, 47591]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_548 :
	true positives : [] 
	false positives : [["laver", 8880, 8885], ["Morel", 18873, 18878], ["sable", 22411, 22416], ["lime", 24967, 24971]] 
	false negatives : [["Anchusa linctoria", 4423, 4440]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_145 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Casianea sativa", 5696, 5711]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_38 :
	true positives : [] 
	false positives : [["rats", 20482, 20486], ["Lion", 27156, 27160], ["Lion", 28657, 28661], ["Lion", 31393, 31397], ["Lion", 37332, 37336], ["sable", 48005, 48010], ["Mans", 81257, 81261], ["Argentine", 84208, 84217]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_190 :
	true positives : [] 
	false positives : [["nance", 2439, 2444], ["laver", 50600, 50605], ["Argentine", 64421, 64430]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_533 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Euryopis acuminata", 4621, 4639], ["Olios c\u00e6nobita", 5953, 5967], ["Meta merian\u00e6", 8351, 8363], ["Cyclosa turbinata", 10752, 10769], ["Meta merianae", 12758, 12771]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_389 :
	true positives : [] 
	false positives : [["Argentine", 80314, 80323], ["sable", 85707, 85712], ["argentine", 87306, 87315], ["jute", 103443, 103447], ["jute", 103954, 103958], ["jute", 104415, 104419], ["jute", 104811, 104815], ["jute", 105390, 105394]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_297 :
	true positives : [] 
	false positives : [["rats", 9789, 9793], ["mastic", 22011, 22017], ["mastic", 23880, 23886], ["rats", 26288, 26292], ["sable", 26904, 26909], ["Morel", 29002, 29007], ["Argentine", 35469, 35478], ["mule", 49808, 49812], ["Niger", 54639, 54644], ["malachite", 84612, 84621]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_104 :
	true positives : [] 
	false positives : [["chats", 2588, 2593], ["Guanaco", 6613, 6620], ["chats", 8893, 8898], ["Wapitis", 9314, 9321], ["chat", 9830, 9834], ["chat", 10185, 10189], ["Man", 10202, 10205], ["gibbons", 12658, 12665], ["gibbon", 15543, 15549]] 
	false negatives : [["Cebus paraguayensis", 12127, 12146]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_18 :
	true positives : [["Alligator mississipiensis", 1228, 1253]] 
	false positives : [["sable", 5359, 5364]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_412 :
	true positives : [["Ursus arctos", 1492, 1504]] 
	false positives : [["casse", 5872, 5877], ["chats", 6431, 6436]] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_287 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_99 :
	true positives : [["Medicago sativa", 2100, 2115], ["Raphanus raphanistrum", 2751, 2772], ["Sinapis arvensis", 2821, 2837]] 
	false positives : [["Alfalfa", 4680, 4687], ["Argentine", 4827, 4836], ["Alfalfa", 5863, 5870]] 
	false negatives : [["Medicago falcata", 3470, 3486]] 
	precision = 50.00 %
	recall = 75.00 %
	F-measure = 60.00 %
Evaluation of the article : page_581 :
	true positives : [] 
	false positives : [] 
	false negatives : [["\u00c6Echinocactus ingens", 377, 397]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_165 :
	true positives : [] 
	false positives : [["Morel", 24187, 24192], ["sable", 26311, 26316], ["sable", 26323, 26328], ["sable", 26670, 26675], ["sable", 27883, 27888], ["sables", 28147, 28153], ["sable", 28548, 28553], ["tuba", 31787, 31791], ["mule", 35178, 35182], ["Emu", 43438, 43441], ["Man", 81710, 81713], ["casse", 82406, 82411], ["casse", 83596, 83601], ["Sables", 87400, 87406]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_98 :
	true positives : [] 
	false positives : [["Mallard", 2389, 2396]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_100 :
	true positives : [] 
	false positives : [["Swines", 2709, 2715], ["mastic", 23503, 23509]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_414 :
	true positives : [] 
	false positives : [["chat", 25586, 25590], ["Banana", 31181, 31187], ["bovine", 52594, 52600], ["ume", 58353, 58356]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_558 :
	true positives : [["capybara", 10163, 10171]] 
	false positives : [["alpaca", 836, 842], ["ass", 1240, 1243], ["gibbons", 7849, 7856], ["gibbon", 8494, 8500], ["capybara", 8917, 8925], ["mouflons", 9146, 9154], ["capybara", 10131, 10139]] 
	false negatives : [["Ovis studeri", 9188, 9200]] 
	precision = 12.50 %
	recall = 50.00 %
	F-measure = 20.00 %
Evaluation of the article : page_56 :
	true positives : [["Homo sapiens", 3462, 3474], ["Hippopotamus amphibius", 13325, 13347], ["Rhinoceros bicornis", 16367, 16386], ["Hippopotamus amphibius", 16391, 16413], ["Homo sapiens", 38318, 38330]] 
	false positives : [["Springbok", 888, 897], ["Springbok", 1569, 1578], ["Springbok", 2045, 2054], ["Springbok", 2489, 2498], ["Niger", 5800, 5805], ["sables", 5953, 5959], ["sables", 13406, 13412], ["sables", 16773, 16779], ["sables", 17393, 17399]] 
	false negatives : [["Homo capensis", 1433, 1446], ["Buffelus Bainu", 2564, 2578], ["Elephas antiquus", 12970, 12986], ["Elephas antiquus", 13122, 13138], ["Elephas antiquus", 13294, 13310], ["Elephas antiquus", 13677, 13693], ["Pelorovis oldowayensis", 13363, 13385], ["Pelorovis oldowayensis", 14605, 14627], ["Homo mediterraneus", 36463, 36481], ["Equus (Hippotigris) Hollisi", 16288, 16315], ["Bu\u00ffffelus antiquus", 16323, 16341], ["Procavia abyssinica", 17069, 17088], ["P. \u00c6Erlangeri", 17098, 17111], ["P. Mackinderi", 17121, 17134], ["Homo afer taganus", 41365, 41382]] 
	precision = 35.71 %
	recall = 25.00 %
	F-measure = 29.41 %
Evaluation of the article : page_6 :
	true positives : [["Homo sapiens", 5973, 5985], ["Homo sapiens", 6586, 6598], ["Homo sapiens", 7150, 7162], ["Homo sapiens", 15149, 15161], ["Homo sapiens", 15454, 15466], ["Homo sapiens", 22057, 22069], ["Homo sapiens", 22345, 22357], ["Homo neanderthalensis", 22374, 22395], ["Homo sapiens", 22420, 22432], ["Homo sapiens", 22873, 22885], ["Homo sapiens", 23113, 23125]] 
	false positives : [["Gibbons", 3208, 3215], ["Springbok", 13219, 13228], ["Hippopotamus", 15239, 15251], ["Kou", 15938, 15941], ["Kou", 16212, 16215], ["Kou", 16883, 16886], ["Kou", 18520, 18523], ["Kou", 18763, 18766], ["Kou", 19331, 19334]] 
	false negatives : [["\u00c2omo sapiens", 12788, 12800], ["Homo capensis", 13347, 13360], ["\u00c6Elephas antiquus", 15342, 15359], ["Sinanthropus pekinensis", 15991, 16014], ["Homo (Palaeanthropus) neanderthalensis palestinus", 21289, 21338], ["Homo palestinus", 22992, 23007], ["Homo (Javanthropus) soloensi", 23419, 23447]] 
	precision = 55.00 %
	recall = 61.11 %
	F-measure = 57.89 %
Evaluation of the article : page_204 :
	true positives : [["Saccharum officinarum", 6594, 6615], ["Solanum tuberosum", 38700, 38717], ["Solanum tuberosum", 40493, 40510]] 
	false positives : [["barley", 6371, 6377], ["corn", 21366, 21370], ["Maize", 21389, 21394], ["sables", 26455, 26461]] 
	false negatives : [["Solanum iuberosum", 32282, 32299], ["Solanum luberosum", 32337, 32354], ["Solunum Fendleri", 32448, 32464], ["Solanum stoloniferum", 32385, 32405], ["Solanum stoloniferum", 40084, 40104], ["S. longiconicum", 40281, 40296], ["S. pinnasectum", 40322, 40336]] 
	precision = 42.86 %
	recall = 30.00 %
	F-measure = 35.29 %
Evaluation of the article : page_241 :
	true positives : [] 
	false positives : [["Lion", 6475, 6479], ["Lion", 9807, 9811], ["Lion", 14477, 14481], ["Lucerne", 25316, 25323], ["Lucerne", 25394, 25401], ["Lucerne", 27017, 27024], ["Argentine", 54609, 54618], ["lions", 57969, 57974], ["sables", 58638, 58644], ["sable", 58689, 58694], ["sable", 60670, 60675], ["Apollo", 67826, 67832], ["sable", 69528, 69533], ["sable", 71217, 71222], ["sable", 73275, 73280], ["sable", 73695, 73700], ["sable", 74638, 74643], ["sable", 79142, 79147]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_267 :
	true positives : [] 
	false positives : [["Argentine", 46235, 46244]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_237 :
	true positives : [["Fraxinus excelsior", 15247, 15265], ["Onthophagus taurus", 16834, 16852], ["Onthophagus taurus", 16902, 16920], ["Pistacia terebinthus", 20045, 20065], ["Pistacia terebinthus", 21168, 21188], ["Pistacia terebinthus", 21221, 21241], ["Onthophagus taurus", 26205, 26223]] 
	false positives : [] 
	false negatives : [["Pistacia terebinihus", 19772, 19792], ["Valgus hemipterus", 21378, 21395], ["Valgus hemipterus", 21559, 21576], ["Valgus hemipierus", 22235, 22252]] 
	precision = 100.00 %
	recall = 63.64 %
	F-measure = 77.78 %
Evaluation of the article : page_36 :
	true positives : [] 
	false positives : [] 
	false negatives : [["P: noctilucus", 2365, 2378], ["Pyrophorus noctilucus", 5320, 5341]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_262 :
	true positives : [["A. patagonica", 14581, 14594], ["A.trifoliata", 14603, 14615], ["Macrocystis pyrifera", 22706, 22726]] 
	false positives : [] 
	false negatives : [["A. Selago", 14563, 14572], ["A. trifurcata", 14620, 14633], ["\u00c0. antipoda", 14730, 14741], ["Azorella Selago", 14829, 14844], ["Barbula validinervis", 17917, 17937], ["Grimmia cupularis", 17941, 17958], ["Campylopus austro-siramineus", 17982, 18010], ["Campylopus austro-stramineus", 18959, 18987], ["C. stramineus", 19063, 19076], ["Drepanocladus uncinatus", 19170, 19193], ["Placodium mexicanum", 20813, 20832], ["Neuropogon trachycarpus", 20904, 20927], ["N. trachycarpus", 21377, 21392], ["N. trachycarpus", 21959, 21974], ["Galera tenera", 22496, 22509], ["Azorella antipoda", 846, 863], ["Festuca Kerguelensis", 5934, 5954], ["Festuca Kerguelensis", 12270, 12290], ["Thuya tetragona", 6560, 6575], ["Thuya tetragonia", 6827, 6843], ["Araucaria imbricata", 7064, 7083], ["Pringlea antiscorbutica", 7484, 7507], ["Ac\u0153\u00e6na affinis", 1624, 1638]] 
	precision = 100.00 %
	recall = 11.54 %
	F-measure = 20.69 %
Evaluation of the article : page_189 :
	true positives : [] 
	false positives : [["sable", 3533, 3538]] 
	false negatives : [["Manta brevirostra", 3365, 3382]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_582 :
	true positives : [] 
	false positives : [["sable", 8543, 8548], ["sables", 70164, 70170], ["sables", 70693, 70699], ["sables", 71656, 71662], ["sables", 73089, 73095], ["sable", 74506, 74511], ["laver", 88784, 88789]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_188 :
	true positives : [["Allium sativum", 4180, 4194]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_602 :
	true positives : [["Welwitschia mirabilis", 12543, 12564]] 
	false positives : [["Aurochs", 1173, 1180], ["aurochs", 16961, 16968], ["aurochs", 23967, 23974]] 
	false negatives : [["Wekwitschia mirabilis", 25352, 25373]] 
	precision = 25.00 %
	recall = 50.00 %
	F-measure = 33.33 %
Evaluation of the article : page_288 :
	true positives : [] 
	false positives : [["LI", 18, 20]] 
	false negatives : [["Indigofera tinctoria", 2136, 2156]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_75 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Helolontha fullo", 16142, 16158], ["Melolontha fullo", 16766, 16782]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_286 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Pegomyia hyosciama", 3670, 3688]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_327 :
	true positives : [] 
	false positives : [["sable", 1549, 1554], ["sable", 12276, 12281], ["mastic", 61649, 61655], ["MAI", 62507, 62510], ["Lion", 65782, 65786], ["ass", 68033, 68036], ["ass", 68375, 68378], ["Lion", 68696, 68700], ["Lion", 73899, 73903], ["human", 84348, 84353], ["lime", 85968, 85972], ["sable", 87859, 87864], ["sable", 94545, 94550], ["mastic", 132902, 132908], ["Argentine", 134614, 134623]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_326 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Cetorhinus maximus", 3208, 3226], ["Dinemoura producta", 4892, 4910], ["Nemesis lamna", 5107, 5120], ["Dinobothrium plicitum", 5269, 5290]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_502 :
	true positives : [] 
	false positives : [["Argentine", 880, 889], ["ellipses", 9023, 9031], ["carps", 68656, 68661], ["Churchill", 84922, 84931], ["Churchill", 87020, 87029], ["Churchill", 88246, 88255], ["Churchill", 88847, 88856], ["Churchill", 89177, 89186], ["Churchill", 89620, 89629], ["Churchill", 90479, 90488], ["Churchill", 90816, 90825]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_561 :
	true positives : [] 
	false positives : [["Lake", 7376, 7380], ["Compton", 11474, 11481], ["Compton", 14174, 14181], ["Compton", 18542, 18549]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %

overall scores on the corpus vol126:
	precision = 14.80 %
	recall = 29.44 %
	F-measure = 19.70 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## starting evaluation of volume vol12
Evaluation of the article : page_138 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_82 :
	true positives : [] 
	false positives : [] 
	false negatives : [["aspidosperma Gomesianum", 1396, 1419]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_232 :
	true positives : [] 
	false positives : [["Grivet", 8195, 8201]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_387 :
	true positives : [] 
	false positives : [["sables", 10584, 10590]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_139 :
	true positives : [] 
	false positives : [["chats", 8432, 8437]] 
	false negatives : [["Gentiana glacialis", 12691, 12709], ["Daphne cn\u00e6orum", 12714, 12728], ["Sa lir herbac\u00e6a", 12733, 12748]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_212 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Cofinga maynana", 1620, 1635], ["Guacamaya colorada", 1806, 1824], ["Troyon pavoninus", 2154, 2170], ["Tinnunculus sparverius", 2756, 2778]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_83 :
	true positives : [] 
	false positives : [["sables", 6383, 6389]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_155 :
	true positives : [] 
	false positives : [["ide", 702, 705]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_91 :
	true positives : [] 
	false positives : [["casse", 20127, 20132], ["casse", 23628, 23633], ["kanda", 24754, 24759]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_310 :
	true positives : [] 
	false positives : [["man", 1049, 1052], ["sable", 8739, 8744]] 
	false negatives : [["Solanum laciniatum", 8706, 8724]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_147 :
	true positives : [] 
	false positives : [["bovine", 870, 876]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_118 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Bathynomus giganteus", 3311, 3331]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_51 :
	true positives : [["B. primigenius", 2198, 2212], ["B. taurus", 2806, 2815], ["B. taurus", 3070, 3079]] 
	false positives : [["aurochs", 1865, 1872]] 
	false negatives : [["Elephas primigenius", 684, 703], ["Rhinoceros lichorinus", 710, 731], ["Bos urus", 1885, 1893], ["B. priscus", 1906, 1916], ["B. latifrons", 1926, 1938], ["B, antiquus", 1950, 1961], ["PB americanus", 2007, 2020], ["B. europ\u0153us", 2027, 2038], ["B. iaurus ligeriensis", 2265, 2286], ["B. trachoceras", 2372, 2386], ["B. frontosus", 2402, 2414], ["B. longifrons", 2833, 2846], ["B, primigenius", 2874, 2888], ["B. laurus balavicus", 2925, 2944], ["B. brachyceras", 3035, 3049], ["B. brachycephalus", 3227, 3244]] 
	precision = 75.00 %
	recall = 15.79 %
	F-measure = 26.09 %
Evaluation of the article : page_108 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_328 :
	true positives : [["V. planifolia", 10484, 10497], ["Vanilla planifolia", 13018, 13036]] 
	false positives : [] 
	false negatives : [["Epidendrum Vanilla", 644, 662], ["Vanilla sativa", 10178, 10192], ["V. quianensis", 10245, 10258], ["V. palmarum", 10305, 10316], ["\u0178. aromatica", 10344, 10356], ["V. Pompona", 10604, 10614], ["Oclomeria graminifolia", 13167, 13189], ["Brassavola cordata", 13196, 13214], ["Angr\u00e6cum fragrans", 15830, 15847], ["Vanilla aromatica", 961, 978]] 
	precision = 100.00 %
	recall = 16.67 %
	F-measure = 28.57 %
Evaluation of the article : page_230 :
	true positives : [] 
	false positives : [["sables", 5219, 5225]] 
	false negatives : [["Cinnyris Adalberti", 471, 489], ["Semnopithecus monspessulanus", 3745, 3773]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_221 :
	true positives : [] 
	false positives : [["Canaries", 18777, 18785], ["boas", 32661, 32665]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_420 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Rhinocerus tichorhinus", 235, 257]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_113 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Pro: tophasma Dumasi", 8844, 8864]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_390 :
	true positives : [] 
	false positives : [["MAI", 14, 17], ["mans", 31278, 31282], ["bovines", 55277, 55284], ["Bers", 69056, 69060], ["MAI", 75592, 75595], ["Canaries", 92012, 92020], ["Canaries", 94512, 94520]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_312 :
	true positives : [] 
	false positives : [["sable", 25426, 25431], ["Argentine", 54145, 54154], ["Canaries", 55556, 55564], ["mans", 56452, 56456], ["sables", 56852, 56858], ["lime", 66705, 66709]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_12 :
	true positives : [] 
	false positives : [["ellipse", 68575, 68582], ["Swift", 127523, 127528], ["Swift", 130804, 130809], ["Swift", 131484, 131489], ["Swift", 132062, 132067], ["brill", 137524, 137529], ["Lions", 160993, 160998]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_148 :
	true positives : [["Sarracenia purpurea", 2129, 2148]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_104 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_251 :
	true positives : [] 
	false positives : [["man", 3934, 3937], ["bee", 26975, 26978], ["Tokay", 33572, 33577], ["Kou", 46253, 46256], ["lion", 68863, 68867], ["chat", 111115, 111119], ["sable", 121985, 121990], ["ellipse", 201375, 201382], ["Starling", 219347, 219355], ["sable", 270300, 270305]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_120 :
	true positives : [] 
	false positives : [["sables", 4316, 4322], ["malachite", 5258, 5267], ["Sable", 5835, 5840], ["Sables", 5981, 5987], ["sables", 6102, 6108], ["sable", 6293, 6298], ["malachite", 7835, 7844], ["Niger", 13282, 13287], ["Niger", 13946, 13951], ["LI", 14704, 14706], ["Swift", 45246, 45251], ["rat", 48068, 48071], ["sable", 51372, 51377]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_60 :
	true positives : [] 
	false positives : [["sable", 3651, 3656]] 
	false negatives : [["PHYLLOFHORA ARMATA", 58, 76], ["Papilio Laglaizei", 3285, 3302], ["Nyctalemon Urontes", 3319, 3337], ["P. speciosa", 3764, 3775], ["P. speciosa", 4359, 4370], ["P. speciosa", 4559, 4570], ["P. armata", 4856, 4865], ["Megalodon ensifer", 5129, 5146]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_146 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Dasychira pudibunda", 1497, 1516]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_429 :
	true positives : [] 
	false positives : [["Pacu", 2606, 2610], ["bovine", 10525, 10531]] 
	false negatives : [["S\u00e9pedon h\u0153\u00e6machale", 4517, 4535], ["phylloxora armiita", 4058, 4076]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_151 :
	true positives : [["Oryx leucoryx", 2570, 2583], ["Oryx gazella", 3101, 3113], ["canna", 9330, 9335], ["Tragelaphus scriptus", 11745, 11765]] 
	false positives : [["lions", 1360, 1365], ["Canna", 9518, 9523], ["Canna", 10451, 10456], ["Cannas", 10724, 10730], ["Canna", 11089, 11094], ["Cannas", 12320, 12326], ["Cannas", 12382, 12388], ["Chamois", 14931, 14938]] 
	false negatives : [["Eleotraqus reduncus", 171, 190], ["E/eotragus arundinaceus", 245, 268], ["Oryx beisa", 2988, 2998], ["Damalis albifions", 8710, 8727], ["Antilope albifions", 8737, 8755], ["Damalis pygargi", 8852, 8867], ["Tragelaphus scriplus", 10839, 10859], ["Tragelaphus decula", 11868, 11886], ["Tragelaphus sylvaticus", 12042, 12064]] 
	precision = 33.33 %
	recall = 30.77 %
	F-measure = 32.00 %
Evaluation of the article : vol12_page_166 :
	true positives : [] 
	false positives : [["sable", 3450, 3455], ["rats", 3879, 3883]] 
	false negatives : [["S\u00e9pedon h\u0153machate", 138, 155], ["S\u00e9pedon h\u0153machate", 1254, 1271], ["S\u00e9pedon h\u0153machate", 1298, 1315]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_417 :
	true positives : [] 
	false positives : [["Pig", 1907, 1910], ["Mans", 11537, 11541]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_413 :
	true positives : [] 
	false positives : [] 
	false negatives : [["E. Australis", 3223, 3235], ["Broussonetia papyrifolia", 5246, 5270], ["Enrycantha horrida", 2642, 2660], ["Eurycantha calcarata", 5806, 5826], ["E. horrida", 5871, 5881], ["E. horrida", 6398, 6408], ["E. echinata", 5899, 5910], ["Bacillus Rossi", 615, 629]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_49 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_214 :
	true positives : [] 
	false positives : [["Canaries", 13240, 13248], ["sable", 13721, 13726]] 
	false negatives : [["Protum\u00e6ba prinitiva", 1261, 1280], ["Myxasirum radians", 1285, 1302], ["Protomyxa aurantiaca", 2143, 2163], ["Protomyxa aurantiaca", 16734, 16754], ["Protomyra ankyst\u00e9e", 2170, 2188], ["Protam\u00e6ba primitiva", 6361, 6380], ["Bathybius H\u00e6ckeli", 7641, 7658], ["H\u00e6ckelina gigantea", 9115, 9133], ["Protomonas amyli", 10719, 10735], ["Protomonas gomphonematis", 10845, 10869], ["Protomyxa aurantiaco", 13360, 13380], ["Myxodiclium sociale", 15450, 15469], ["Myxastrum radians", 17544, 17561], ["Myxodictium sociale", 17639, 17658], ["Actinosph\u00e6rium Eichhornii", 18350, 18375], ["Pro\u00e9omyra auruntiaca", 18532, 18552], ["Actinophrys sol", 27112, 27127], ["Actinosph\u00e6rium E\u00efichhornii", 27675, 27701]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_353 :
	true positives : [] 
	false positives : [["MAI", 21319, 21322], ["MAI", 44663, 44666], ["mules", 54433, 54438], ["mules", 54937, 54942], ["Ber", 71900, 71903], ["MAI", 90981, 90984]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_68 :
	true positives : [] 
	false positives : [] 
	false negatives : [["{\u00e6nia solium", 887, 899], ["t\u0153nia mediocanellata", 906, 926], ["f\u0153nia 8olium", 1141, 1153], ["{\u00e6nia mediocanellata", 1300, 1320]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_56 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_8 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Eopteris Crier", 3675, 3689], ["Eopteris Morierei", 5377, 5394]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_384 :
	true positives : [] 
	false positives : [["sables", 3623, 3629], ["sables", 4227, 4233]] 
	false negatives : [["Gastornis Edwardsi", 5856, 5874], ["Gaslornis Edwardsi", 6291, 6309], ["Gastornis minor", 6561, 6576], ["Eupterornis remensis", 6756, 6776], ["Holaster pilula", 9987, 10002], ["Heterodiadema Lybicum", 8328, 8349], ["Holaster equiluberculatus", 9193, 9218], ["Archiacia Saadensis", 9597, 9616], ["Coptophyma problemalicum", 9642, 9666], ["H\u00e9miaster Balorensis", 9763, 9783], ["Goniopygus Messaoud", 9799, 9818], ["Heterodiadema Libycum", 9872, 9893], ["Holaster senonensis", 9948, 9967]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_351 :
	true positives : [["Cysticercus pisiformis", 6758, 6780]] 
	false positives : [["chat", 4443, 4447], ["rat", 4466, 4469]] 
	false negatives : [["Vesperugo parisiensis", 3043, 3064], ["Tenia solium", 4496, 4508], ["Tenia perfoliata", 5831, 5847], ["Tenia pectinata", 5867, 5882], ["Teniu perfoliata", 6539, 6555], ["Tenia pectinala", 6612, 6627], ["Tenia serrata", 6956, 6969], ["Tenia serrata", 9744, 9757], ["Rumina decollata", 10809, 10825], ["Pelobales fuscus", 11946, 11962], ["Pelobates cullripes", 11980, 11999]] 
	precision = 33.33 %
	recall = 8.33 %
	F-measure = 13.33 %
Evaluation of the article : page_415 :
	true positives : [["S. roseus", 8778, 8787]] 
	false positives : [["sable", 531, 536], ["aurochs", 1590, 1597], ["chamois", 1733, 1740], ["sables", 10663, 10669]] 
	false negatives : [["Bos brachyceros", 1639, 1654], ["Saccharomyce Sminor", 8301, 8320], ["Succharomyces quitulatus", 9255, 9279]] 
	precision = 20.00 %
	recall = 25.00 %
	F-measure = 22.22 %
Evaluation of the article : vol12_page_347 :
	true positives : [["Nitella flexilis", 11806, 11822], ["Funaria hygrometrica", 11856, 11876]] 
	false positives : [] 
	false negatives : [["Tradescantia Virginica", 2668, 2690], ["AZ th\u0153\u00e6a rosea", 2751, 2765], ["Stephanosph\u00e6ra pluvialis", 7638, 7662], ["Magosph\u00e6ra planula", 10214, 10232], ["Fucus vusiculusus", 11479, 11496], ["\u0152dogonium gemelliparum", 11651, 11673], ["Bulboch\u00e6te intermedia", 11749, 11770], ["Sphagnum acutifohum", 11916, 11935], ["Adianthum capillus veneris", 11971, 11997], ["Equiselum arvense", 12040, 12057], ["Gonium pectorale", 13010, 13026], [" Volvoz globator", 13062, 13078], ["Labyrinthula macrocystis", 14480, 14504], ["Magosph\u00e6ra planuia", 15296, 15314], ["Didymium leucojus", 15379, 15396], ["Areyria incarn la", 15507, 15524], ["Mugosph\u00e6ra adulle", 15533, 15550], ["\u00c6thalium septicum", 17352, 17369], ["Ceratium hydnoides", 19838, 19856], ["Polysticta reticulata", 19863, 19884]] 
	precision = 100.00 %
	recall = 9.09 %
	F-measure = 16.67 %
Evaluation of the article : page_422 :
	true positives : [] 
	false positives : [["sable", 6003, 6008], ["bovine", 8377, 8383], ["Sable", 9625, 9630], ["sable", 20866, 20871]] 
	false negatives : [["Phyllophora armata", 8604, 8622], ["S\u00e9pedon h\u0153machale", 9898, 9915], ["phyllophora armata", 16082, 16100], ["s\u00e9p\u00e9don h\u0153machate", 18929, 18946]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_143 :
	true positives : [] 
	false positives : [["Canaries", 64, 72], ["Canaries", 791, 799], ["Canaries", 1246, 1254], ["Canaries", 1637, 1645], ["Canaries", 2259, 2267], ["Canaries", 2572, 2580], ["Canaries", 3623, 3631], ["Canaries", 4455, 4463], ["Canaries", 4665, 4673], ["Canaries", 7525, 7533]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_246 :
	true positives : [] 
	false positives : [["sable", 2239, 2244]] 
	false negatives : [["Gromia oviformis", 543, 559], ["Globigerina builoides", 571, 592], ["Antmalina hemisph\u00e6rica", 610, 632], ["Lagenuiina costata", 681, 699], ["Dentalina punctata", 718, 736], ["Cristellaria iriangularis", 754, 779], ["Rotalia Venela", 2376, 2390], ["Cornuspira planorbis", 2396, 2416], ["Mihota flenera", 2435, 2449], ["Amphilonche heteracanta", 17406, 17429], ["Aca\u00efthometra elaslica", 17443, 17464], ["Doratospis polyanuystra", 22155, 22178], ["Cuchilonia Beckmanni", 22223, 22243], ["Rosalina anomala", 649, 665], ["Arachnocorys circumlexta", 17368, 17392]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_53 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Trachea piniperda", 586, 603]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_102 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_100 :
	true positives : [] 
	false positives : [["sables", 7997, 8003]] 
	false negatives : [["Bathynomus qiyanteus", 6479, 6499]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_103 :
	true positives : [] 
	false positives : [["lions", 5951, 5956]] 
	false negatives : [["Gazslle dama", 456, 468], ["Gazelle mobhr", 514, 527], ["Gazelle mohr", 1299, 1311], ["G. Soemmeringi", 1380, 1394], ["Gazelle Granli", 1758, 1772], ["Gazelle euchore", 2026, 2041], ["Gazelle euchore", 6380, 6395], ["G.euchore", 2043, 2052], ["Antilope bezoartica", 6887, 6906], ["Gazelles euchores", 3256, 3273], ["Antilope dama", 242, 255], ["Gazelle dama", 1236, 1248]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_54 :
	true positives : [] 
	false positives : [["Wapiti", 615, 621], ["bovines", 819, 826], ["Chiru", 1839, 1844], ["sable", 4171, 4176], ["Lions", 7761, 7766]] 
	false negatives : [["Elaphurus Davidianus", 625, 645], ["Capra dorcas", 3373, 3385], ["Antilope dorcas", 3399, 3414], ["Gazelle dorcas", 3460, 3474], ["Gazelle dorcas", 4080, 4094], ["Gazelle dorcas", 4867, 4881], ["Gazelle dorcas", 5551, 5565], ["Gazelle dorcas", 9329, 9343], ["G. isabella", 4998, 5009], ["lG. rufifrons", 5058, 5071], ["G. Cuvieri", 5121, 5131]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : page_48 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Lamprocolius nitens", 5911, 5930], ["Lamprocolius iris", 6493, 6510]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_421 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_96 :
	true positives : [] 
	false positives : [["tare", 11222, 11226]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_241 :
	true positives : [] 
	false positives : [["pear", 6371, 6375]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_235 :
	true positives : [] 
	false positives : [["laver", 27471, 27476]] 
	false negatives : [["Orchis pyramidulis", 2277, 2295], ["Orchis intacta", 6526, 6540], ["Neottia nidus-avis", 8009, 8027], ["Neottia nidus-avis", 10382, 10400], ["Limodorum abortivum", 8034, 8053], ["S. macrautha", 14423, 14435], ["Cypripedium barbalum", 17750, 17770], ["Colax jugosus", 17777, 17790], ["Epidendrum \u00e6mulum", 17797, 17814], ["Trichopilia tortilis", 17821, 17841], ["One'ditum iridifolium", 17848, 17869], ["Ansellia africana", 19010, 19027], ["Orchis Mono", 27065, 27076], ["PO. papilionccea", 27221, 27237], ["Ophrys nidus-avis", 27342, 27359], ["Neottia ovala", 27447, 27460], ["Arethusa bulbosa", 27809, 27825], ["Spiranthes diuretica", 27949, 27969], ["Chlor\u0153a disoidea", 27983, 27999], ["Cypripsdium pubescens", 28109, 28130], ["C. guttatum", 28247, 28258], ["Angr\u00e6cum fragrans", 28322, 28339], ["Callleya Epidendrum", 7285, 7304], ["Calypso borealis", 24962, 24978], ["Orchis conopsea", 27731, 27746]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_168 :
	true positives : [] 
	false positives : [["malachite", 10507, 10516], ["sables", 49160, 49166], ["bovine", 119139, 119145], ["chat", 151554, 151558], ["Canaries", 160236, 160244], ["Canaries", 160501, 160509], ["Canaries", 166936, 166944], ["Canaries", 167945, 167953], ["Canaries", 168835, 168843], ["Canaries", 170551, 170559], ["Canaries", 172086, 172094], ["Canaries", 177318, 177326], ["chat", 193702, 193706], ["chat", 193869, 193873]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_63 :
	true positives : [] 
	false positives : [["ass", 620, 623]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_52 :
	true positives : [] 
	false positives : [["lion", 373, 377]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_389 :
	true positives : [] 
	false positives : [["man", 45, 48]] 
	false negatives : [["Mygale Pyrenaica", 10, 26]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_106 :
	true positives : [] 
	false positives : [["sables", 3612, 3618], ["sables", 3690, 3696], ["sable", 3881, 3886], ["sables", 3996, 4002], ["sable", 4088, 4093], ["sables", 4149, 4155], ["sables", 4273, 4279], ["sables", 7040, 7046], ["sables", 8270, 8276], ["limes", 8487, 8492], ["sables", 9235, 9241]] 
	false negatives : [["Cerithium latisulcatum", 2478, 2500], ["Cerithium latisulcatum", 5956, 5978], ["Dentalium Leoni\u00e6", 2502, 2518], ["Dentalium Leoni\u00e6", 6975, 6991], ["Dentalium Leoni\u00e6", 8199, 8215], ["Limopsis concentrica", 2522, 2542], ["Limopsis concentrica", 8585, 8605], ["Cerithium spiratum", 6228, 6246], ["Cerithium spiratum", 6647, 6665], ["Dentalium eburneum", 7152, 7170], ["Dentalium eburneum", 7462, 7480], ["Dentalium eburneum", 8229, 8247], ["Nummulites variolaria", 8078, 8099], ["Cardita Bazini", 9244, 9258], ["Cardium stampinense", 9366, 9385], ["Cardium aviculinum", 9416, 9434]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_331 :
	true positives : [] 
	false positives : [["chamois", 24461, 24468], ["rats", 26480, 26484], ["MAI", 43582, 43585]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_69 :
	true positives : [] 
	false positives : [["chat", 2957, 2961], ["Lion", 15877, 15881], ["Lion", 16036, 16040], ["lions", 19803, 19808], ["Lion", 24696, 24700], ["sables", 28655, 28661], ["bovines", 29321, 29328], ["lions", 29448, 29453]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_167 :
	true positives : [] 
	false positives : [["Chats", 3438, 3443]] 
	false negatives : [["T\u00e6nia solium", 403, 415], ["T\u00e6\u0153nia cucumerina", 3251, 3268], ["Trichodectes Canis", 3470, 3488], ["T\u00e6nia Echinococcus", 3928, 3946], ["Disfonum hepaticun", 6834, 6852], ["D. lanceolatum", 6859, 6873]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_379 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Euglena sanguinea", 1872, 1889], ["Astasia h\u0153matodes", 1893, 1910], ["Monas prodigiosa", 2133, 2149], ["Salping\u00e6ca Clarkii", 3270, 3288], ["Salping\u00e6ca Clarkii", 7319, 7337], ["Astasia h\u00e6matodes", 5711, 5728], ["Phacus longicauda", 5742, 5759], ["Euglena deses", 5772, 5785], ["Stentor polymorphus", 5819, 5838], ["Codosiga Botrytis", 7204, 7221], ["Dinobryon sertularia", 7355, 7375], ["Uvella virescens", 7387, 7403], ["Rhipidodendron splendidum", 8823, 8848], ["Cephalothamnium Cyclopum", 8862, 8886], ["Anlhophysa vegetans", 8900, 8919], ["Dendromonas virgurie", 10258, 10278], ["Cladomonas fruticulosa", 10291, 10313], ["Phalans= terium digitatum", 10327, 10352], ["Poteriodendron petiolatum", 10364, 10389], ["Noctiluca miliaris", 10861, 10879], ["Notiluca miliaris", 11808, 11825], ["Hop'orhynchus oligacanthus", 13482, 13508], ["Clepsidrina blattarum", 13528, 13549], ["Gregarina gigantea", 13664, 13682], ["Gregarina gigantea", 18146, 18164], ["Gregarina gigantea", 19889, 19907]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_137 :
	true positives : [] 
	false positives : [] 
	false negatives : [["Verspertilio murinus", 440, 460]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_149 :
	true positives : [] 
	false positives : [["sable", 4739, 4744], ["sable", 5092, 5097], ["lime", 5115, 5119], ["sable", 5487, 5492], ["sable", 5646, 5651], ["lime", 5814, 5818], ["sable", 5921, 5926], ["limes", 5947, 5952], ["sable", 5973, 5978], ["sable", 6179, 6184], ["lime", 6282, 6286], ["sable", 6342, 6347], ["sable", 6691, 6696], ["sable", 6936, 6941], ["sable", 7324, 7329], ["lime", 7841, 7845], ["sable", 7919, 7924], ["lime", 8115, 8119], ["lime", 8269, 8273], ["sable", 8309, 8314], ["limes", 8359, 8364], ["lime", 8541, 8545], ["lime", 8650, 8654], ["sable", 8747, 8752], ["lime", 8782, 8786], ["sable", 8889, 8894], ["sable", 9123, 9128], ["limes", 9163, 9168], ["sable", 9365, 9370], ["sable", 9465, 9470], ["limes", 9825, 9830], ["limes", 9917, 9922]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_86 :
	true positives : [["Vitis vinifera", 15238, 15252]] 
	false positives : [] 
	false negatives : [["Phyllorera vaslatrix", 581, 601], ["Quercus pedunculata", 2431, 2450], ["Schizoneura lanigera", 15622, 15642]] 
	precision = 100.00 %
	recall = 25.00 %
	F-measure = 40.00 %

overall scores on the corpus vol12:
	precision = 7.46 %
	recall = 5.34 %
	F-measure = 6.22 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## overall scores on the whole corpus:
	precision = 14.01 %
	recall = 17.37 %
	F-measure = 15.51 %
