# ----------------------------------------------------------------------------------------------------------
Experience launched on July 28, 2022 at 00:13:31 with mode 6
----------------------------------------------------------------------------------------------------------

overall scores on the corpus vol83:
	precision = 70.44 %
	recall = 69.57 %
	F-measure = 70.00 %

overall scores on the corpus vol155:
	precision = 76.23 %
	recall = 66.19 %
	F-measure = 70.86 %

overall scores on the corpus vol126:
	precision = 59.78 %
	recall = 61.11 %
	F-measure = 60.44 %

overall scores on the corpus vol12:
	precision = 76.67 %
	recall = 65.48 %
	F-measure = 70.63 %
## overall scores on the whole corpus:
	precision = 71.40 %
	recall = 66.17 %
	F-measure = 68.68 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on July 28, 2022 at 00:13:31 with mode 6
----------------------------------------------------------------------------------------------------------

overall scores on the corpus vol83:
	precision = 70.44 %
	recall = 69.57 %
	F-measure = 70.00 %

overall scores on the corpus vol155:
	precision = 76.23 %
	recall = 66.19 %
	F-measure = 70.86 %

overall scores on the corpus vol126:
	precision = 59.78 %
	recall = 61.11 %
	F-measure = 60.44 %

overall scores on the corpus vol12:
	precision = 76.67 %
	recall = 65.48 %
	F-measure = 70.63 %
## overall scores on the whole corpus:
	precision = 71.40 %
	recall = 66.17 %
	F-measure = 68.68 %
# ----------------------------------------------------------------------------------------------------------
Experience launched on July 28, 2022 at 01:12:55 with mode 6
----------------------------------------------------------------------------------------------------------

overall scores on the corpus vol83:
	precision = 90.69 %
	recall = 69.57 %
	F-measure = 78.73 %

overall scores on the corpus vol155:
	precision = 83.41 %
	recall = 66.19 %
	F-measure = 73.81 %

overall scores on the corpus vol126:
	precision = 82.71 %
	recall = 61.11 %
	F-measure = 70.29 %

overall scores on the corpus vol12:
	precision = 90.64 %
	recall = 65.48 %
	F-measure = 76.03 %
## overall scores on the whole corpus:
	precision = 87.34 %
	recall = 66.17 %
	F-measure = 75.29 %
