# ----------------------------------------------------------------------------------------------------------
Experience launched on May 04, 2022 at 18:54:27
Chosen mode: union
----------------------------------------------------------------------------------------------------------
## starting evaluation of volume vol83
Evaluation of the article : page_611 :
	true positives : [] 
	false positives : [["Ruccrro Ravasixi", 43299, 43315], ["Coquetier mire", 72286, 72300], ["R. Viiuers", 26167, 26177], ["C. Lechalas", 37482, 37493], ["R. Marrerr", 42531, 42541]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_109 :
	true positives : [] 
	false positives : [["Stephenson actionnentles", 4695, 4719], ["Almagestum novum", 12366, 12382], ["Riccrour relaie", 12385, 12400], ["Perspectiva horaria", 12481, 12500]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_472 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_507 :
	true positives : [["Gigantosaurus africanus", 3678, 3701], ["G. robustus", 3705, 3716]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_218 :
	true positives : [["Vipera berus", 114, 126], ["Vipera aspis", 143, 155], ["Naja hiperdians", 1815, 1830], ["Lachesis lanceolatus", 3408, 3428], ["Vipera aspis", 4811, 4823], ["Crotalus terrificus", 6778, 6797]] 
	false positives : [["Sao Paulo", 16129, 16138]] 
	false negatives : [] 
	precision = 85.71 %
	recall = 100.00 %
	F-measure = 92.31 %
Evaluation of the article : page_232 :
	true positives : [] 
	false positives : [["Sierra Candelaria", 8646, 8663], ["Lucrex Fourier", 32594, 32608], ["Sapeurs pompiers", 60578, 60594]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_310 :
	true positives : [["Rotalina orbicularis", 968, 988], ["Pupa similis", 2210, 2222], ["Pupa similis", 2604, 2616]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_122 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_139 :
	true positives : [] 
	false positives : [["Imperator rappellera", 7619, 7639], ["Princeps Mathematicorum", 33841, 33864], ["Bourgogne survenue", 61244, 61262], ["Roufs flotlanis", 62251, 62266], ["Gama Machado", 105272, 105284], ["B. Emerson", 24900, 24910], ["P. Joumors", 81609, 81619]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_488 :
	true positives : [["Cereus pitahaya", 588, 603]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_83 :
	true positives : [] 
	false positives : [["Revaccination antityphique", 1370, 1396], ["Viribus Unitis", 20158, 20172]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_537 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_655 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_654 :
	true positives : [] 
	false positives : [["Amplitudes diurnes", 1514, 1532], ["Hadiation solair", 7471, 7487]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_569 :
	true positives : [["Homo heidelbergensis", 1199, 1219]] 
	false positives : [["H. Ducxwortx", 857, 869]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_550 :
	true positives : [["yucca filamentosa", 6135, 6152], ["helianthus multiflorus", 6286, 6308], ["bocconia microcarpa", 6318, 6337]] 
	false positives : [["Amplitudes diurnes", 1373, 1391]] 
	false negatives : [["statice limonium", 6261, 6277], ["anemone japonica", 6509, 6525]] 
	precision = 75.00 %
	recall = 60.00 %
	F-measure = 66.67 %
Evaluation of the article : page_489 :
	true positives : [] 
	false positives : [["piedra movediza", 15947, 15962], ["Quiconque transmettra", 41599, 41620], ["assa f\u0153tida", 61278, 61289], ["Matth\u0153us Platearius", 61654, 61673], ["medicina dictus", 61741, 61756], ["Circa instans", 61757, 61770], ["Circa instans", 62297, 62310], ["olla positus", 62445, 62457], ["Serapionis dicta", 62545, 62561], ["S. Baglioni", 107169, 107180], ["C. Hess", 107224, 107231]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_60 :
	true positives : [["Macrorhinus elephantinus", 1281, 1305], ["Canis jubatus", 5005, 5018], ["Bradypus tridactylus", 5179, 5199]] 
	false positives : [["Clemente ficie", 6687, 6701]] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [["Uxiox vgsraze", 1775, 1788], ["Wie onts", 48479, 48487]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_530 :
	true positives : [["Cichorium intrbus", 2072, 2089]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_281 :
	true positives : [] 
	false positives : [["cxpor ation", 75262, 75273]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_341 :
	true positives : [["Sporotrichum globuliferum", 2228, 2253]] 
	false positives : [["Botr ylis", 2203, 2212]] 
	false negatives : [["Botr ylis bassiana", 2203, 2221]] 
	precision = 50.00 %
	recall = 50.00 %
	F-measure = 50.00 %
Evaluation of the article : page_176 :
	true positives : [["Amanita phalloides", 1587, 1605], ["Russula emetica", 1865, 1880], ["Amanita phalloides", 1886, 1904], ["Balliota campestris", 2046, 2065], ["Amanita muscaria", 2307, 2323], ["Boletus edulis", 3744, 3758]] 
	false positives : [["accueillis Lepiota", 2015, 2033], ["A. Acroqur", 4986, 4996]] 
	false negatives : [["Lepiota procera", 2026, 2041]] 
	precision = 75.00 %
	recall = 85.71 %
	F-measure = 80.00 %
Evaluation of the article : page_105 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_372 :
	true positives : [] 
	false positives : [["Hyla arborea", 17724, 17736], ["Alytes obstetricans", 17766, 17785], ["Sciurres rufiventer", 18714, 18733], ["Volontaires albanais", 23304, 23324], ["Slaves austrohongrois", 28180, 28201], ["grosso modo", 92506, 92517]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_657 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_35 :
	true positives : [["Rhizina inflata", 4293, 4308], ["Rhizina inflata", 4961, 4976]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_169 :
	true positives : [["Mirabilis Jalappa", 3145, 3162], ["Mirabilis jalappa", 3396, 3413]] 
	false positives : [["Farents inlr", 3013, 3025], ["Elude stalislique", 6250, 6267]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_570 :
	true positives : [] 
	false positives : [["Amortisseur pneminatique", 14156, 14180], ["Lectures anthropologiques", 41627, 41652], ["Gasron Bonxier", 47852, 47866], ["L. Meens", 1770, 1778], ["G. Bernstein", 44301, 44313]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_80 :
	true positives : [["Homarus americanus", 245, 263], ["Pinnotheres pisum", 601, 618], ["Birgus latro", 676, 688], ["Nephrops norvegicus", 1127, 1146], ["Pandalus borealis", 2564, 2581]] 
	false positives : [["Aselle aqualique", 1247, 1263], ["Crangon vulgar", 2493, 2507]] 
	false negatives : [["Limnoria \u2018 lignorium", 1961, 1981], ["Limnoria ef des Chelura", 2087, 2110], ["Leander serra", 2403, 2416], ["Crangon vulgar is", 2493, 2510]] 
	precision = 71.43 %
	recall = 55.56 %
	F-measure = 62.50 %
Evaluation of the article : page_118 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_164 :
	true positives : [["Grampus griseus", 2111, 2126], ["Grampus griseus", 2778, 2793]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_127 :
	true positives : [] 
	false positives : [["Eryngium maritimum", 673, 691], ["Conventionne fui", 32088, 32104]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_230 :
	true positives : [["Raphidium nivale", 674, 690], ["Protococcus nivalis", 1199, 1218], ["Pteromonas nivalis", 4794, 4812], ["Ancylonema Nordenskioldii", 5129, 5154]] 
	false positives : [["Diamylon nivale", 3060, 3075]] 
	false negatives : [["Sph\u00e6rella \u2018mivalis", 1498, 1516], ["Sph\u00e6rella: lacustris", 1664, 1684], ["rococcus vulg\u00e4ris", 1758, 1775]] 
	precision = 80.00 %
	recall = 57.14 %
	F-measure = 66.67 %
Evaluation of the article : page_652 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_348 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_406 :
	true positives : [["Mesonaula insignis", 3594, 3612], ["Herniramphus fluvia", 3641, 3660], ["Danio rerio", 3673, 3684], ["Rasbora heteromorpha", 3690, 3710], ["Paratilapia multicolor", 4031, 4053]] 
	false positives : [] 
	false negatives : [["Plerophy Ju scalare", 1726, 1745], ["Seatophagus arqUs", 1749, 1766], ["Heros | facetus", 2997, 3012], ["Mo\u00eflienesia latipinna", 3719, 3740]] 
	precision = 100.00 %
	recall = 55.56 %
	F-measure = 71.43 %
Evaluation of the article : page_81 :
	true positives : [["Carcinus mo\u0153nas", 599, 614], ["Portunus puber", 628, 642], ["Callinectes sapidus", 703, 722], ["Eupagurus Bernhardus", 826, 846], ["Balanus psittacus", 1004, 1021], ["Pinnotheres pisum", 2744, 2761], ["Asellus aquaticus", 3217, 3234], ["Limnoria lignorium", 3572, 3590], ["Chelura terebrans", 3643, 3660]] 
	false positives : [] 
	false negatives : [["Cancer pagurus", 568, 582], ["Pollicipes cornucopi\u00e6", 1190, 1211]] 
	precision = 100.00 %
	recall = 81.82 %
	F-measure = 90.00 %
Evaluation of the article : page_227 :
	true positives : [["Ornithodorus Savignyi", 2823, 2844], ["Ornithodorus moubaia", 2873, 2893], ["Solanum Luberosum", 3246, 3263]] 
	false positives : [["Lucrex Fournrer", 1295, 1310]] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_521 :
	true positives : [] 
	false positives : [["Vereins deutscher", 11287, 11304]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_470 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_211 :
	true positives : [["ficus carica", 1869, 1881]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_116 :
	true positives : [["Desoria glacialis", 1816, 1833], ["Polytrichum formosum", 3563, 3583], ["Polytrichum formosum", 6762, 6782], ["Pellia epiphylla", 8341, 8357], ["Polytrichum formosum", 8645, 8665], ["Polytrichum formosum", 10153, 10173]] 
	false positives : [["Oronge citrine", 1239, 1253], ["P. Lesage", 2504, 2513]] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_397 :
	true positives : [["Drosera rotundifolia", 444, 464], ["Drosera rotundifolia", 617, 637], ["Drosera rotundifolia", 1252, 1272], ["Drosera rotundifolia", 2243, 2263], ["Drosera rotundifolia", 2268, 2288], ["Pinguicula caudata", 3225, 3243], ["Drosera rotundifolia", 4445, 4465], ["Dionaea muscipula", 4583, 4600], ["Dionaea muscipula", 5113, 5130], ["Apocynum androsoemifolium", 7765, 7790]] 
	false positives : [] 
	false negatives : [["Dionaca m\u00fcscipula", 1351, 1368], ["Drosera ratun", 4728, 4741]] 
	precision = 100.00 %
	recall = 83.33 %
	F-measure = 90.91 %
Evaluation of the article : page_583 :
	true positives : [] 
	false positives : [["Jacobus Henricus", 10276, 10292], ["Ufficio Idrografico", 15597, 15616], ["Carlo Ferrari", 15716, 15729], ["Theo Hillmer", 33802, 33814], ["Astra Romana", 33894, 33906], ["Garnissage calorifuge", 43324, 43345], ["Studio zoologico", 65591, 65607], ["Mira Ceti", 110389, 110398], ["Andrea Doria", 130716, 130728], ["Caio Duillio", 130736, 130748], ["A. Cuwapver", 9006, 9017], ["J. Coe", 14420, 14426], ["C. Davisox", 14672, 14682], ["C. Aruould", 57232, 57242], ["G. Chevallier", 115000, 115013], ["J. Bonenfant", 115085, 115097], ["J. Loisez", 117045, 117054], ["G. Urbain", 117886, 117895], ["J. Lorsez", 119118, 119127], ["A. Canxox", 120667, 120676], ["A. Minchin", 137004, 137014], ["S. Geol", 172508, 172515]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_649 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_508 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_228 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_551 :
	true positives : [["Ceroxylon audicola", 130, 148], ["Copernicia cerifera", 480, 499], ["Rhus succedanea", 2084, 2099], ["Rhus vermicifera", 2126, 2142], ["Stillingia Sebifera", 2982, 3001]] 
	false positives : [] 
	false negatives : [["M. Cerifera", 1195, 1206], ["M. Carolinensis", 1208, 1223], ["M. Pensylvanica", 1225, 1240], ["M. Cordifolia", 1257, 1270], ["M. Quercifolia", 1272, 1286], ["M. Serrata", 1288, 1298]] 
	precision = 100.00 %
	recall = 45.45 %
	F-measure = 62.50 %
Evaluation of the article : page_478 :
	true positives : [["tradescantia virginica", 6446, 6468], ["geum urbanum", 6519, 6531], ["deutzia scabra", 6739, 6753]] 
	false positives : [["Ambplitudes diurnes", 1897, 1916], ["A. Angot", 3596, 3604]] 
	false negatives : [] 
	precision = 60.00 %
	recall = 100.00 %
	F-measure = 75.00 %
Evaluation of the article : page_471 :
	true positives : [["Atriplex halimus", 3401, 3417], ["Atriplex nummularia", 3419, 3438], ["Artemisia maritima", 3440, 3458], ["Casuarina equisetifolia", 3460, 3483], ["Ephedra alata", 3485, 3498], ["Juniperus macrocarpa", 3521, 3541], ["Melaleuca eri\u00e6\u0153folia", 3557, 3577], ["Ph\u0153nix tenuis", 3615, 3628], ["Ph\u0153nix dactylifera", 3630, 3648], ["Rhus viminalis", 3664, 3678], ["Salsola fruticosa", 3680, 3697], ["Tamarix articulata", 3699, 3717], ["Tamarix gallica", 3719, 3734], ["Acacia cyclopis", 3838, 3853], ["Acacia cyanophylla", 3855, 3873], ["Albizzia lophauta", 3875, 3892], ["Prosopis dulcis", 3894, 3909], ["Casuarina quadrivalvis", 3911, 3933], ["Cupressus lambertiana", 3935, 3956], ["Eucalyptus robusta", 3958, 3976], ["Evonymus japonica", 3978, 3995], ["Ficus carica", 3997, 4009], ["Pittosporum tobira", 4011, 4029], ["Phillyrea media", 4031, 4046], ["Parkinsonia aculeata", 4048, 4068], ["Punica granatum", 4070, 4085], ["Statice arborea", 4093, 4108]] 
	false positives : [["Vitex agnus", 3736, 3747], ["A. Delbove", 4936, 4946], ["J. Larroche", 7793, 7804], ["V. Martinaud", 7987, 7999], ["J. Weinmann", 8174, 8185], ["E. Duval", 8779, 8787], ["C. Bailly", 9594, 9603]] 
	false negatives : [["Hippoph\u00e6 rhamno\u00efdes", 3500, 3519], ["Phytolacca dio\u00efca", 3596, 3613], ["Vitex agnus castus", 3736, 3754], ["Acacia-nilatica", 3821, 3836]] 
	precision = 79.41 %
	recall = 87.10 %
	F-measure = 83.08 %
Evaluation of the article : page_555 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_278 :
	true positives : [["Hydra fusca", 9533, 9544], ["Branchipus stagnalis", 9686, 9706], ["Apus productus", 9711, 9725], ["Daphnia similis", 9784, 9799], ["Nepa cinerea", 10105, 10117]] 
	false positives : [] 
	false negatives : [["Gammarus n\u00e9giectus", 9843, 9861]] 
	precision = 100.00 %
	recall = 83.33 %
	F-measure = 90.91 %
Evaluation of the article : page_120 :
	true positives : [["Palinurus regius", 5766, 5782], ["Temnodon sallator", 6471, 6488], ["Dentex maroccanus", 7781, 7798], ["Temnodon Sallaior", 7848, 7865], ["Beryx decadactylus", 7881, 7899]] 
	false positives : [["Brito Capello", 5783, 5796], ["Temnodon sauteur", 6453, 6469], ["Dentiex macro", 7402, 7415], ["decadactylus Guvier", 8612, 8631]] 
	false negatives : [["Dentiex macro phthalmus", 7402, 7425], ["Berg decadactylus", 8607, 8624]] 
	precision = 55.56 %
	recall = 71.43 %
	F-measure = 62.50 %
Evaluation of the article : page_252 :
	true positives : [["Bal\u00e6noptera Sibbaldii", 877, 898], ["B. musculus", 910, 921], ["B. borealis", 944, 955]] 
	false positives : [["Sandwichs australes", 20469, 20488]] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_424 :
	true positives : [] 
	false positives : [["Oualata contribuera", 28581, 28600], ["Oualata reconstruite", 33084, 33104], ["Blatte chanteuse", 51981, 51997], ["Revaeciuation antityphique", 61682, 61708], ["Revaccination antityphique", 86801, 86827], ["R. Lecrnbre", 86676, 86687], ["R. Boxnix", 87955, 87964], ["R. Menur", 88767, 88775], ["R. Vizsens", 88921, 88931], ["R. Boxux", 89782, 89790], ["R. Menue", 90980, 90988], ["R. Boxmx", 91033, 91041], ["R. Bossix", 92236, 92245], ["R. Box", 92340, 92346]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_648 :
	true positives : [["Helix pomatia", 7167, 7180]] 
	false positives : [["Orro Srecae", 7481, 7492]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_610 :
	true positives : [["Polysiphonia Brodiaei", 3107, 3128], ["Batrachospermum Gallaer", 3597, 3620], ["Demanea fluviatilis", 3624, 3643], ["Ceramium rubrum", 3869, 3884], ["P. nigrescens", 3130, 3143]] 
	false positives : [] 
	false negatives : [["Rhodomela su\u00fcbfusca", 3147, 3166]] 
	precision = 100.00 %
	recall = 83.33 %
	F-measure = 90.91 %
Evaluation of the article : page_531 :
	true positives : [] 
	false positives : [["Geologica Mexicana", 8309, 8327], ["Pacte ravemi", 10730, 10742], ["P. Gordon", 6170, 6179], ["P. Cousin", 17302, 17311]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_101 :
	true positives : [["Pulicaria vulqaris", 715, 733], ["Pyrethrum carneum", 1161, 1178], ["Pyrethrum roseum", 1843, 1859], ["P. roseum", 1182, 1191]] 
	false positives : [["Chr ysanthemum", 404, 418]] 
	false negatives : [["Chr ysanthemum leucanthemum", 404, 431]] 
	precision = 80.00 %
	recall = 80.00 %
	F-measure = 80.00 %
Evaluation of the article : page_451 :
	true positives : [["Zirphaea {Pholas] cristata", 3601, 3627], ["Saxicava rugosa", 3635, 3650]] 
	false positives : [["vacuum cleaner", 3784, 3798]] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_351 :
	true positives : [["Ginkgo biloba", 1851, 1864], ["Ginkgo biloba", 5513, 5526], ["Ginkgo biloba", 8224, 8237]] 
	false positives : [["Lilter ature", 7698, 7710]] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_192 :
	true positives : [["Littorina littoralis", 2811, 2831]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_534 :
	true positives : [["ficus carica", 3200, 3212]] 
	false positives : [["Augustus Woelker", 4264, 4280]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_369 :
	true positives : [["Arvicola agrestis", 119, 136]] 
	false positives : [["Campagrols pullulations", 1974, 1997]] 
	false negatives : [["Mus sylvaticus", 161, 175], ["B. Typhi murium", 8913, 8928]] 
	precision = 50.00 %
	recall = 33.33 %
	F-measure = 40.00 %
Evaluation of the article : page_535 :
	true positives : [["Eucalyptus globulus", 6301, 6320], ["quassia amara", 6999, 7012], ["quassia amara", 7099, 7112]] 
	false positives : [["E. Kayser", 1976, 1985], ["E. Duclaux", 2278, 2288], ["E. Boullanger", 2889, 2902]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_95 :
	true positives : [] 
	false positives : [["Corrado Gappello", 7677, 7693], ["Alessandro Malladra", 7930, 7949], ["Immunisation vaccinale", 21208, 21230], ["I. Alessandro", 7927, 7940]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_510 :
	true positives : [["galega officinalis", 5070, 5088], ["Mistichthys luzonensis", 5720, 5742], ["Bal\u00e6noptera sibbaldi", 5901, 5921], ["Microsorex minnemana", 6172, 6192], ["Blarina parva", 6283, 6296], ["Diomedea exulans", 7503, 7519], ["Sph\u00e6rodactylus sputator", 7614, 7637], ["Varanus saltator", 7837, 7853], ["Arthroleptis sechellensis", 11132, 11157], ["Hyla Pickeringi", 11254, 11269], ["Megalobatrachus japonicus", 11359, 11384], ["Acanthophacelus bifurcus", 11577, 11601], ["Arapaima gigas", 11723, 11737], ["Carcharodon Rondeletii", 11890, 11912], ["Oospora pulmonalis", 12987, 13005], ["Rhizomucor parasiticus", 13330, 13352], ["Mucor corymbifer", 13357, 13373]] 
	false positives : [["Amplitudes diurnes", 1138, 1156], ["Oosporoses pulmonaires", 11983, 12005]] 
	false negatives : [["Calypte kelen\u00e6", 6931, 6945], ["$. notatus", 7742, 7752], ["aspergilluss fumigatus", 9382, 9404]] 
	precision = 89.47 %
	recall = 85.00 %
	F-measure = 87.18 %
Evaluation of the article : page_452 :
	true positives : [] 
	false positives : [["Delambre laissa", 31966, 31981]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_568 :
	true positives : [["quassia amara", 1530, 1543]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_519 :
	true positives : [["Eriocampa limacina", 4828, 4846]] 
	false positives : [["E. Freurexr", 10450, 10461]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_486 :
	true positives : [["Cimex lectularius", 2976, 2993], ["Acanthia lectularia", 2997, 3016]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_186 :
	true positives : [] 
	false positives : [["danstous lessens", 4817, 4833]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_311 :
	true positives : [["bacillus butylicus", 10383, 10401], ["bacillus orthobutylicus", 10617, 10640]] 
	false positives : [["Osonide ara", 6543, 6554]] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_543 :
	true positives : [["Cossus ligniperda", 6648, 6665]] 
	false positives : [] 
	false negatives : [["Zeus\u00e8ra \u00e6sculi", 6045, 6059]] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_264 :
	true positives : [] 
	false positives : [["Lacroix constale", 46562, 46578]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_342 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_422 :
	true positives : [["Libellula depressa", 5903, 5921]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_166 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_212 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_102 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_302 :
	true positives : [["Eumenes coarctatus", 738, 756], ["Eumenes coarclatus", 1638, 1656], ["Euinenes unguiculus", 1674, 1693], ["Odynevus spinipes", 1711, 1728], ["Celonites abbreviatus", 1768, 1789], ["Polistes gallicus", 3533, 3550], ["Vespa germanica", 3567, 3582], ["Vespa germanica", 3595, 3610], ["Vespa media", 3631, 3642], ["Vespa media", 3656, 3667], ["Leipomeles lamellaria", 4110, 4131], ["Polybia dimidiaia", 4193, 4210], ["Polybia rejecta", 4269, 4284], ["Ceramius lusitanicus", 4845, 4865], ["Odynerus spinipes", 5015, 5032], ["Polistes gallicus", 8267, 8284], ["Vespa germanica", 8644, 8659], ["Vespa media", 11164, 11175], ["Protopolybia emortualis", 13426, 13449], ["Protopolybia emortualis", 13939, 13962], ["Leipomeles lamellaria", 14294, 14315], ["Polybia rejecta", 15445, 15460], ["Cassicus persicus", 15737, 15754]] 
	false positives : [["Vespides solilaires", 1612, 1631], ["Vespides solitaires", 4581, 4600], ["Ceramie portugais", 4872, 4889]] 
	false negatives : [["Odyner us spinipes", 2454, 2472], ["Belenogaster junceuset", 3495, 3517], ["Prolopolybia emoTtualis", 4156, 4179], ["Polybia rejecta", 15867, 15882], ["Chelonites abbrevi\u00e4tus", 5619, 5641]] 
	precision = 88.46 %
	recall = 82.14 %
	F-measure = 85.19 %
Evaluation of the article : page_172 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_487 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_512 :
	true positives : [] 
	false positives : [["Hooton Blackiston", 26397, 26414], ["aglo inclus", 27873, 27884], ["Watson jugea", 44038, 44050], ["H. Paillard", 18004, 18015]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_632 :
	true positives : [["Luillaja Saponaria", 2280, 2298], ["Zuillaja Saponaria", 2813, 2831], ["castilloa elastica", 3593, 3611]] 
	false positives : [["Sapindus Saponaria", 2886, 2904], ["Mancer Bror", 9535, 9546], ["S. Gramer", 3565, 3574]] 
	false negatives : [["Sapindus Saponaria officinalis", 2886, 2916]] 
	precision = 50.00 %
	recall = 75.00 %
	F-measure = 60.00 %
Evaluation of the article : page_656 :
	true positives : [["Quillaja sapo", 1119, 1132], ["Schisotrypanum Cruzi", 5295, 5315]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_314 :
	true positives : [] 
	false positives : [["Transactions philo", 50763, 50781], ["nullius addicius", 53839, 53855], ["verba magistri", 53866, 53880], ["Costa Rica", 65930, 65940], ["Malte vota", 68374, 68384], ["Instr uctions", 97649, 97662], ["C. Holzapfel", 105243, 105255]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_660 :
	true positives : [] 
	false positives : [["sara Casablanca", 42479, 42494], ["Louer ass", 49101, 49110], ["Rapaces bienfaisants", 51002, 51022], ["Speclres stellaires", 51618, 51637], ["Garnissage calorifuge", 57007, 57028], ["Muselte mangeoire", 59879, 59896], ["R. Graxsow", 30920, 30930], ["R. Homwer", 31806, 31815], ["G. Wervy", 34814, 34822], ["G. Fisher", 36791, 36800], ["R. Vizcens", 66922, 66932]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_558 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_346 :
	true positives : [["Shistocerca peregrina", 810, 831], ["Shistocerca americana", 1187, 1208], ["Micrococcus Acridiorum", 2646, 2668], ["Coccobacillus Acridiorum", 7580, 7604], ["Coccobacillus Acridiorum", 9292, 9316]] 
	false positives : [["ocerca americana", 986, 1002], ["Ricardo Mattei", 4830, 4844]] 
	false negatives : [["Shis{ocerca americana", 981, 1002], ["Atta Sexdens", 9572, 9584]] 
	precision = 71.43 %
	recall = 71.43 %
	F-measure = 71.43 %
Evaluation of the article : page_106 :
	true positives : [["Culex fatigans", 3913, 3927], ["Stegomya fasciata", 4457, 4474]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_408 :
	true positives : [] 
	false positives : [["Basile remporta", 48034, 48049]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_177 :
	true positives : [] 
	false positives : [["Patinage agiatique", 18381, 18399]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_400 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_405 :
	true positives : [] 
	false positives : [["fyphus levissimus", 4977, 4994]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_480 :
	true positives : [] 
	false positives : [["Ulrico H\u00e6pli", 8092, 8104], ["assa f\u0153tida", 15891, 15902]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_353 :
	true positives : [] 
	false positives : [["Schultze gunpowder", 2114, 2132], ["Mirabilia graphica", 14081, 14099], ["Technica curiosa", 14390, 14406], ["Divinum munus", 14409, 14422], ["velocior illis", 15007, 15021], ["Nondum lingua", 15022, 15035], ["suum dextra", 15037, 15048], ["furta verborum", 15406, 15420], ["Tachygraphia nova", 15677, 15694], ["Techuca euriosa", 16157, 16172], ["Tachygraphia nova", 18398, 18415], ["Mirabilia graphica", 19323, 19341], ["Avarus vettes", 21588, 21601], ["Kuliabko conserva", 51349, 51366]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_466 :
	true positives : [["Lithodes kamschatica", 13092, 13112], ["Chinoeletes opilio", 13206, 13224]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_540 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_634 :
	true positives : [] 
	false positives : [["Lyster Jameson", 10580, 10594], ["Barbier conseille", 29784, 29801], ["Cyon affirma", 56163, 56175], ["servizio minerario", 63899, 63917], ["Societa eritrea", 64594, 64609], ["Aeide butyrique", 70330, 70345], ["Industria Saponiera", 94649, 94668], ["A. Soulier", 40630, 40640], ["S. Julien", 44056, 44065]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_183 :
	true positives : [["Lomentaria articulata", 66, 87], ["Padina Pavotia", 104, 118], ["Corallina officinalis", 165, 186], ["Rhodymenia palmata", 1997, 2015], ["Delesseria sanguinea", 2116, 2136], ["Laminaria Cloustoni", 2197, 2216], ["Callophyllis laciniata", 2237, 2259], ["Ulva Lactuca", 2279, 2291], ["Fucus vesiculosus", 2616, 2633], ["Calliblepharis ciliata", 2654, 2676], ["Calliblepharis laciniata", 4247, 4271], ["Plocamium coccineum", 4284, 4303], ["Chondrus crispus", 4386, 4402], ["Heterosiphonia coccinea", 4459, 4482]] 
	false positives : [["H. Coubin", 6372, 6381]] 
	false negatives : [] 
	precision = 93.33 %
	recall = 100.00 %
	F-measure = 96.55 %
Evaluation of the article : page_36 :
	true positives : [] 
	false positives : [["envo oyer", 9618, 9627], ["Lucrex Fourxrer", 22387, 22402], ["deutscher Elektrotechniker", 29970, 29996], ["L. Menvsxr", 32507, 32517]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_658 :
	true positives : [["Parom\u00e6cium aurelia", 11397, 11415], ["Colpomenia sinuosa", 13638, 13656]] 
	false positives : [["Hughes invente", 1874, 1888]] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_262 :
	true positives : [["Hippopotamus amphibius", 3859, 3881], ["Hippopotamus amphibius", 6020, 6042], ["Hippopotamus melitensis", 6281, 6304], ["H. minutus", 6326, 6336], ["H. madagascariensis", 6491, 6510]] 
	false positives : [["Hippopotarnes nains", 463, 482], ["Hippopotame adulle", 2631, 2649], ["Chcer opsis", 3339, 3350]] 
	false negatives : [["Hippopotamus amphibius major", 6020, 6048]] 
	precision = 62.50 %
	recall = 83.33 %
	F-measure = 71.43 %
Evaluation of the article : page_554 :
	true positives : [["Gonioma Kamassi", 2854, 2869]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_622 :
	true positives : [["veronica speciosa", 6770, 6787], ["helianthus rigidus", 6819, 6837], ["helianthus orgyalis", 6924, 6943]] 
	false positives : [["Amplitudes diurnes", 2137, 2155]] 
	false negatives : [] 
	precision = 75.00 %
	recall = 100.00 %
	F-measure = 85.71 %
Evaluation of the article : page_582 :
	true positives : [["polygonum cuspidatum", 6977, 6997]] 
	false positives : [["Amplitudes diurnes", 1951, 1969]] 
	false negatives : [] 
	precision = 50.00 %
	recall = 100.00 %
	F-measure = 66.67 %
Evaluation of the article : page_92 :
	true positives : [["Catarrhactes chrysolophus", 1997, 2022], ["Pygoscelis antarctica", 2071, 2092], ["Catarrhactes chrysolophus", 3177, 3202], ["Pygoscelis antarctica", 3690, 3711]] 
	false positives : [["Pingouins antarctiques", 4703, 4725], ["dermer plongeon", 5950, 5965], ["ygoscelis papua", 6587, 6602], ["P. papou", 3331, 3339]] 
	false negatives : [["P, Adeli\u00e6", 2107, 2116], ["Aptenodytes Forsteri", 3342, 3362], ["P.papua", 3377, 3384], ["Catarrhacteschrysolophus", 3388, 3412], ["P ygoscelis papua", 6585, 6602], ["Pygoscelis Adeli\u00e6", 7654, 7671]] 
	precision = 50.00 %
	recall = 40.00 %
	F-measure = 44.44 %
Evaluation of the article : page_257 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_479 :
	true positives : [["uassia amara", 2056, 2068]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_623 :
	true positives : [] 
	false positives : [["Linde fournira", 25442, 25456]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_552 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_651 :
	true positives : [["Falco tinnunculus", 7356, 7373], ["Aceipiter nisus", 7730, 7745], ["Buteo vulgaris", 8177, 8191]] 
	false positives : [["Rapaces bienfaisants", 6949, 6969]] 
	false negatives : [["Astur.palumbarius", 7998, 8015]] 
	precision = 75.00 %
	recall = 75.00 %
	F-measure = 75.00 %
Evaluation of the article : page_194 :
	true positives : [] 
	false positives : [["Milton Dana", 68, 79], ["sourcier Kurringer", 8296, 8314], ["Franvins ctpar", 17310, 17324], ["F. Barrett", 5733, 5743]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_103 :
	true positives : [["Phyteuma Villarsi", 3856, 3873]] 
	false positives : [] 
	false negatives : [["Phyt. Charmelii", 4505, 4520]] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_538 :
	true positives : [["Xantophyllum lanceatum", 11633, 11655]] 
	false positives : [["Leo Stevens", 7844, 7855], ["Zana distante", 14720, 14733]] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_306 :
	true positives : [] 
	false positives : [["Ecoles nationales", 1442, 1459]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_124 :
	true positives : [["Picea esvention", 2804, 2819], ["Betula nana", 7265, 7276], ["Coronella austriaca", 7942, 7961], ["Eryngium maritimum", 8244, 8262], ["Cypripedium calceolus", 8442, 8463], ["Ophrys muscifera", 8469, 8485], ["Eryngium maritimum", 10258, 10276]] 
	false positives : [["Porta Westfalica", 5070, 5086], ["Isar acheta", 5640, 5651], ["Poria Westfalica", 7987, 8003]] 
	false negatives : [["Pices berg", 2711, 2721]] 
	precision = 70.00 %
	recall = 87.50 %
	F-measure = 77.78 %
Evaluation of the article : page_136 :
	true positives : [["Carex stricta", 8230, 8243], ["Carex stricta", 9961, 9974], ["Phragmites comcelle", 9979, 9998], ["Typha angustifolia", 11136, 11154], ["Juncus obtusiflorus", 11158, 11177], ["Scirpus lacustris", 11183, 11200], ["Carex stricta", 13372, 13385], ["Carex riparia", 13400, 13413], ["Scirpus lacustris", 13516, 13533], ["Scirpus lacus", 13546, 13559], ["Scirpus lacustris", 13571, 13588]] 
	false positives : [] 
	false negatives : [["Carex .stricta", 13725, 13739]] 
	precision = 100.00 %
	recall = 91.67 %
	F-measure = 95.65 %
Evaluation of the article : page_222 :
	true positives : [] 
	false positives : [["Sao Paulo", 1329, 1338], ["Garros vainqueur", 3383, 3399]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %

overall scores on the corpus vol83:
	precision = 53.48 %
	recall = 81.56 %
	F-measure = 64.60 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## starting evaluation of volume vol126
Evaluation of the article : page_472 :
	true positives : [["Ac\u00e6na argentea", 3373, 3387], ["Antholcus varinervis", 4156, 4176], ["Ac\u00e6na argentea", 9368, 9382]] 
	false positives : [["Miller retourna", 10578, 10593]] 
	false negatives : [["ANTHOLCUS VARINERVIS", 1841, 1861], ["Ac\u00e6na sanguisorb\u00e6", 2512, 2529]] 
	precision = 75.00 %
	recall = 60.00 %
	F-measure = 66.67 %
Evaluation of the article : page_381 :
	true positives : [] 
	false positives : [["portugais Bomba", 1719, 1734], ["Procession religieuse", 6444, 6465], ["Statuelies votives", 13139, 13157]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_122 :
	true positives : [] 
	false positives : [["Pedro Jevenois", 18129, 18143], ["Garcia Fara", 18629, 18640], ["Gallego Herrera", 20934, 20949], ["Curvas dromocronicas", 29193, 29213], ["Punta Ferdigua", 38142, 38156], ["Medina Sidonia", 38546, 38560], ["Tissier abrite", 50581, 50595], ["Calligraphia gr\u0153\u00e6ca", 74009, 74028], ["G. Sineriz", 18265, 18275], ["G. Sineriz", 35538, 35548], ["G. Sineris", 35723, 35733], ["G. Sineriz", 40047, 40057]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_536 :
	true positives : [] 
	false positives : [["Marius Houlier", 3607, 3621], ["Mimoso Serra", 5060, 5072], ["Mathematica dilettevole", 6891, 6914], ["Liber Abaci", 7251, 7262], ["Griffon bruxellois", 11211, 11229], ["water polo", 13987, 13997], ["L. Emir", 4659, 4666], ["L. Nordmann", 60146, 60157]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_160 :
	true positives : [["Perca latus", 3828, 3839], ["Sci\u00e6na umbra", 6939, 6951], ["Perca latus", 6973, 6984], ["Malapterurus electricus", 8735, 8758], ["Mormyre axyrhynaque", 13703, 13722], ["Mormyrus oxyrhynchus", 15039, 15059], ["Trigon vulgaris", 17600, 17615], ["Trigon lymne", 19119, 19131]] 
	false positives : [["Silure trembleur", 8810, 8826], ["Pastenague lymne", 17491, 17507], ["Hisloire nalurelle", 21510, 21528], ["P. Hiprozyre", 23047, 23059]] 
	false negatives : [["Trygon Lymne", 19297, 19309]] 
	precision = 66.67 %
	recall = 88.89 %
	F-measure = 76.19 %
Evaluation of the article : page_527 :
	true positives : [["Medicago satiwa", 13529, 13544], ["Atriplex semibaccata", 14491, 14511], ["Medicago faleaia", 14861, 14877]] 
	false positives : [["cerra Blanco", 9432, 9444], ["Toscas calcareas", 17743, 17759], ["Toscas argentines", 17868, 17885], ["Bolivie montagneuse", 29079, 29098], ["Chaco torride", 30960, 30973]] 
	false negatives : [["Atriplexz cachiyuyo", 14468, 14487], ["\u00c6Elephas meridionalis", 23908, 23929], ["Atriplez cachiyuyo", 28070, 28088]] 
	precision = 37.50 %
	recall = 50.00 %
	F-measure = 42.86 %
Evaluation of the article : page_576 :
	true positives : [["Zostera marina", 19357, 19371], ["Z. nana", 19375, 19382], ["Z. nana", 19601, 19608], ["Z. marina", 19638, 19647], ["Z. nana", 22208, 22215]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_289 :
	true positives : [] 
	false positives : [["Christiana Minekompani", 36855, 36877], ["Haber creusa", 37544, 37556], ["H. Kavser", 26482, 26491], ["H. Konxen", 26495, 26504], ["C. Tourneux", 30541, 30552]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_215 :
	true positives : [] 
	false positives : [["Madonna della", 74973, 74986], ["Monsignor Angelo", 77117, 77133], ["Paino Arcivescovo", 77135, 77152], ["Archimandrita Donando", 77156, 77177], ["Messina questo", 77180, 77194], ["Orologio Miracolo", 77203, 77220], ["Richiamo dei", 77422, 77434], ["Angelo Paino", 77542, 77554], ["A. Gould", 2682, 2690], ["P. Chappuis", 4833, 4844], ["A. Michelson", 6810, 6822], ["R. Castaing", 80128, 80139]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_386 :
	true positives : [["Oxypleurus Nodieri", 11652, 11670]] 
	false positives : [["Jeme souviens", 3823, 3836], ["Arias aetarietinr", 5057, 5074], ["Nodier rencontra", 6384, 6400]] 
	false negatives : [["Carabus aurenitens", 3796, 3814], ["O\u00e9ypleurus Nodieri", 10191, 10209]] 
	precision = 25.00 %
	recall = 33.33 %
	F-measure = 28.57 %
Evaluation of the article : page_295 :
	true positives : [["Welwitschia mirabilis", 1773, 1794], ["Welwitschia mirabilis", 3543, 3564], ["Welvitschia mirabilis", 3623, 3644], ["Odontopus sexpunctatus", 4930, 4952]] 
	false positives : [["Welvitschia orme", 5047, 5063]] 
	false negatives : [] 
	precision = 80.00 %
	recall = 100.00 %
	F-measure = 88.89 %
Evaluation of the article : page_11 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_80 :
	true positives : [] 
	false positives : [["Dolomie siliceuse", 6039, 6056]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_22 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_377 :
	true positives : [["Physeter macrocephalus", 1673, 1695], ["Bal\u00e6noptera acutorostrata", 1714, 1739], ["Bal\u00e6na biscayensis", 1753, 1771], ["Bal\u00e6noptera physalus", 7313, 7333], ["Bal\u00e6na biscayensis", 7422, 7440], ["Delphis delphis", 8376, 8391], ["Phocaena phocaena", 8413, 8430], ["Grampus griseus", 8446, 8461], ["Orcinus orca", 8463, 8475], ["Globicephalus melas", 8490, 8509], ["Tursiops tursio", 8525, 8540], ["Delphinus algeriensis", 8998, 9019], ["Delphinus delphis", 9329, 9346], ["Phoc\u00e6na phoc\u00e6na", 9350, 9365], ["Grampus griseus", 9438, 9453], ["Orcinus orca", 9850, 9862], ["Tursiops tursio", 9908, 9923], ["llex Paraguayensis", 17048, 17066], ["D. plombeus", 9087, 9098]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_108 :
	true positives : [] 
	false positives : [["Gourbes isostatiques", 912, 932], ["Favre conseille", 16119, 16134], ["Campine estla", 37691, 37704], ["Campine avantles", 41462, 41478], ["G. Danet", 21226, 21234], ["G. Geo", 37158, 37164]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_283 :
	true positives : [["Sepia officinalis", 2905, 2922], ["Sepia officinalis", 2967, 2984], ["Petromyzon fluviatilis", 8190, 8212], ["Petromyzon marinus", 8250, 8268]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_93 :
	true positives : [["Manatus senegalensis", 24812, 24832], ["Arctocephalus antarcticus", 28625, 28650]] 
	false positives : [] 
	false negatives : [["M. americanus", 24863, 24876]] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : page_500 :
	true positives : [["Scilla marilima", 10076, 10091]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_433 :
	true positives : [] 
	false positives : [["Flora sinensis", 78523, 78537], ["Plantae medicinalis", 78539, 78558], ["Chinese materia", 78568, 78583], ["Lanoline anhydre", 89352, 89368], ["Chevaliers teutoniques", 109031, 109053], ["L. Dudley", 52978, 52987], ["P. Guillemet", 76828, 76840], ["P. Guillemet", 78062, 78074], ["P. Bouraoin", 169859, 169870]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_64 :
	true positives : [] 
	false positives : [["Mercurio Europeo", 862, 878], ["Mercurio Europeo", 3091, 3107], ["Hacienda nomma", 5871, 5885]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_551 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_432 :
	true positives : [["Triodendron anfractuosum", 919, 943]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_120 :
	true positives : [["Bison bonasus", 1884, 1897], ["Bos primigenius", 1986, 2001], ["Rhinoceros trichorhinus", 2189, 2212], ["Ursus spel\u00e6us", 2214, 2227]] 
	false positives : [["nomma Urus", 3175, 3185]] 
	false negatives : [] 
	precision = 80.00 %
	recall = 100.00 %
	F-measure = 88.89 %
Evaluation of the article : page_475 :
	true positives : [] 
	false positives : [["chancelier Hitler", 69074, 69091]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_146 :
	true positives : [] 
	false positives : [["Consultations gratuites", 31861, 31884]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_548 :
	true positives : [["Anchusa linctoria", 4423, 4440]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_145 :
	true positives : [["Casianea sativa", 5696, 5711]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_38 :
	true positives : [] 
	false positives : [["saura retrancher", 1847, 1863], ["Phenomena hydrauliea-pneumatica", 10858, 10889], ["Mersenne utilisa", 14931, 14947], ["Eclipse iotale", 25738, 25752], ["Meyerson exposa", 50488, 50503], ["P. Mersenne", 6868, 6879], ["P. Mersenne", 10265, 10276], ["P. Mersenne", 11457, 11468], ["P. Mersenne", 12335, 12346], ["P. Mersenne", 12892, 12903], ["P. Mersenne", 13793, 13804], ["P. Mersenne", 15837, 15848], ["P. Mersenne", 17653, 17664], ["P. Mersenne", 17957, 17968], ["P. Bs", 25072, 25077]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_190 :
	true positives : [] 
	false positives : [["Allier abonde", 55253, 55266]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_533 :
	true positives : [["Euryopis acuminata", 4621, 4639], ["Olios c\u00e6nobita", 5953, 5967], ["Cyclosa turbinata", 10752, 10769], ["Meta merianae", 12758, 12771]] 
	false positives : [] 
	false negatives : [["Meta merian\u00e6", 8351, 8363]] 
	precision = 100.00 %
	recall = 80.00 %
	F-measure = 88.89 %
Evaluation of the article : page_389 :
	true positives : [] 
	false positives : [["usager constatera", 13348, 13365], ["Aussile radiophonographe", 25482, 25506], ["Dextrine blonde", 36056, 36071], ["Mantes via", 55016, 55026], ["Emme memes", 60981, 60991], ["Puszta hongroise", 85001, 85017], ["Fata Morgana", 92888, 92900], ["E. Darmois", 40650, 40660], ["P. Buxyer", 42506, 42515], ["E. Fazz", 45067, 45074], ["E. Chiron", 74722, 74731]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_297 :
	true positives : [] 
	false positives : [["Permutite alcaline", 21158, 21176], ["-viela solubilisation", 25268, 25289], ["Agro romano", 39286, 39297], ["Bonifica della", 43157, 43171], ["Lago Lunga", 43201, 43211], ["Fore apoenne", 47206, 47218], ["Volsques porta", 48587, 48601], ["Appius Claudius", 48736, 48751], ["Regina Viarum", 48810, 48823], ["Via Appia", 49612, 49621], ["Linea Pia", 50742, 50751], ["Linea Pia", 51122, 51131], ["Pontins assainis", 53433, 53449], ["Fosso Moscarello", 55336, 55352], ["Linea Pia", 56236, 56245], ["Piazza Daittorio", 59276, 59292], ["Agro Pontino", 59557, 59569], ["Littoria abrite", 60518, 60533], ["Lua pula", 85161, 85169], ["synchronisation Bston", 102589, 102610], ["A. Chaplet", 20075, 20085]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_104 :
	true positives : [["Cebus paraguayensis", 12127, 12146]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_18 :
	true positives : [["Alligator mississipiensis", 1228, 1253]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_412 :
	true positives : [["Ursus arctos", 1492, 1504]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_287 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_99 :
	true positives : [["Medicago sativa", 2100, 2115], ["Raphanus raphanistrum", 2751, 2772], ["Sinapis arvensis", 2821, 2837], ["Medicago falcata", 3470, 3486]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_581 :
	true positives : [] 
	false positives : [] 
	false negatives : [["\u00c6Echinocactus ingens", 377, 397]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_165 :
	true positives : [] 
	false positives : [["Kirghises nomades", 86480, 86497], ["Iraniens samanides", 86982, 87000], ["Pelouze accepta", 101803, 101818], ["Pelouze accepta", 102044, 102059]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_98 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_100 :
	true positives : [] 
	false positives : [["Babbage tenta", 6653, 6666], ["Quevedo apporta", 6726, 6741]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_414 :
	true positives : [] 
	false positives : [["Violle proposa", 6815, 6829], ["Kotaro Honda", 43674, 43686], ["Kotaro Honda", 44168, 44180]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_558 :
	true positives : [["Ovis studeri", 9188, 9200], ["Hydroch\u0153rus capybara", 10151, 10171]] 
	false positives : [["legon amena", 1691, 1702], ["Chiare jresche", 4917, 4931], ["Friquets abrite", 5001, 5016]] 
	false negatives : [] 
	precision = 40.00 %
	recall = 100.00 %
	F-measure = 57.14 %
Evaluation of the article : page_56 :
	true positives : [["Homo capensis", 1433, 1446], ["Homo sapiens", 3462, 3474], ["Elephas antiquus", 12970, 12986], ["Elephas antiquus", 13122, 13138], ["Elephas antiquus", 13294, 13310], ["Hippopotamus amphibius", 13325, 13347], ["Pelorovis oldowayensis", 13363, 13385], ["Elephas antiquus", 13677, 13693], ["Pelorovis oldowayensis", 14605, 14627], ["Equus (Hippotigris) Hollisi", 16288, 16315], ["Rhinoceros bicornis", 16367, 16386], ["Hippopotamus amphibius", 16391, 16413], ["Procavia abyssinica", 17069, 17088], ["Homo mediterraneus", 36463, 36481], ["Homo sapiens", 38318, 38330], ["P. Mackinderi", 17121, 17134]] 
	false positives : [["Knysna implique", 2391, 2406], ["Lalla Marnia", 28371, 28383], ["Caton Thompson", 36606, 36620], ["Homo afer", 41365, 41374], ["R. Broom", 317, 325], ["R. Drennan", 340, 350], ["H. Wells", 357, 365], ["R. Broom", 742, 750], ["H. Vallois", 1001, 1011], ["R. Drennan", 1163, 1173], ["R. Dart", 1678, 1685], ["R. Broom", 1687, 1695], ["R. Drennan", 1710, 1720], ["H. Wells", 1725, 1733], ["H. Wells", 2925, 2933], ["E. Salmons", 3730, 3740], ["H. Wells", 3745, 3753], ["R. Drennan", 3780, 3790], ["H. Vallois", 5359, 5369], ["H. Vallois", 7885, 7895], ["H. Reck", 11913, 11920], ["H. Reck", 12826, 12833], ["P. Brookes", 15685, 15695], ["E. Bleek", 20943, 20951], ["E. Blecck", 21638, 21647], ["P. Culwick", 22107, 22117], ["E. Bleek", 23423, 23431], ["C. Arambourg", 26559, 26571], ["E. Garrod", 27135, 27144], ["H. Obermaier", 28710, 28722], ["H. Vallois", 28742, 28752], ["H. Vallois", 29770, 29780], ["E. Garrod", 33198, 33207], ["E. Garrod", 36028, 36037], ["C. Arambourg", 39293, 39305], ["L. Joreaun", 42467, 42477]] 
	false negatives : [["Buffelus Bainu", 2564, 2578], ["Hippopotamus amphibius gorgops", 13325, 13355], ["Bu\u00ffffelus antiquus", 16323, 16341], ["P. \u00c6Erlangeri", 17098, 17111], ["Homo afer taganus", 41365, 41382]] 
	precision = 30.77 %
	recall = 76.19 %
	F-measure = 43.84 %
Evaluation of the article : page_6 :
	true positives : [["Homo sapiens", 5973, 5985], ["Homo sapiens", 6586, 6598], ["Homo sapiens", 7150, 7162], ["Homo capensis", 13347, 13360], ["Homo sapiens", 15149, 15161], ["Homo sapiens", 15454, 15466], ["Sinanthropus pekinensis", 15991, 16014], ["Homo sapiens", 22057, 22069], ["Homo sapiens", 22345, 22357], ["Homo neanderthalensis", 22374, 22395], ["Homo sapiens", 22420, 22432], ["Homo sapiens", 22873, 22885], ["Homo palestinus", 22992, 23007], ["Homo sapiens", 23113, 23125], ["Homo (Javanthropus) soloensis", 23419, 23448]] 
	false positives : [["Quina ftraits", 1683, 1696], ["antiquus Recki", 15351, 15365], ["Homo (Palaeanthropus) neanderthalensis", 21289, 21327], ["Hippopotame hexaprotodonte", 24320, 24346], ["Hippopotame hexaprotodonte", 24420, 24446], ["H. Reck", 14962, 14969], ["H. Breuil", 19002, 19011]] 
	false negatives : [["\u00c2omo sapiens", 12788, 12800], ["\u00c6Elephas antiquus", 15342, 15359], ["Homo (Palaeanthropus) neanderthalensis palestinus", 21289, 21338]] 
	precision = 68.18 %
	recall = 83.33 %
	F-measure = 75.00 %
Evaluation of the article : page_204 :
	true positives : [["Saccharum officinarum", 6594, 6615], ["Solanum iuberosum", 32282, 32299], ["Solanum luberosum", 32337, 32354], ["Solanum stoloniferum", 32385, 32405], ["Solunum Fendleri", 32448, 32464], ["Solanum tuberosum", 38700, 38717], ["Solanum stoloniferum", 40084, 40104], ["Solanum tuberosum", 40493, 40510], ["S. longiconicum", 40281, 40296], ["S. pinnasectum", 40322, 40336]] 
	false positives : [["Copper Corporation", 5185, 5203], ["acceptum Viennae", 35828, 35844], ["Papas peruanum", 35862, 35876], ["Costa Rica", 40300, 40310]] 
	false negatives : [] 
	precision = 71.43 %
	recall = 100.00 %
	F-measure = 83.33 %
Evaluation of the article : page_241 :
	true positives : [] 
	false positives : [["voudrais crier", 70861, 70875]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_267 :
	true positives : [] 
	false positives : [["Florine iype", 4019, 4031], ["Florine montrera", 8014, 8030], ["Hispano Suiza", 8928, 8941], ["Katanga abonde", 35544, 35558], ["Contacter electrique", 56244, 56264]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_237 :
	true positives : [["Fraxinus excelsior", 15247, 15265], ["Onthophagus taurus", 16834, 16852], ["Onthophagus taurus", 16902, 16920], ["Pistacia terebinihus", 19772, 19792], ["Pistacia terebinthus", 20045, 20065], ["Pistacia terebinthus", 21168, 21188], ["Pistacia terebinthus", 21221, 21241], ["Valgus hemipterus", 21378, 21395], ["Valgus hemipterus", 21559, 21576], ["Valgus hemipierus", 22235, 22252], ["Onthophagus taurus", 26205, 26223]] 
	false positives : [["Julius Sunyer", 1241, 1254], ["Palpes maxillaires", 27121, 27139], ["Mandibules membraneuses", 28102, 28125], ["Palpes labiales", 28372, 28387], ["J. Guichard", 594, 605]] 
	false negatives : [] 
	precision = 68.75 %
	recall = 100.00 %
	F-measure = 81.48 %
Evaluation of the article : page_36 :
	true positives : [["Pyrophorus noctilucus", 5320, 5341]] 
	false positives : [] 
	false negatives : [["P: noctilucus", 2365, 2378]] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : page_262 :
	true positives : [["Azorella antipoda", 846, 863], ["Ac\u0153\u00e6na affinis", 1624, 1638], ["Festuca Kerguelensis", 5934, 5954], ["Thuya tetragona", 6560, 6575], ["Thuya tetragonia", 6827, 6843], ["Araucaria imbricata", 7064, 7083], ["Pringlea antiscorbutica", 7484, 7507], ["Festuca Kerguelensis", 12270, 12290], ["Azorella Selago", 14829, 14844], ["Barbula validinervis", 17917, 17937], ["Grimmia cupularis", 17941, 17958], ["Campylopus austro-siramineus", 17982, 18010], ["Campylopus austro-stramineus", 18959, 18987], ["Drepanocladus uncinatus", 19170, 19193], ["Placodium mexicanum", 20813, 20832], ["Neuropogon trachycarpus", 20904, 20927], ["Galera tenera", 22496, 22509], ["Macrocystis pyrifera", 22706, 22726], ["A. Selago", 14563, 14572], ["A. patagonica", 14581, 14594], ["A. trifurcata", 14620, 14633], ["C. stramineus", 19063, 19076], ["N. trachycarpus", 21377, 21392], ["N. trachycarpus", 21959, 21974]] 
	false positives : [] 
	false negatives : [["A.trifoliata", 14603, 14615], ["\u00c0. antipoda", 14730, 14741]] 
	precision = 100.00 %
	recall = 92.31 %
	F-measure = 96.00 %
Evaluation of the article : page_189 :
	true positives : [["Manta brevirostra", 3365, 3382]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_582 :
	true positives : [] 
	false positives : [["della Preta", 33410, 33421], ["Minimas mensuelles", 37911, 37929], ["Julius Springer", 63432, 63447], ["J. Chaussin", 15499, 15510], ["J. Cnaussin", 31742, 31753]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_188 :
	true positives : [["Allium sativum", 4180, 4194]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_602 :
	true positives : [["Welwitschia mirabilis", 12543, 12564], ["Wekwitschia mirabilis", 25352, 25373]] 
	false positives : [["Citernes amovibles", 2825, 2843], ["Isolants calorifuges", 5909, 5929], ["Citernes amovibles", 18851, 18869], ["Isolants calorifuges", 18891, 18911], ["Does sms", 23124, 23132], ["Isolants calorifuges", 27810, 27830], ["Citernes amovibles", 30300, 30318], ["C. Jose", 23170, 23177]] 
	false negatives : [] 
	precision = 20.00 %
	recall = 100.00 %
	F-measure = 33.33 %
Evaluation of the article : page_288 :
	true positives : [["Indigofera tinctoria", 2136, 2156]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_75 :
	true positives : [["Helolontha fullo", 16142, 16158], ["Melolontha fullo", 16766, 16782]] 
	false positives : [["Exner distingua", 4304, 4319]] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_286 :
	true positives : [["Pegomyia hyosciama", 3670, 3688]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_327 :
	true positives : [] 
	false positives : [["Pravda Vostoka", 12801, 12815], ["Xavier Marmier", 49581, 49595], ["Ergebnisse geologischer", 79360, 79383], ["selcnla chanson", 142659, 142674], ["X. Marmier", 41601, 41611], ["E. Douszer", 57748, 57758], ["E. Schweizerbart", 79602, 79618], ["E. Bowes", 81761, 81769], ["E. Esclangon", 148116, 148128], ["P. Liau", 148319, 148326], ["P. Liau", 148382, 148389]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_326 :
	true positives : [["Cetorhinus maximus", 3208, 3226], ["Dinemoura producta", 4892, 4910], ["Nemesis lamna", 5107, 5120], ["Dinobothrium plicitum", 5269, 5290]] 
	false positives : [["porco monstroso", 2420, 2435], ["horribilibus monstris", 2454, 2475], ["Litiorum Norvegiae", 2476, 2494]] 
	false negatives : [] 
	precision = 57.14 %
	recall = 100.00 %
	F-measure = 72.73 %
Evaluation of the article : page_502 :
	true positives : [] 
	false positives : [["Tendilha Retha", 7588, 7602], ["Ailas linguistique", 21669, 21687], ["Variantes juqguoir", 21734, 21752], ["neutraliser laction", 60280, 60299], ["Ungerva ravitailleur", 85974, 85994], ["A. Piccard", 31135, 31145]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_561 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %

overall scores on the corpus vol126:
	precision = 41.09 %
	recall = 87.85 %
	F-measure = 55.99 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## starting evaluation of volume vol12
Evaluation of the article : page_138 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_82 :
	true positives : [["aspidosperma Gomesianum", 1396, 1419]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_232 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_387 :
	true positives : [] 
	false positives : [["Casola Valsenio", 1723, 1738], ["Casola Valsenio", 1861, 1876], ["Casola Valsenio", 2141, 2156], ["Casola Valsenio", 2504, 2519]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_139 :
	true positives : [["Gentiana glacialis", 12691, 12709], ["Daphne cn\u00e6orum", 12714, 12728]] 
	false positives : [] 
	false negatives : [["Sa lir herbac\u00e6a", 12733, 12748]] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : vol12_page_212 :
	true positives : [["Cofinga maynana", 1620, 1635], ["Guacamaya colorada", 1806, 1824], ["Troyon pavoninus", 2154, 2170], ["Tinnunculus sparverius", 2756, 2778]] 
	false positives : [["Panache maure", 1206, 1219], ["Pine preneur", 2918, 2930]] 
	false negatives : [] 
	precision = 66.67 %
	recall = 100.00 %
	F-measure = 80.00 %
Evaluation of the article : page_83 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_155 :
	true positives : [] 
	false positives : [["Deville consacre", 4966, 4982], ["Cosmos esi", 6088, 6098], ["Veufs avecenfants", 35493, 35510]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_91 :
	true positives : [] 
	false positives : [["guerrier Osycba", 12468, 12483], ["Hache pahouine", 19063, 19077]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_310 :
	true positives : [["Solanum laciniatum", 8706, 8724]] 
	false positives : [["Nouka Hiva", 4000, 4010], ["Foyage aulour", 6922, 6935]] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_1 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_147 :
	true positives : [] 
	false positives : [["Prosper Guyor", 1824, 1837]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_118 :
	true positives : [["Bathynomus giganteus", 3311, 3331]] 
	false positives : [["Isopodes marcheurs", 7688, 7706], ["Cymothoadiens errants", 7903, 7924], ["Cymothoadiens errants", 8345, 8366]] 
	false negatives : [] 
	precision = 25.00 %
	recall = 100.00 %
	F-measure = 40.00 %
Evaluation of the article : vol12_page_51 :
	true positives : [["Elephas primigenius", 684, 703], ["Rhinoceros lichorinus", 710, 731], ["Bos urus", 1885, 1893], ["B. priscus", 1906, 1916], ["B. latifrons", 1926, 1938], ["B. europ\u0153us", 2027, 2038], ["B. primigenius", 2198, 2212], ["B. trachoceras", 2372, 2386], ["B. frontosus", 2402, 2414], ["B. longifrons", 2833, 2846], ["B. brachyceras", 3035, 3049], ["B. brachycephalus", 3227, 3244]] 
	false positives : [["iaurus ligeriensis", 2268, 2286], ["taurus jurassicus", 2809, 2826], ["laurus balavicus", 2928, 2944], ["taurus alpinus", 3073, 3087], ["B. iaurus", 2265, 2274], ["B. taurus", 2806, 2815], ["B. laurus", 2925, 2934], ["B. taurus", 3070, 3079], ["R. Viox", 3369, 3376]] 
	false negatives : [["B, antiquus", 1950, 1961], ["PB americanus", 2007, 2020], ["B. iaurus ligeriensis", 2265, 2286], ["B. taurus jurassicus", 2806, 2826], ["B, primigenius", 2874, 2888], ["B. laurus balavicus", 2925, 2944], ["B. taurus alpinus", 3070, 3087]] 
	precision = 57.14 %
	recall = 63.16 %
	F-measure = 60.00 %
Evaluation of the article : page_108 :
	true positives : [] 
	false positives : [["ultima ratio", 4856, 4868]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_328 :
	true positives : [["Epidendrum Vanilla", 644, 662], ["Vanilla aromatica", 961, 978], ["Vanilla sativa", 10178, 10192], ["Vanilla planifolia", 13018, 13036], ["Oclomeria graminifolia", 13167, 13189], ["Brassavola cordata", 13196, 13214], ["Angr\u00e6cum fragrans", 15830, 15847], ["V. quianensis", 10245, 10258], ["V. palmarum", 10305, 10316], ["V. planifolia", 10484, 10497], ["V. Pompona", 10604, 10614]] 
	false positives : [] 
	false negatives : [["\u0178. aromatica", 10344, 10356]] 
	precision = 100.00 %
	recall = 91.67 %
	F-measure = 95.65 %
Evaluation of the article : page_230 :
	true positives : [["Cinnyris Adalberti", 471, 489], ["Semnopithecus monspessulanus", 3745, 3773]] 
	false positives : [["Gervais aborda", 2944, 2958], ["Pal\u00e6otheriums parlsiens", 4893, 4916], ["P. Gervais", 3478, 3488], ["P. Gervus", 5735, 5744]] 
	false negatives : [] 
	precision = 33.33 %
	recall = 100.00 %
	F-measure = 50.00 %
Evaluation of the article : page_221 :
	true positives : [] 
	false positives : [["Pacide borique", 7025, 7039], ["Agenda vade", 13837, 13848], ["Wilkes emmena", 16938, 16951], ["Spectacles selentifiques", 31402, 31426]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_420 :
	true positives : [["Rhinocerus tichorhinus", 235, 257]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_113 :
	true positives : [] 
	false positives : [["tophasma Dumasi", 8849, 8864]] 
	false negatives : [["Pro: tophasma Dumasi", 8844, 8864]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_390 :
	true positives : [] 
	false positives : [["Varialions nocturnes", 60361, 60381]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_312 :
	true positives : [] 
	false positives : [["Bruchus obfectus", 54187, 54203]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_12 :
	true positives : [] 
	false positives : [["chapska polonais", 7982, 7998], ["Lapons nomades", 17921, 17935], ["Lapons blonds", 18500, 18513], ["Iowa Weaiher", 32284, 32296], ["Andamento diurno", 32589, 32605], ["Domenico Racowa", 32658, 32673], ["Chabrier appuya", 61221, 61236], ["Sie mens", 101518, 101526], ["Memoria sobre", 110551, 110564], ["sistema metrico", 110568, 110583], ["I. Bierzy", 31396, 31405], ["D. Appleton", 31565, 31576], ["C. Towwe", 31738, 31746], ["L. Paruierr", 49447, 49458], ["L. Muybridge", 79451, 79463], ["A. Seccyt", 162748, 162757]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_148 :
	true positives : [["Sarracenia purpurea", 2129, 2148]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_104 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_251 :
	true positives : [] 
	false positives : [["usum delphini", 35017, 35030], ["Figuier aspire", 43242, 43256], ["Finitiative individuelle", 50789, 50813], ["Pantzer sombra", 70150, 70164], ["Aevues hebdomadaires", 79658, 79678], ["Batraciens anoures", 91209, 91227], ["Gutte parcelle", 132491, 132505], ["Drauings made", 178529, 178542], ["Moss abonde", 180276, 180287], ["Triton alpestre", 232369, 232384], ["A. Young", 21126, 21134], ["D. Cassini", 75705, 75715], ["A. Varley", 85723, 85732], ["P. Drnrnan", 150179, 150189], ["A. Destrem", 154073, 154083], ["P. Cravoe", 156741, 156750], ["A. Secondement", 157478, 157492], ["F. Iayez", 205037, 205045], ["A. Guyard", 242178, 242187], ["A. Agassis", 265821, 265831], ["G. Tissaxnren", 271776, 271789]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_120 :
	true positives : [] 
	false positives : [["Rhizo Carpasso", 1290, 1304], ["Mia Milia", 6864, 6873], ["Brazza acheta", 53426, 53439], ["Brazza renvoya", 55935, 55949], ["Melchior Guillandinus", 68267, 68288]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_60 :
	true positives : [["Papilio Laglaizei", 3285, 3302], ["Megalodon ensifer", 5129, 5146], ["P. speciosa", 3764, 3775], ["P. speciosa", 4359, 4370], ["P. speciosa", 4559, 4570], ["P. armata", 4856, 4865]] 
	false positives : [["Ilistoire naturelte", 3806, 3825], ["P. grandis", 5009, 5019]] 
	false negatives : [["PHYLLOFHORA ARMATA", 58, 76], ["Nyctalemon Urontes", 3319, 3337]] 
	precision = 75.00 %
	recall = 75.00 %
	F-measure = 75.00 %
Evaluation of the article : page_146 :
	true positives : [["Dasychira pudibunda", 1497, 1516]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_429 :
	true positives : [["phylloxora armiita", 4058, 4076]] 
	false positives : [["Etna sors", 1181, 1190], ["Noctuclle piniperde", 3896, 3915], ["Helminthes entozonires", 9310, 9332], ["E. Frov", 953, 960], ["E. Ovsraser", 3953, 3964], ["E. Sauvace", 4747, 4757], ["E. Sauvacr", 4843, 4853], ["E. Trirar", 4948, 4957], ["E. Conriuserr", 6860, 6873]] 
	false negatives : [["S\u00e9pedon h\u0153\u00e6machale", 4517, 4535]] 
	precision = 10.00 %
	recall = 50.00 %
	F-measure = 16.67 %
Evaluation of the article : vol12_page_151 :
	true positives : [["Eleotraqus reduncus", 171, 190], ["Oryx leucoryx", 2570, 2583], ["Oryx beisa", 2988, 2998], ["Oryx gazella", 3101, 3113], ["Damalis albifions", 8710, 8727], ["Antilope albifions", 8737, 8755], ["Damalis pygargi", 8852, 8867], ["Antilope canna", 9321, 9335], ["Tragelaphus scriplus", 10839, 10859], ["Tragelaphus scriptus", 11745, 11765], ["Tragelaphus decula", 11868, 11886], ["Tragelaphus sylvaticus", 12042, 12064]] 
	false positives : [["eotragus arundinaceus", 247, 268], ["Antilopes rousses", 989, 1006], ["Antilopes typiques", 5133, 5151], ["Ganna rappclle", 10165, 10179], ["Nilgaus offerts", 14069, 14084]] 
	false negatives : [["E/eotragus arundinaceus", 245, 268]] 
	precision = 70.59 %
	recall = 92.31 %
	F-measure = 80.00 %
Evaluation of the article : vol12_page_166 :
	true positives : [] 
	false positives : [] 
	false negatives : [["S\u00e9pedon h\u0153machate", 138, 155], ["S\u00e9pedon h\u0153machate", 1254, 1271], ["S\u00e9pedon h\u0153machate", 1298, 1315]] 
	precision = 100.00 %
	recall = 0.00 %
	F-measure = 0.00 %
Evaluation of the article : page_417 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_413 :
	true positives : [["Bacillus Rossi", 615, 629], ["Enrycantha horrida", 2642, 2660], ["Broussonetia papyrifolia", 5246, 5270], ["Eurycantha calcarata", 5806, 5826], ["E. Australis", 3223, 3235], ["E. horrida", 5871, 5881], ["E. echinata", 5899, 5910], ["E. horrida", 6398, 6408]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_49 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_214 :
	true positives : [["Protum\u00e6ba prinitiva", 1261, 1280], ["Myxasirum radians", 1285, 1302], ["Protomyxa aurantiaca", 2143, 2163], ["Protam\u00e6ba primitiva", 6361, 6380], ["Bathybius H\u00e6ckeli", 7641, 7658], ["H\u00e6ckelina gigantea", 9115, 9133], ["Protomonas amyli", 10719, 10735], ["Protomonas gomphonematis", 10845, 10869], ["Protomyxa aurantiaco", 13360, 13380], ["Protomyxa aurantiaca", 16734, 16754], ["Myxastrum radians", 17544, 17561], ["Actinosph\u00e6rium Eichhornii", 18350, 18375]] 
	false positives : [] 
	false negatives : [["Protomyra ankyst\u00e9e", 2170, 2188], ["Myxodiclium sociale", 15450, 15469], ["Myxodictium sociale", 17639, 17658], ["Pro\u00e9omyra auruntiaca", 18532, 18552], ["Actinophrys sol", 27112, 27127], ["Actinosph\u00e6rium E\u00efichhornii", 27675, 27701]] 
	precision = 100.00 %
	recall = 66.67 %
	F-measure = 80.00 %
Evaluation of the article : vol12_page_353 :
	true positives : [] 
	false positives : [["Torule ammoniacale", 45140, 45158], ["Sacra Familia", 56893, 56906], ["Cyclode noirjaune", 88825, 88842], ["Volvox proprements", 113495, 113513], ["Euglena sanguinea", 113743, 113760], ["Astasia h\u0153matodes", 113764, 113781], ["Monas prodigiosa", 114004, 114020], ["Salping\u00e6ca Clarkii", 115141, 115159], ["V. Dave", 12815, 12822], ["T. Hamy", 15174, 15181], ["V. Meyer", 44965, 44973], ["E. Sauvacs", 90843, 90853], ["S. Resort", 96152, 96161]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_68 :
	true positives : [["t\u0153nia mediocanellata", 906, 926]] 
	false positives : [["\u00e6nia solium", 888, 899], ["\u00e6nia mediocanellata", 1301, 1320], ["Dee mour", 3470, 3478]] 
	false negatives : [["{\u00e6nia solium", 887, 899], ["f\u0153nia 8olium", 1141, 1153], ["{\u00e6nia mediocanellata", 1300, 1320]] 
	precision = 25.00 %
	recall = 25.00 %
	F-measure = 25.00 %
Evaluation of the article : vol12_page_56 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_8 :
	true positives : [["Eopteris Crier", 3675, 3689], ["Eopteris Morierei", 5377, 5394]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_384 :
	true positives : [["Gastornis Edwardsi", 5856, 5874], ["Gaslornis Edwardsi", 6291, 6309], ["Gastornis minor", 6561, 6576], ["Eupterornis remensis", 6756, 6776], ["Heterodiadema Lybicum", 8328, 8349], ["Holaster equiluberculatus", 9193, 9218], ["Archiacia Saadensis", 9597, 9616], ["Coptophyma problemalicum", 9642, 9666], ["Heterodiadema Libycum", 9872, 9893], ["Holaster senonensis", 9948, 9967], ["Holaster pilula", 9987, 10002]] 
	false positives : [["Salenia Bainensis", 9692, 9709]] 
	false negatives : [["H\u00e9miaster Balorensis", 9763, 9783], ["Goniopygus Messaoud", 9799, 9818]] 
	precision = 91.67 %
	recall = 84.62 %
	F-measure = 88.00 %
Evaluation of the article : vol12_page_351 :
	true positives : [["Vesperugo parisiensis", 3043, 3064], ["Tenia solium", 4496, 4508], ["Tenia perfoliata", 5831, 5847], ["Tenia pectinata", 5867, 5882], ["Tenia pectinala", 6612, 6627], ["Cysticercus pisiformis", 6758, 6780], ["Tenia serrata", 6956, 6969], ["Tenia serrata", 9744, 9757], ["Rumina decollata", 10809, 10825], ["Pelobales fuscus", 11946, 11962], ["Pelobates cullripes", 11980, 11999]] 
	false positives : [["Helminthes parasilaires", 5491, 5514]] 
	false negatives : [["Teniu perfoliata", 6539, 6555]] 
	precision = 91.67 %
	recall = 91.67 %
	F-measure = 91.67 %
Evaluation of the article : page_415 :
	true positives : [["Bos brachyceros", 1639, 1654], ["Succharomyces quitulatus", 9255, 9279], ["S. roseus", 8778, 8787]] 
	false positives : [] 
	false negatives : [["Saccharomyce Sminor", 8301, 8320]] 
	precision = 100.00 %
	recall = 75.00 %
	F-measure = 85.71 %
Evaluation of the article : vol12_page_347 :
	true positives : [["Tradescantia Virginica", 2668, 2690], ["Stephanosph\u00e6ra pluvialis", 7638, 7662], ["Magosph\u00e6ra planula", 10214, 10232], ["Fucus vusiculusus", 11479, 11496], ["\u0152dogonium gemelliparum", 11651, 11673], ["Bulboch\u00e6te intermedia", 11749, 11770], ["Nitella flexilis", 11806, 11822], ["Funaria hygrometrica", 11856, 11876], ["Sphagnum acutifohum", 11916, 11935], ["Equiselum arvense", 12040, 12057], ["Gonium pectorale", 13010, 13026], ["Magosph\u00e6ra planuia", 15296, 15314], ["Didymium leucojus", 15379, 15396], ["Mugosph\u00e6ra adulle", 15533, 15550], ["\u00c6thalium septicum", 17352, 17369], ["Ceratium hydnoides", 19838, 19856], ["Polysticta reticulata", 19863, 19884]] 
	false positives : [["th\u0153\u00e6a rosea", 2754, 2765], ["Adianthum capillus", 11971, 11989]] 
	false negatives : [["AZ th\u0153\u00e6a rosea", 2751, 2765], ["Adianthum capillus veneris", 11971, 11997], [" Volvoz globator", 13062, 13078], ["Labyrinthula macrocystis", 14480, 14504], ["Areyria incarn la", 15507, 15524]] 
	precision = 89.47 %
	recall = 77.27 %
	F-measure = 82.93 %
Evaluation of the article : page_422 :
	true positives : [["Phyllophora armata", 8604, 8622], ["phyllophora armata", 16082, 16100]] 
	false positives : [["Telminthes entozoaires", 5286, 5308], ["Noctuelle piniperde", 7925, 7944], ["Meptiles peumiens", 9507, 9524], ["Noctuelle piniperde", 14860, 14879], ["P. Gower", 17722, 17730], ["P. Gower", 10960, 10968]] 
	false negatives : [["S\u00e9pedon h\u0153machale", 9898, 9915], ["s\u00e9p\u00e9don h\u0153machate", 18929, 18946]] 
	precision = 25.00 %
	recall = 50.00 %
	F-measure = 33.33 %
Evaluation of the article : page_143 :
	true positives : [] 
	false positives : [["Junonia minor", 1098, 1111], ["Thedisio Doria", 2005, 2019], ["Castille envoya", 3557, 3572], ["Fernando Peraza", 3633, 3648], ["Diego Silva", 4287, 4298]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_246 :
	true positives : [["Gromia oviformis", 543, 559], ["Globigerina builoides", 571, 592], ["Antmalina hemisph\u00e6rica", 610, 632], ["Rosalina anomala", 649, 665], ["Lagenuiina costata", 681, 699], ["Dentalina punctata", 718, 736], ["Cristellaria iriangularis", 754, 779], ["Rotalia Venela", 2376, 2390], ["Cornuspira planorbis", 2396, 2416], ["Mihota flenera", 2435, 2449], ["Arachnocorys circumlexta", 17368, 17392], ["Amphilonche heteracanta", 17406, 17429], ["Doratospis polyanuystra", 22155, 22178], ["Cuchilonia Beckmanni", 22223, 22243]] 
	false positives : [] 
	false negatives : [["Aca\u00efthometra elaslica", 17443, 17464]] 
	precision = 100.00 %
	recall = 93.33 %
	F-measure = 96.55 %
Evaluation of the article : vol12_page_53 :
	true positives : [["Trachea piniperda", 586, 603]] 
	false positives : [["Noctuelle puuperde", 791, 809], ["Noctuelle piniperde", 1540, 1559], ["Noctuelle piniperde", 3785, 3804]] 
	false negatives : [] 
	precision = 25.00 %
	recall = 100.00 %
	F-measure = 40.00 %
Evaluation of the article : page_102 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_100 :
	true positives : [["Bathynomus qiyanteus", 6479, 6499]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_103 :
	true positives : [["Antilope dama", 242, 255], ["Gazslle dama", 456, 468], ["Gazelle mobhr", 514, 527], ["Gazelle dama", 1236, 1248], ["Gazelle mohr", 1299, 1311], ["Gazelle euchore", 2026, 2041], ["Gazelles euchores", 3256, 3273], ["Gazelle euchore", 6380, 6395], ["Antilope bezoartica", 6887, 6906], ["G. Soemmeringi", 1380, 1394]] 
	false positives : [["Cafres cherchentils", 10748, 10767]] 
	false negatives : [["Gazelle Granli", 1758, 1772], ["G.euchore", 2043, 2052]] 
	precision = 90.91 %
	recall = 83.33 %
	F-measure = 86.96 %
Evaluation of the article : vol12_page_54 :
	true positives : [["Elaphurus Davidianus", 625, 645], ["Capra dorcas", 3373, 3385], ["Antilope dorcas", 3399, 3414], ["Gazelle dorcas", 3460, 3474], ["Gazelle dorcas", 4080, 4094], ["Gazelle dorcas", 4867, 4881], ["Gazelle dorcas", 5551, 5565], ["Gazelle dorcas", 9329, 9343], ["G. isabella", 4998, 5009], ["G. Cuvieri", 5121, 5131]] 
	false positives : [["Antilopes bovines", 809, 826], ["Antilopes reconnaissables", 939, 964], ["Antilopes eervines", 1200, 1218], ["Antilopes caprines", 1401, 1419], ["Kemas odgsoni", 1848, 1861], ["Gazelle isabelle", 4980, 4996], ["Gazelle corinne", 5042, 5057], ["Antilope mohr", 9854, 9867], ["E. Ousrazer", 9869, 9880], ["E. Gray", 10917, 10924]] 
	false negatives : [["lG. rufifrons", 5058, 5071]] 
	precision = 50.00 %
	recall = 90.91 %
	F-measure = 64.52 %
Evaluation of the article : page_48 :
	true positives : [["Lamprocolius nitens", 5911, 5930]] 
	false positives : [["Gasrox Tissanbier", 3724, 3741]] 
	false negatives : [["Lamprocolius iris", 6493, 6510]] 
	precision = 50.00 %
	recall = 50.00 %
	F-measure = 50.00 %
Evaluation of the article : page_421 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_96 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_241 :
	true positives : [] 
	false positives : [["Paiguille recule", 11956, 11972], ["Hhonune ivre", 13769, 13781], ["Alexandrette centralise", 18800, 18823]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_235 :
	true positives : [["Orchis pyramidulis", 2277, 2295], ["Orchis intacta", 6526, 6540], ["Callleya Epidendrum", 7285, 7304], ["Limodorum abortivum", 8034, 8053], ["Cypripedium barbalum", 17750, 17770], ["Colax jugosus", 17777, 17790], ["Epidendrum \u00e6mulum", 17797, 17814], ["Trichopilia tortilis", 17821, 17841], ["Ansellia africana", 19010, 19027], ["Calypso borealis", 24962, 24978], ["Neottia ovala", 27447, 27460], ["Orchis conopsea", 27731, 27746], ["Arethusa bulbosa", 27809, 27825], ["Spiranthes diuretica", 27949, 27969], ["Chlor\u0153a disoidea", 27983, 27999], ["Cypripsdium pubescens", 28109, 28130], ["Angr\u00e6cum fragrans", 28322, 28339], ["S. macrautha", 14423, 14435], ["C. guttatum", 28247, 28258]] 
	false positives : [["Blume rencontra", 11231, 11246], ["ditum iridifolium", 17852, 17869], ["C. Sprengel", 3631, 3642]] 
	false negatives : [["Neottia nidus-avis", 8009, 8027], ["Neottia nidus-avis", 10382, 10400], ["One'ditum iridifolium", 17848, 17869], ["Orchis Mono", 27065, 27076], ["PO. papilionccea", 27221, 27237], ["Ophrys nidus-avis", 27342, 27359]] 
	precision = 86.36 %
	recall = 76.00 %
	F-measure = 80.85 %
Evaluation of the article : vol12_page_168 :
	true positives : [] 
	false positives : [["alluvion laissa", 6574, 6589], ["Kane envahie", 26994, 27006], ["Delemater tron", 38026, 38040], ["Brazza poussa", 40774, 40787], ["pestis indica", 99476, 99489], ["Kalmouks nomades", 100549, 100565], ["Obserles bourrasques", 126765, 126785], ["O. Desvour", 30063, 30073]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_63 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_52 :
	true positives : [] 
	false positives : [["Repliles permiens", 4045, 4062]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_389 :
	true positives : [] 
	false positives : [["Geite irisation", 1528, 1543], ["G. Tissannigr", 2378, 2391]] 
	false negatives : [["Mygale Pyrenaica", 10, 26]] 
	precision = 0.00 %
	recall = 0.00 %
	F-measure = -100.00 %
Evaluation of the article : vol12_page_106 :
	true positives : [["Cerithium latisulcatum", 2478, 2500], ["Limopsis concentrica", 2522, 2542], ["Cerithium latisulcatum", 5956, 5978], ["Cerithium spiratum", 6228, 6246], ["Cerithium spiratum", 6647, 6665], ["Dentalium eburneum", 7152, 7170], ["Dentalium eburneum", 7462, 7480], ["Nummulites variolaria", 8078, 8099], ["Dentalium eburneum", 8229, 8247], ["Limopsis concentrica", 8585, 8605], ["Cardita Bazini", 9244, 9258], ["Cardium stampinense", 9366, 9385], ["Cardium aviculinum", 9416, 9434]] 
	false positives : [["Quiconque renouvellera", 1472, 1494]] 
	false negatives : [["Dentalium Leoni\u00e6", 2502, 2518], ["Dentalium Leoni\u00e6", 6975, 6991], ["Dentalium Leoni\u00e6", 8199, 8215]] 
	precision = 92.86 %
	recall = 81.25 %
	F-measure = 86.67 %
Evaluation of the article : vol12_page_331 :
	true positives : [] 
	false positives : [["Mio Blanco", 12059, 12069], ["Gastox Tissannier", 29688, 29705], ["Cocilio Pujazon", 32593, 32608], ["Brilo Capello", 33256, 33269], ["Seynes conteste", 38386, 38401], ["Tradescantia Virginica", 69733, 69755], ["th\u0153\u00e6a rosea", 69819, 69830], ["B. Wyse", 18365, 18372], ["G. Cantoni", 34235, 34245]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : page_69 :
	true positives : [] 
	false positives : [["surnommer Bender", 34145, 34161]] 
	false negatives : [] 
	precision = 0.00 %
	recall = 100.00 %
	F-measure = 0.00 %
Evaluation of the article : vol12_page_167 :
	true positives : [["T\u00e6nia solium", 403, 415], ["T\u00e6\u0153nia cucumerina", 3251, 3268], ["T\u00e6nia Echinococcus", 3928, 3946]] 
	false positives : [] 
	false negatives : [["Trichodectes Canis", 3470, 3488], ["Disfonum hepaticun", 6834, 6852], ["D. lanceolatum", 6859, 6873]] 
	precision = 100.00 %
	recall = 50.00 %
	F-measure = 66.67 %
Evaluation of the article : vol12_page_379 :
	true positives : [["Euglena sanguinea", 1872, 1889], ["Astasia h\u0153matodes", 1893, 1910], ["Monas prodigiosa", 2133, 2149], ["Salping\u00e6ca Clarkii", 3270, 3288], ["Astasia h\u00e6matodes", 5711, 5728], ["Phacus longicauda", 5742, 5759], ["Euglena deses", 5772, 5785], ["Stentor polymorphus", 5819, 5838], ["Codosiga Botrytis", 7204, 7221], ["Salping\u00e6ca Clarkii", 7319, 7337], ["Dinobryon sertularia", 7355, 7375], ["Uvella virescens", 7387, 7403], ["Rhipidodendron splendidum", 8823, 8848], ["Cephalothamnium Cyclopum", 8862, 8886], ["Anlhophysa vegetans", 8900, 8919], ["Dendromonas virgurie", 10258, 10278], ["Cladomonas fruticulosa", 10291, 10313], ["Poteriodendron petiolatum", 10364, 10389], ["Noctiluca miliaris", 10861, 10879], ["Notiluca miliaris", 11808, 11825], ["Clepsidrina blattarum", 13528, 13549], ["Gregarina gigantea", 13664, 13682], ["Gregarina gigantea", 18146, 18164], ["Gregarina gigantea", 19889, 19907]] 
	false positives : [["Volvox proprements", 1624, 1642], ["terium digitatum", 10336, 10352], ["orhynchus oligacanthus", 13486, 13508]] 
	false negatives : [["Phalans= terium digitatum", 10327, 10352], ["Hop'orhynchus oligacanthus", 13482, 13508]] 
	precision = 88.89 %
	recall = 92.31 %
	F-measure = 90.57 %
Evaluation of the article : page_137 :
	true positives : [["Verspertilio murinus", 440, 460]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : vol12_page_149 :
	true positives : [] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %
Evaluation of the article : page_86 :
	true positives : [["Phyllorera vaslatrix", 581, 601], ["Quercus pedunculata", 2431, 2450], ["Vitis vinifera", 15238, 15252], ["Schizoneura lanigera", 15622, 15642]] 
	false positives : [] 
	false negatives : [] 
	precision = 100.00 %
	recall = 100.00 %
	F-measure = 100.00 %

overall scores on the corpus vol12:
	precision = 56.42 %
	recall = 79.72 %
	F-measure = 66.08 %

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

## overall scores on the whole corpus:
	precision = 50.63 %
	recall = 82.35 %
	F-measure = 62.71 %
